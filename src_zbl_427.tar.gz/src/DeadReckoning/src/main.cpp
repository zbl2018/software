#include "Fusion.h"

Fusion fusion;

ros::Subscriber CarInfo;
ros::Subscriber LocationInfo;
ros::Publisher PositionInfo;

void LocationInfoHandler(const std_msgs::String::ConstPtr &msg)
{
    std::string DataString = msg->data;
    fusion.UpdateLaserPosition(DataString);
    
}

void CarInfoHandler(const std_msgs::String::ConstPtr &msg)
{
    std::string DataString = msg -> data;
    fusion.UPdateOdometry(DataString);
}

void Data_Send()
{
    std::string position_data = boost::lexical_cast<std::string>(fusion.position.x);
    position_data.append(" ").append(boost::lexical_cast<std::string>(fusion.position.y));
    position_data.append(" ").append(boost::lexical_cast<std::string>(fusion.position.heading));

    std_msgs::String msgs;
    msgs.data = position_data;
    PositionInfo.publish(msgs);
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "DeadReckoning");
    ros::NodeHandle nh;

    CarInfo = nh.subscribe<std_msgs::String>("/odo_send",1000, CarInfoHandler);
    LocationInfo = nh.subscribe<std_msgs::String>("trajectory_node_string",5, LocationInfoHandler);
    PositionInfo = nh.advertise<std_msgs::String>("/final_data",1000);
    
    ros::Duration(5).sleep();
    fusion.ImuInit();

    ros::Rate rate(100);
    while(ros::ok())
    {
        ros::spinOnce();

        fusion.imu.Data_Receive();
        fusion.AngleFusion();
        Data_Send();

        rate.sleep();
    }
    return 0;
}
