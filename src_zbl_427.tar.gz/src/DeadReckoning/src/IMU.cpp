#include "IMU.h"

IMU::IMU()
{
	data_to_send[0]=0x68;
	data_to_send[1]=0x04;	
	data_to_send[2]=0x00;
	data_to_send[3]=0x28;
	data_to_send[4]=0x2C;
}

void IMU::Init()
{
	if((fd = serial.OpenPort(ttyUSB0)) < 0)
	{
	}
	serial.SetPara(fd, 6, 3, 1, 0);
}

void IMU::Data_Receive()
{
	int n = serial.ReadData(fd, data_received, sizeof(data_received)) / sizeof(unsigned char);
	short len;

	for (int i = 0; i < n - 13; i++)
	{
		short sum = 0;
		if ((short)data_received[i] == 0x68 && (short)data_received[i + 1] == 0x0D && (short)data_received[i + 2] == 0x00 && (short)data_received[i + 3] == 0x84)
		{
			len = (short)data_received[i + 1];
			for (int j = i + 1; j < i + len; j++)
			{
				sum += data_received[j];
			}
			if ((sum & 0x00FF) == (short)data_received[i + len])//校验通过
			{
				float tmp;

				tmp = (float)((data_received[i + 4] & 0x0F) * 100 + (data_received[i + 5] >> 4 & 0x0F) * 10 + (data_received[i + 5] & 0x0F) + (data_received[i + 6] >> 4 & 0x0F) * 0.1f + (data_received[i + 6] & 0x0F) * 0.01f);
				if(data_received[i + 4] >> 4 & 0x0F)
					delta_angle = -tmp;
				else
					delta_angle = tmp;
				
				tmp = (float)((data_received[i + 10] & 0x0F) * 100 + (data_received[i + 11] >> 4 & 0x0F) * 10 + (data_received[i + 11] & 0x0F) + (data_received[i + 12] >> 4 & 0x0F) * 0.1f + (data_received[i + 12] & 0x0F) * 0.01f);
				if(data_received[i + 10] >> 4 & 0x0F)
					angle = -tmp;
				else
					angle = tmp;
				
				angle = radians(angle);
				delta_angle = radians(delta_angle);
				
				angle = Angle_Constrain(angle);
			}
		}
	}
}

void IMU::Send_Reset()
{
	serial.WriteData(fd, data_to_send, 5);
}

double IMU::Angle_Constrain(double angle)
{
	if(angle < -M_PI)
	{
		angle += 2 * M_PI;
	}
	else if(angle > M_PI)
	{
		angle -= 2 * M_PI;
	}
	return angle;
}

float radians(float deg)
{
	return (deg * M_PI / 180.0);
}

float degrees(float rad)
{
	return (rad * 180.0 / M_PI);
}
