#include "config.h"

using namespace std;

double x, y, heading;
double last_x, last_y, last_heading;

void PositionInfoHanfler(const std_msgs::String::ConstPtr &msg)
{
    string DataString = msg->data;
    stringstream stringin(DataString);
    stringin >> setprecision(12) >> x >> y >> heading;
    
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "tf_broadcast");

    ros::NodeHandle nh;
    ros::Subscriber PositionInfo = nh.subscribe<std_msgs::String>("position", 1000, PositionInfoHanfler);    
    ros::Publisher OdomInfo = nh.advertise<nav_msgs::Odometry>("odom", 50);
    tf::TransformBroadcaster odom_broadcaster;
    
    ros::Time current_time, last_time;
    current_time = ros::Time::now();
    last_time = ros::Time::now();

    x = y = heading = last_x = last_y = last_heading = 0;

    ros::Rate rate(100);
    while(ros::ok())
    {
        ros::spinOnce();
        current_time = ros::Time::now();

        double dt = (current_time - last_time).toSec();
        double delta_x = x - last_x;
        double delta_y = y - last_y;
        double delta_heading = heading - last_heading;

        geometry_msgs::Quaternion odom_quat = tf::createQuaternionMsgFromYaw(heading);
        geometry_msgs::TransformStamped odom_trans;
        odom_trans.header.stamp = current_time;
        odom_trans.header.frame_id = "odom";
        odom_trans.child_frame_id = "base_link";

        odom_trans.transform.translation.x = -x;
        odom_trans.transform.translation.y = y;
        odom_trans.transform.translation.z = 0.0;
        odom_trans.transform.rotation = odom_quat;

        //send the transform
        odom_broadcaster.sendTransform(odom_trans);

        nav_msgs::Odometry odom;
        odom.header.stamp = current_time;
        odom.header.frame_id = "odom";

        //set the position
        odom.pose.pose.position.x = -x;
        odom.pose.pose.position.y = y;
        odom.pose.pose.position.z = 0.0;
        odom.pose.pose.orientation = odom_quat;

        //set the velocity
        odom.child_frame_id = "base_link";
        odom.twist.twist.linear.x = -delta_x / dt;
        odom.twist.twist.linear.y = delta_y / dt;
        odom.twist.twist.angular.z = delta_heading / dt;

        //publish the message
        OdomInfo.publish(odom);

        last_time = current_time;
        last_x = x;
        last_y = y;
        last_heading = heading;

        rate.sleep();
    }

    return 0;
}
