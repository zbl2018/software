#include <ros/ros.h>
#include <std_msgs/String.h>
#include <boost/lexical_cast.hpp>
#include <pthread.h>
#include "control_car.h"

using namespace std;

ros::Publisher CarData_pub;

//Car Data var
car cc;
double o1,o2,o3,o4,a1,a2,a3,a4;
double sm1,sm2,sm3,sm4;
int car_mode;

//read info from the car and open a thread to send to other node
pthread_t id;
int ret;

void send_info_to_deadreckoning(){
  string tmp,r;

  tmp.clear();r.clear();
  tmp = boost::lexical_cast<string>(o1);
  r = tmp;

  tmp.clear();
  tmp = boost::lexical_cast<string>(o2);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(o3);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(o4);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(a1);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(a2);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(a3);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(a4);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(car_mode);
  r.append(" ").append(tmp);

  std_msgs::String msg;
  msg.data = r;
  CarData_pub.publish(msg);
}

void* getData(void* args)//get data from car and send 
{
    
    while(true){
      cc.DataReceive();
      o1 = cc.pul1_data;//四个里程计数据
      o2 = cc.pul2_data;
      o3 = cc.pul3_data;
      o4 = cc.pul4_data;

      a1 = cc.sv1_ac_data;
      a2 = cc.sv2_ac_data;
      a3 = cc.sv3_ac_data;
      a4 = cc.sv4_ac_data;

      car_mode = cc.mode_data;
    }
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "Cardata");
    ros::NodeHandle nh;
    CarData_pub = nh.advertise<std_msgs::String>("carinfo", 100);
    o1 = o2 = o3 = o4 = a1 = a2 = a3 = a4 = car_mode = 0;
    ret = pthread_create(&id,NULL,getData,NULL);
    
    ros::Rate rate(100);
    while(ros::ok())
    {
        send_info_to_deadreckoning();
        ros::spinOnce();
        rate.sleep();
    }

    return 0;
}
