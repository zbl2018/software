#include "Fusion.h"

std::ofstream III("/home/equal/SouthGird/BASE/src/Fusion.csv");

std::ofstream JJJ("/home/equal/SouthGird/BASE/src/Laser.csv");

void Fusion::AngleFusion()
{
    //std::cout << degrees(position.heading) << " ";
    position.heading = 0.02 * position.heading + 0.98 * (imu.angle - imu.offset);
    //std::cout << degrees(imu.angle) << " " << degrees(imu.offset) << " " << degrees(position.heading) << std::endl;
}

void Fusion::ImuInit()
{
    imu.Init();
    imu.Send_Reset();
}

void Fusion::UPdateOdometry(const std::string &DataString)
{
    long int odometry[4] = {0};
    long int steer[4] = {0};
    int mode = 0;

    std::stringstream stringin(DataString);
    stringin >> odometry[0] >> odometry[1] >> odometry[2] >> odometry[3]
             >> steer[0] >> steer[1] >> steer[2] >> steer[3] >> mode;

    odom.sendOdometryAndSteerInfo(odometry, steer, mode);
    Position delta = odom.getDelta();
    III << delta.x << " " << delta.y << " " << delta.heading << " " << position.x << " " << position.y << " " << position.heading << std::endl;
    position.x -= cos(position.heading) * delta.x - sin(position.heading) * delta.y;
    position.y += cos(position.heading) * delta.y + sin(position.heading) * delta.x;
    position.heading -= delta.heading;
    position.heading = imu.Angle_Constrain(position.heading);
}

void Fusion::UpdateLaserPosition(const std::string &DataString)
{
    double x, y, heading;
    x = y = heading = 0;

    std::stringstream stringin(DataString);
    stringin >> y >> x >> heading;

    heading = heading * 3.1415926 / 180.0;

    position.x = x;
    position.y = y;
    position.heading = imu.Angle_Constrain(heading);
    JJJ << x << " " << y << " " << heading << std::endl;
    imu.offset = imu.angle - position.heading;
}
