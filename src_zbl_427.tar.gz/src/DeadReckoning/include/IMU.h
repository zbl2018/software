#pragma once

#include "serial.h"
#include <cmath>

float radians(float deg);
float degrees(float rad);

class IMU
{
public:
	double delta_angle;
	double angle;
	double offset;

	IMU();
	void Init();
	void Data_Receive();
	void Send_Reset();
	double Angle_Constrain(double angle);
	
private:
	unsigned char data_received[256];
	unsigned char data_to_send[8];
	Serial serial;
	int fd;
};
