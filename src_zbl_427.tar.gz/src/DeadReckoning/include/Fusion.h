#pragma once

#include "IMU.h"
#include "Odometry.h"

class Fusion
{
public:
    IMU imu;
    Odometry odom;
    Position position;

    void AngleFusion();
    void ImuInit();
    void UPdateOdometry(const std::string &DataString);
    void UpdateLaserPosition(const std::string &DataString);
};
