// @author: Raphael 
// Data: Sept 15th 2017 

#include <ros/ros.h>
#include <sensor_msgs/PointCloud2.h>
#include <sensor_msgs/point_cloud2_iterator.h>
#include <vector>
#include <lcm/lcm-cpp.hpp>
#include "lidar_lcm/lidar_grid.hpp"

void GetObstacles(const sensor_msgs::PointCloud2 &height_map_obstacles);

int main(int argc, char **argv) {
  ros::init(argc, argv, "height_map_obstacle_subscriber");
  ros::NodeHandle n;
  ros::Subscriber sub = n.subscribe("velodyne_obstacles", 1028, GetObstacles);
  ros::spin();
  return 0;
}

void GetObstacles(const sensor_msgs::PointCloud2 &heightmap_obstacles) {
  sensor_msgs::PointCloud2 obstacles = heightmap_obstacles;
  
  int h = obstacles.height;
  int w = obstacles.width;
  int rs = obstacles.row_step;
  int ps = obstacles.point_step;
  ROS_INFO("height:[%d],width:[%d],row_step:[%d],point_step:[%d]", h, w, rs, ps);


  int pointOffSet = ps/4;

  // grid map range
  int ahead = 20;
  int behind = 20;
  int left = 20;
  int right = 20;
  double grid_size = 0.1; 
  int row_len = (ahead + behind) / grid_size;
  int col_len = (left + right) / grid_size;

  long long current_time = ros::Time::now().toSec() * 100;
  ROS_INFO("current_time: %lld", current_time);

  // init lcm data
  lcm::LCM lcm_velodyne_lidar("udpm://239.255.76.63:7667?ttl=5");

  if (!lcm_velodyne_lidar.good())
  {
    ROS_INFO("fail to create lcm(LCM thread dumped)\n");
    return;
  }
  lidarlcm::lidar_grid velodyne_lidar_data;
  velodyne_lidar_data.gps_time = current_time;
  velodyne_lidar_data.forward = ahead;
  velodyne_lidar_data.backward = behind;
  velodyne_lidar_data.left = left;
  velodyne_lidar_data.right = right;
  velodyne_lidar_data.grid_size = grid_size;
  velodyne_lidar_data.row_len = row_len;
  velodyne_lidar_data.col_len = col_len;
  velodyne_lidar_data.occupany.resize(row_len,std::vector<double>(col_len,0));
  velodyne_lidar_data.avg_height.resize(row_len,std::vector<double>(col_len,0));
  velodyne_lidar_data.avg_intensity.resize(row_len,std::vector<double>(col_len,0));
  velodyne_lidar_data.relative_speed.resize(row_len,std::vector<double>(col_len,0));
  
  sensor_msgs::PointCloud2Iterator<float> iter_xyz(obstacles,"x");

  // Translate to grid map
  for(int i = 0; i <= h; i++) {
    for(int j = 0; j < w; j++) {
      int x_index = (left - iter_xyz[j*pointOffSet+1]) / grid_size;
      int y_index = (ahead - iter_xyz[j*pointOffSet+0]) / grid_size;
      if( 0 < x_index && x_index < row_len && 0 < y_index && y_index < col_len) {
        ROS_INFO("x:[%f] y:[%f] z:[%f]",iter_xyz[j*pointOffSet+0],iter_xyz[j*pointOffSet+1],iter_xyz[j*pointOffSet+2]);
        velodyne_lidar_data.occupany[x_index][y_index] = 1;
        std::cout<<x_index<<" "<<y_index<<std::endl;
      }
    }
  }
  lcm_velodyne_lidar.publish("lidar_grid", &velodyne_lidar_data);
}
