#include <ros/ros.h>
#include <sensor_msgs/PointCloud2.h>
#include <sensor_msgs/point_cloud2_iterator.h>
#include <vector>
#include <fstream>
#include <string>
#include <sstream>

#include <cmath>
#include <vector>

#include <nav_msgs/Odometry.h>
//#include <opencv/cv.h>
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/kdtree/kdtree_flann.h>
#include <ros/ros.h>
#include <iomanip>
#include <sensor_msgs/Imu.h>
#include <sensor_msgs/PointCloud2.h>
#include <boost/lexical_cast.hpp>
#include <tf/transform_datatypes.h>
#include <tf/transform_broadcaster.h>
#include <iostream>
#include "std_msgs/Int8.h"
#include "std_msgs/String.h"

using namespace std;

struct Point{
	double x;
	double y;
};

ros::Publisher obstacle_send;

void SendData(vector<Point> points){
  	string tmp,r;
  	
  	for(int i = 0 ;i<points.size();i++)
  	{
  		if(i == 0 )
  		{
  			tmp.clear();r.clear();
		  	tmp = boost::lexical_cast<string>(points[i].x);
		  	r = tmp;
		  	tmp.clear();
		  	tmp = boost::lexical_cast<string>(points[i].y);
		  	r.append(" ").append(tmp).append(";");
  		}
  		else
  		{
  			tmp.clear();
  			tmp = boost::lexical_cast<string>(points[i].x);
  			r.append(tmp);
  			tmp.clear();
  			tmp = boost::lexical_cast<string>(points[i].y);
  			r.append(" ").append(tmp).append(";");
  		}
  	}

  	std_msgs::String msg;
  	msg.data = r;
  	obstacle_send.publish(msg);
  	
}

void GetObstacles(const sensor_msgs::PointCloud2ConstPtr& heightmap_obstacles) {
	double timeScanCur = heightmap_obstacles->header.stamp.toSec();
	pcl::PointCloud<pcl::PointXYZI> obstacleCloudIn;
	pcl::fromROSMsg(*heightmap_obstacles, obstacleCloudIn);

	int cloudSize = obstacleCloudIn.points.size();
	vector<Point> point;
	for(int i=0;i<cloudSize;i++)
	{
  		double x = obstacleCloudIn.points[i].x;
   		double y = obstacleCloudIn.points[i].y;
   		
		if(x < 0) continue;
    if(fabs(y) > 0.5) continue;   
   		Point newpoint;//x跟y相反
   		newpoint.x = y;
   		newpoint.y = x;
		
   		point.push_back(newpoint);

   		//grid[x][y] = 1;
	}
	//test = false;

	SendData(point);
}


int main(int argc, char **argv) {
  ros::init(argc, argv, "height_map_obstacle_subscriber");
  ros::NodeHandle n;
  ros::Subscriber sub = n.subscribe<sensor_msgs::PointCloud2>("velodyne_obstacles", 1028, GetObstacles);
  obstacle_send = n.advertise<std_msgs::String>("/obstacle_out",1000);
  ros::spin();
  return 0;
}
