#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <iomanip>
#include <cstring>
#include <sstream>
#include <stdio.h>   
#include <stdlib.h>  

#include <ros/ros.h>
#include "std_msgs/String.h" 
#include "std_msgs/Int8.h"
#include "std_msgs/Int64.h"
#include <boost/lexical_cast.hpp>

#include <loam_velodyne/pathPlan.hpp>
#include <loam_velodyne/geography.hpp>

using namespace std;

const string taskfile("/home/shenrk/lym/catkin_lidar/src/loam_velodyne/tasknode.txt");

ros::Publisher Path_send;
ros::Publisher Task_plan;
ros::Subscriber Arrive_task;
ros::Subscriber Location_now;
ros::Subscriber Obstacle_plan;


// double lat_now = 0.1989;//x
// double lon_now = 216.765;//y
double lat_now = 0;
double lon_now = 0;
// double lat_now = 17.8;
// double lon_now = 2.71815;
// double lat_now = 17.8003139496;
// double lon_now = 10.1500740051;
double heading_now = 0;

double taskx;
double tasky;

int is_car_arrvie = 1;
int is_obstacle = 0;

vector<PointS> task;

void LocationHandler(const std_msgs::String::ConstPtr &msg){
    
    string moves = msg->data;
    //stringstream stringin(moves);
    stringstream stringin2(moves);
    //stringin>>lat>>lon>>heading;
    double tmpx = 0;
    double tmpy = 0;
    double tmpheading = 0;

    // stringin2>>setprecision(12)>>tmpx>>tmpy>>tmpheading;

    // if(fabs(tmpx)>0.5 && fabs(tmpy)>0.5){
    //     lat_now = tmpx;
    //     lon_now = tmpy;
    //     heading_now = tmpheading;
    // }

    stringin2>>setprecision(12)>>lat_now>>lon_now>>heading_now;
    
    //heading = heading * 180.0 / 3.14159265;
} 

void Arrive_Car_Handler(const std_msgs::Int8::ConstPtr &msg){
    is_car_arrvie = msg->data;
    cout<<"the car have stop ok!!!!!!!!!!!!"<<endl;
}

void Obstacle_plan_Handle(const std_msgs::Int8::ConstPtr &msg){
    is_obstacle = msg->data;
}

int main(int argc, char **argv){
    ros::init(argc, argv, "pathplan");
    ros::NodeHandle nh;

    Path_send = nh.advertise<std_msgs::String>("/map_send",1000);//map send test
    Task_plan = nh.advertise<std_msgs::String>("/task_net",1000);//任务点数据发布
    Location_now = nh.subscribe<std_msgs::String>("/final_data",1000,LocationHandler);
    Arrive_task = nh.subscribe<std_msgs::Int8>("/car_arrive",5,Arrive_Car_Handler);
    Obstacle_plan = nh.subscribe<std_msgs::Int8>("/obstacle_plan",5,Obstacle_plan_Handle);

    ifstream infile;
    infile.open(taskfile.c_str());
    task.clear();
    stringstream ss;
    string stirng_tmp;

    double task_lat = 0;
    double task_lon = 0;

    ros::Duration(5).sleep();

    while(!infile.eof())
    {
        stirng_tmp.clear();
        ss.clear();
        getline(infile,stirng_tmp);
        if(stirng_tmp.compare("") == 0) continue;
        ss<<stirng_tmp;
        ss>>setprecision(12)>>task_lat>>task_lon;
        PointS newpoint;
        newpoint.lat = task_lat;
        newpoint.lon = task_lon;
        task.push_back(newpoint);
    }

    infile.close();
    cout<<task.size()<<endl;
    for(int i=0;i<task.size();i++)
    {
        cout<<task[i].lat<<" "<<task[i].lon<<endl;
    }

    int task_id_old = 0;
    int task_id = 0;
    cout<<"plan node ready..."<<endl;
    ros::Rate rate(200);
    bool status = ros::ok();
    while(status)
    {
    	ros::spinOnce();

        if(is_car_arrvie == 1)
    	{
		    while(true)
            {
                task_id = rand() % task.size();
                //cout<<"task id..."<<task_id<<endl;
                if(task_id_old != task_id)
                {
                    task_id_old = task_id;

                    break;
                }
            }
            cout<<"Plan!!!!!!!!!!!!!!!!!!!!!!!!!!"<<endl;
            cout<<setprecision(12)<<"lat_now: "<<lat_now<<"  lon_now: "<<lon_now<<endl;
            cout<<"task_x: "<<task[task_id].lat<<" task_y: "<<task[task_id].lon<<" task_id:"<<task_id<<endl;
		    vector<PointS> task_node;
		    PointS task_now;
		    task_now.lat = lat_now;
		    task_now.lon = lon_now;
		    task_node.push_back(task_now);
		    task_node.push_back(task[task_id]);


            // lat_now = task[task_id].lat;
            // lon_now = task[task_id].lon;

            taskx = task[task_id].lat;
            tasky = task[task_id].lon;

		    std_msgs::String msg;

		    string task_x = boost::lexical_cast<string>(task[task_id].lat);
		    string task_y = boost::lexical_cast<string>(task[task_id].lon);
		    string task_speed = "0.2";
		    string task_string("");
		    task_string.append(task_x).append(" ").append(task_y).append(" ").append(task_speed);
		    msg.data = task_string;
            Task_plan.publish(msg);


		    pathPlan pa;
		    vector<PointS> plan_node = pa.calculate(task_node);
		    string path_send = pa.pathplan;//规划完成的导航路径

		    msg.data = path_send;
            Path_send.publish(msg);
            is_car_arrvie = 0;

    	}


        if(is_obstacle)
        {
            vector<PointS> task_node;
		    PointS task_now;
		    task_now.lat = lat_now;
		    task_now.lon = lon_now;
		    task_node.push_back(task_now);
            task_now.lat = taskx;
            task_now.lon = tasky;
		    task_node.push_back(task_now);

		    std_msgs::String msg;
		    string task_x = boost::lexical_cast<string>(task[task_id].lat);
		    string task_y = boost::lexical_cast<string>(task[task_id].lon);
		    string task_speed = "0.2";
		    string task_string("");
		    task_string.append(task_x).append(" ").append(task_y).append(" ").append(task_speed);
		    msg.data = task_string;
            Task_plan.publish(msg);

            double heading = heading_now *180/3.14159;
            pathPlan pa;
            vector<PointS> plan_node = pa.obstacles(task_node,heading);
		    string path_send = pa.pathplan;//规划完成的导航路径

		    msg.data = path_send;
            Path_send.publish(msg);

            is_obstacle = 0;
        }

        status = ros::ok();
        rate.sleep();
    }
    return 0;  
}
