#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <iomanip>
#include <cstring>
#include <sstream>
#include <stdio.h>   
#include <stdlib.h>  

#include <ros/ros.h>
#include "std_msgs/String.h" 
#include "std_msgs/Int8.h"
#include "std_msgs/Int64.h"
#include <boost/lexical_cast.hpp>

#include <loam_velodyne/pathPlan.hpp>
#include <loam_velodyne/geography.hpp>

using namespace std;

const string taskfile("/home/dky/catkin_lidar/src/loam_velodyne/tasknode.txt");

ros::Publisher Path_send;
ros::Publisher Task_plan;
ros::Subscriber Arrive_task;
ros::Subscriber Location_now;

double lat_now = 0;
double lon_now = 0;
double heading_now = 0;

int is_car_arrvie = 1;

vector<PointS> task;

void LocationHandler(const std_msgs::String::ConstPtr &msg){
    
    string moves = msg->data;
    //stringstream stringin(moves);
    stringstream stringin2(moves);
    //stringin>>lat>>lon>>heading;

    stringin2>>setprecision(12)>>lat_now>>lon_now>>heading_now;

    //heading = heading * 180.0 / 3.14159265;
} 

void Arrive_Car_Handler(const std_msgs::Int8::ConstPtr &msg){
	is_car_arrvie = msg->data;
}

int main(int argc, char **argv){
    ros::init(argc, argv, "pathplan");
    ros::NodeHandle nh;

    Path_send = nh.advertise<std_msgs::String>("/map_send",1000);//map send test
    Task_plan = nh.advertise<std_msgs::String>("/task_net",1000);//任务点数据发布
    Location_now = nh.subscribe<std_msgs::String>("/final_data",1000,LocationHandler);
    Arrive_task = nh.subscribe<std_msgs::Int8>("car_arrive",5,Arrive_Car_Handler);

    ifstream infile;
    infile.open(taskfile.c_str());
    task.clear();
    stringstream ss;
    string stirng_tmp;

    double task_lat = 0;
    double task_lon = 0;
    while(!infile.eof())
    {
        stirng_tmp.clear();
        ss.clear();
        getline(infile,stirng_tmp);
        if(stirng_tmp.compare("") == 0) continue;
        ss<<stirng_tmp;
        ss>>setprecision(12)>>task_lat>>task_lon;
        PointS newpoint;
        newpoint.lat = task_lat;
        newpoint.lon = task_lon;
        task.push_back(newpoint);
    }

    infile.close();
    cout<<task.size()<<endl;
    for(int i=0;i<task.size();i++)
    {
        cout<<task[i].lat<<" "<<task[i].lon<<endl;
    }

    ros::Rate rate(200);
    bool status = ros::ok();
    while(status)
    {
    	//cout<<"is car arrived"<<is_car_arrvie<<endl;
        int task_id = rand() % task.size();
        //cout<<"id "<<task_id<<endl;
        if(is_car_arrvie)
    	{
		    cout<<"task_x: "<<task[task_id].lat<<" task_y: "<<task[task_id].lon<<endl;
		    vector<PointS> task_node;
		    PointS task_now;
		    task_now.lat = lat_now;
		    task_now.lon = lon_now;
		    task_node.push_back(task_now);
		    task_node.push_back(task[task_id]);

		    std_msgs::String msg;

		    string task_x = boost::lexical_cast<string>(task[task_id].lat);
		    string task_y = boost::lexical_cast<string>(task[task_id].lon);
		    string task_speed = "0.2";
		    string task_string("");
		    task_string.append(task_x).append(" ").append(task_y).append(" ").append(task_speed);
		    msg.data = task_string;
            Task_plan.publish(msg);


		    pathPlan pa;
		    vector<PointS> plan_node = pa.calculate(task_node);
		    string path_send = pa.pathplan;//规划完成的导航路径
		    msg.data = path_send;
            Path_send.publish(msg);
            is_car_arrvie = 0;

    	}

        status = ros::ok();
        rate.sleep();
    }
    return 0;  
}