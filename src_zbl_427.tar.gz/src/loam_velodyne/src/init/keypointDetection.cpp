#include <init/keypointDetection.h>


using namespace boost::filesystem;
using namespace std;
using namespace utility;
using namespace keypoint;
using namespace pcl;

bool cmpBasedOnCurvature(CkeypointDetection::pcaFeature &a, CkeypointDetection::pcaFeature &b)
{
	if (a.curvature>b.curvature)
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool CkeypointDetection::keypointDetectionBasedOnCurvature(PointCloud<PointXYZI>::Ptr inputPointCloud,PointIndicesPtr &keypointIndices)
{

	vector<pcaFeature> features(inputPointCloud->points.size());
	CalculatePcaFeaturesOfPointCloud(inputPointCloud, m_option.radiusFeatureCalculation, features);

	int keypointNum = 0;

	pcl::PointIndicesPtr candidateIndices(new pcl::PointIndices());
	pruneUnstablePoints(features, m_option.ratioMax, candidateIndices);

	std::vector<pcaFeature> stableFeatures;
	for (size_t i = 0; i < candidateIndices->indices.size(); ++i)
	{
		stableFeatures.push_back(features[candidateIndices->indices[i]]);
	}

	pcl::PointIndicesPtr nonMaximaIndices(new pcl::PointIndices());
	nonMaximaSuppression(stableFeatures, nonMaximaIndices);
	keypointIndices = nonMaximaIndices;
	keypointNum = keypointIndices->indices.size();

	bool finishIteration = false;
	float ratioMax = m_option.ratioMax;

	if (keypointNum > 15000)
	{
		do
		{
			if (keypointNum < 5000)
			{
				ratioMax += 0.025;
				finishIteration = true;
			}
			else
			{
				ratioMax -= 0.05;
			}

			candidateIndices->indices.clear();
			pruneUnstablePoints(features, ratioMax, candidateIndices);
			stableFeatures.clear();
			for (size_t i = 0; i < candidateIndices->indices.size(); ++i)
			{
				stableFeatures.push_back(features[candidateIndices->indices[i]]);
			}

			nonMaximaIndices->indices.clear();
			nonMaximaSuppression(stableFeatures, nonMaximaIndices);
			keypointIndices = nonMaximaIndices;
			keypointNum = keypointIndices->indices.size();

		} while ((keypointNum < 5000 || keypointNum > 15000) && (finishIteration == false) && ratioMax >= 0.65);
	}

	cout << setiosflags(ios::fixed) << setprecision(3) << ratioMax << endl;
	return true;
}

bool CkeypointDetection::pruneUnstablePoints(vector<pcaFeature> &features, float ratioMax, pcl::PointIndicesPtr &indices)
{
	for (size_t i = 0; i < features.size(); ++i)
	{
		float ratio1, ratio2;
		ratio1 = features[i].values.lamada2 / features[i].values.lamada1;
		ratio2 = features[i].values.lamada3 / features[i].values.lamada2;

		if (ratio1 < ratioMax && ratio2 < ratioMax && features[i].ptNum > m_option.minPtNum)
		{
			indices->indices.push_back(i);
		}
	}

	return true;
}


bool CkeypointDetection::nonMaximaSuppression(std::vector<pcaFeature> &features,pcl::PointIndicesPtr &indices)
{
	sort(features.begin(), features.end(), cmpBasedOnCurvature);
	pcl::PointCloud<pcl::PointXYZI> pointCloud;

	/*建立UnSegment以及UnSegment的迭代器,存储未分割的点号;*/
	set<size_t, less<size_t>> unVisitedPtId;
	set<size_t, less<size_t>>::iterator iterUnseg;
	for (size_t i = 0; i < features.size(); ++i)
	{
		unVisitedPtId.insert(i);
		pointCloud.points.push_back(features[i].pt);
	}

	pcl::KdTreeFLANN<pcl::PointXYZI> tree;
	tree.setInputCloud(pointCloud.makeShared());

	//邻域搜索所用变量
	vector<int> search_indices;
	vector<float> distances;

	size_t keypointNum = 0;
	do
	{
		keypointNum++;
		vector<int>().swap(search_indices);
		vector<float>().swap(distances);

		size_t id;
		iterUnseg = unVisitedPtId.begin();
		id = *iterUnseg;
		indices->indices.push_back(features[id].ptId);
		unVisitedPtId.erase(id);

		tree.radiusSearch(features[id].pt, m_option.radiusNonMax, search_indices, distances);

		for (size_t i = 0; i < search_indices.size(); ++i)
		{
			unVisitedPtId.erase(search_indices[i]);
		}

	} while (!unVisitedPtId.empty());

	return true;
}

void CkeypointDetection::outputKeypoints(const std::string &filenames, pcl::PointIndicesPtr &indices,
										 pcl::PointCloud<pcl::PointXYZI>::Ptr cloud)
{
	//获得点云的bound;
	pointCloudBound bound;
	getCloudBound(*cloud, bound);


	//根据indices获得对应的keypoint点云;
	pcl::PointCloud<pcl::PointXYZI>::Ptr keypoint_cloud(new pcl::PointCloud<pcl::PointXYZI>);
	pcl::PointCloud<pcl::PointXYZI>::Ptr other_cloud(new pcl::PointCloud<pcl::PointXYZI>);
	pcl::ExtractIndices<pcl::PointXYZI> extract;

	extract.setInputCloud(cloud);
	extract.setIndices(indices);
	extract.setNegative(false);
	extract.filter(*keypoint_cloud);
	extract.setNegative(true);
	extract.filter(*other_cloud);

	size_t pt_num = keypoint_cloud->size() + other_cloud->size();

	boost::filesystem::path dir(filenames);
	std::string folderName;
	folderName = "KeypointLas";
	//创建文件夹;
	if (!boost::filesystem::exists(folderName))
	{
		boost::filesystem::create_directory(folderName);
	}

	//获取不包含路径和后缀的文件名;
	std::string outputFileName;
	outputFileName = dir.stem().string();
	outputFileName = folderName + "/" + outputFileName + "_Keypoint.las";


	std::ofstream ofs;
	ofs.open(outputFileName, std::ios::out | std::ios::binary);
	if (ofs.is_open())
	{
		liblas::Header header;
		header.SetDataFormatId(liblas::ePointFormat2);
		header.SetVersionMajor(1);
		header.SetVersionMinor(2);
		header.SetMin(bound.minx, bound.miny, bound.minz);
		header.SetMax(bound.maxx, bound.maxy, bound.maxz);
		header.SetOffset((bound.minx + bound.maxx) / 2.0, (bound.miny + bound.maxy) / 2.0, (bound.minz + bound.maxz) / 2.0);
		header.SetScale(0.01, 0.01, 0.01);
		header.SetPointRecordsCount(pt_num);
		liblas::Writer writer(ofs, header);
		liblas::Point pt(&header);

		for (int j = 0; j < keypoint_cloud->size(); j++)
		{
			pt.SetCoordinates(keypoint_cloud->points[j].x,
							  keypoint_cloud->points[j].y,
							  keypoint_cloud->points[j].z);
			pt.SetIntensity(10);
			pt.SetColor(liblas::Color(255, 0, 0));
			writer.WritePoint(pt);
		}

		for (int j = 0; j < other_cloud->size(); j++)
		{
			pt.SetCoordinates(other_cloud->points[j].x,
							  other_cloud->points[j].y,
							  other_cloud->points[j].z);
			pt.SetIntensity(10);
			pt.SetColor(liblas::Color(0, 0, 255));
			writer.WritePoint(pt);
		}

		ofs.flush();
		ofs.close();
	}
}