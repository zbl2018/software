#include <init/registration.h>

using namespace pcRegistration;

using namespace  std;
using namespace utility;
using namespace pcRegistration;
struct Lap{
	string file;
	double score;
	int index;
};
bool compa(Lap p,Lap q)
{
	if(p.score > q.score) return true;
	else return false;
}
bool cmpSimilarity2(IdSimilarity &a, IdSimilarity &b)
{
    return a.similarity > b.similarity ? true : false;
}

bool CmpWeightPtNum(Edge &a, Edge &b)
{
    return a.weightPtNum > b.weightPtNum ? true : false;
}

bool CmpWeightOverlap(Edge &a, Edge &b)
{
    return a.weightOverlap > b.weightOverlap ? true : false;
}

//比较两个配对关系的汉明距离;
bool CmpHammingDistance(RegistrationPair &a, RegistrationPair &b)
{
    return a.hamming_distance < b.hamming_distance ? true : false;
}

//比较两个vector的大小;
bool CmpRegPairNum(concurrencyVectorRegistrationPair &a, concurrencyVectorRegistrationPair &b)
{
    return a.size() > b.size() ? true : false;
}

bool cmpTargetId(RegistrationPair &a, RegistrationPair &b)
{
    return a.target_id < b.target_id ? true : false;

}

/*从target_sbfs中找到跟src_sbf中最佳匹配的特征;*/
bool CRegistration::FindOptimalFeaturePairBasedOnOneWayOptimal(size_t srcIndex, vector<StereoBinaryFeature>  &src_sbfs_coor1,
															   vector<StereoBinaryFeature> & target_sbfs_coor1,
															   vector<StereoBinaryFeature> & target_sbfs_coor2,
															   RegistrationPair &feature_pair)
{
	StereoBinaryFeature src_sbf = src_sbfs_coor1[srcIndex];

	int min_dis = (int)(src_sbf.size_*m_coRgopt.tolerantHammingDis);
	int hamming_dis;
	RegistrationPair rp_coor;
	VectorRegistrationPair vrp;
    VectorRegistrationPair().swap(vrp);

	for (int i = 0; i < target_sbfs_coor1.size(); i++)
	{
		if (target_sbfs_coor1[i].feature_ == nullptr)
		{
			continue;
		}
		else
		{
			hamming_dis = hammingDistance(src_sbf, target_sbfs_coor1[i]);
			rp_coor.target_id = target_sbfs_coor1[i].keypointIndex_;
			rp_coor.src_id = srcIndex;
			rp_coor.hamming_distance = hamming_dis;
			rp_coor.target_index = 0;

			if (rp_coor.hamming_distance < min_dis)
			{
				vrp.push_back(rp_coor);
			}
		}
	}

	for (int i = 0; i < target_sbfs_coor2.size(); i++)
	{
		if (target_sbfs_coor2[i].feature_ == nullptr)
		{
			continue;
		}
		else
		{
			hamming_dis = hammingDistance(src_sbf, target_sbfs_coor2[i]);
			rp_coor.target_id = target_sbfs_coor2[i].keypointIndex_;
			rp_coor.src_id = srcIndex;
			rp_coor.hamming_distance = hamming_dis;
			rp_coor.target_index = 1;

			if (rp_coor.hamming_distance < min_dis)
			{
				vrp.push_back(rp_coor);
			}
		}
	}

	if (vrp.empty())
	{
		return false;
	}
	else
	{
		//2016.10.08 修改：添加约束使得特征匹配具有单向的唯一性;
		sort(vrp.begin(), vrp.end(), CmpHammingDistance);
		if (vrp[0].hamming_distance <= min_dis &&
			vrp[0].hamming_distance < vrp[1].hamming_distance)
		{
			feature_pair = vrp[0];
			return true;
		}
		else
		{
			return false;
		}
	}
}

bool CRegistration::FindOptimalFeaturePairBasedOnTwoWayOptimal(size_t srcIndex,vector<StereoBinaryFeature>  &src_sbfs_coor1,
															   vector<StereoBinaryFeature> & target_sbfs_coor1,
															   vector<StereoBinaryFeature> & target_sbfs_coor2,
															   RegistrationPair &feature_pair)
{
	RegistrationPair tempFeaturePair;
	bool tempBool;
	StereoBinaryFeature src_sbf;
	src_sbf = src_sbfs_coor1[srcIndex];

	tempBool = FindOptimalFeaturePairBasedOnOneWayOptimal(srcIndex, src_sbfs_coor1,target_sbfs_coor1, target_sbfs_coor2,tempFeaturePair);

	if (!tempBool)
	{
		return false;
	}
	else
	{
		int min_dis = (int)(src_sbf.size_*m_coRgopt.tolerantHammingDis);

		VectorRegistrationPair vrp;

		StereoBinaryFeature  target_sbf;
		switch (tempFeaturePair.target_index)
		{
			case 0:
				target_sbf = target_sbfs_coor1[tempFeaturePair.target_id];
				break;

			case 1:
				target_sbf = target_sbfs_coor2[tempFeaturePair.target_id];
				break;
		}

		for (int i = 0; i < src_sbfs_coor1.size(); i++)
		{
			if (src_sbfs_coor1[i].feature_ == nullptr)
			{
				continue;
			}
			else
			{
				int hamming_dis;
				RegistrationPair tempPair;
				hamming_dis = hammingDistance(target_sbf, src_sbfs_coor1[i]);
				tempPair.src_id = static_cast<size_t>(i);
				tempPair.hamming_distance = hamming_dis;
				if (hamming_dis < min_dis)
				{
					vrp.push_back(tempPair);
				}
			}
		}

		if (vrp.empty())
		{
			return false;
		}
		else
		{
			//2016.10.08 修改：添加约束使得特征匹配具有单向的唯一性;
			sort(vrp.begin(), vrp.end(), CmpHammingDistance);
			if (vrp[0].hamming_distance < vrp[1].hamming_distance
				&&vrp[0].src_id == srcIndex)
			{

				vrp[0].target_id = tempFeaturePair.target_id;
				vrp[0].src_id = srcIndex;
				feature_pair = vrp[0];
				return true;
			}
			else
			{
				return false;
			}
		}
	}
}


/*计算符合特征一致性的点对集合;*/
bool CRegistration::CalculateFeatureConsistencyPointPairs(vector<StereoBinaryFeature>  &src_sbfs_coor1,
														  vector<StereoBinaryFeature>  &target_sbfs_coor1,
														  vector<StereoBinaryFeature>  &target_sbfs_coor2,
														  concurrencyVectorRegistrationPair &reg_pairs_f)
{

	float searchRadius;
	searchRadius = static_cast<float>(1.0 / 2.0f * m_coRgopt.tolerantHammingDis * src_sbfs_coor1[0].size_);

	//利用三个点个数作为三维坐标构建KD树
	//邻域搜索所用变量
	pcl::KdTreeFLANN<pcl::PointXYZ> tree_coor1, tree_coor2;
	pcl::PointCloud<pcl::PointXYZ>::Ptr pointCloud_coor1(new pcl::PointCloud<pcl::PointXYZ>());
	pcl::PointCloud<pcl::PointXYZ>::Ptr pointCloud_coor2(new pcl::PointCloud<pcl::PointXYZ>());

	pointCloud_coor1->resize(target_sbfs_coor1.size());
	pointCloud_coor2->resize(target_sbfs_coor1.size());

	for (size_t i = 0; i < target_sbfs_coor1.size(); ++i)
	{
		pcl::PointXYZ pt;
		pt.x = target_sbfs_coor1[i].numOfOneInGridFeature_;
		pt.y = target_sbfs_coor1[i].numOfOneInDensityComparisonFeature_;
		pt.z = target_sbfs_coor1[i].numOfOneInDistanceComparisonFeature_;
		pointCloud_coor1->points[i] = pt;

		pt.x = target_sbfs_coor2[i].numOfOneInGridFeature_;
		pt.y = target_sbfs_coor2[i].numOfOneInDensityComparisonFeature_;
		pt.z = target_sbfs_coor2[i].numOfOneInDistanceComparisonFeature_;
		pointCloud_coor2->points[i] = pt;

	}
	tree_coor1.setInputCloud(pointCloud_coor1);
	tree_coor2.setInputCloud(pointCloud_coor2);


	tbb::parallel_for(size_t(0), src_sbfs_coor1.size(), [&](size_t i)
	{
		if (src_sbfs_coor1[i].feature_ != nullptr)
		{
			RegistrationPair tempPair;

			pcl::PointXYZ searchPt;
			searchPt.x = src_sbfs_coor1[i].numOfOneInGridFeature_;
			searchPt.y = src_sbfs_coor1[i].numOfOneInDensityComparisonFeature_;
			searchPt.z = src_sbfs_coor1[i].numOfOneInDistanceComparisonFeature_;

			vector<int> search_indices_coor1, search_indices_coor2, search_indices_coor3, search_indices_coor4;
			vector<float> distances_coor1, distances_coor2, distances_coor3, distances_coor4;
			vector<int>().swap(search_indices_coor1); vector<int>().swap(search_indices_coor2);
			vector<int>().swap(search_indices_coor3); vector<int>().swap(search_indices_coor4);

			vector<float>().swap(distances_coor1); vector<float>().swap(distances_coor2);
			vector<float>().swap(distances_coor3); vector<float>().swap(distances_coor4);

			tree_coor1.radiusSearch(searchPt, searchRadius, search_indices_coor1, distances_coor1);
			tree_coor2.radiusSearch(searchPt, searchRadius, search_indices_coor2, distances_coor2);

			vector<StereoBinaryFeature>  candidate_target_sbfs_coor1, candidate_target_sbfs_coor2;
			vector<StereoBinaryFeature>().swap(candidate_target_sbfs_coor1);
			vector<StereoBinaryFeature>().swap(candidate_target_sbfs_coor2);


			for (size_t n = 0; n < search_indices_coor1.size(); ++n)
			{
				candidate_target_sbfs_coor1.push_back(target_sbfs_coor1[search_indices_coor1[n]]);
			}

			for (size_t n = 0; n < search_indices_coor2.size(); ++n)
			{
				candidate_target_sbfs_coor2.push_back(target_sbfs_coor2[search_indices_coor2[n]]);
			}

			//计算src中的点testPointIndex在尺度i下target中的对应点对;
			if (FindOptimalFeaturePairBasedOnOneWayOptimal(i, src_sbfs_coor1, candidate_target_sbfs_coor1, candidate_target_sbfs_coor2, tempPair))
			{
				reg_pairs_f.push_back(tempPair);
			}
		}
	});

	pcl::PointCloud<pcl::PointXYZ>().swap(*pointCloud_coor1);
	pcl::PointCloud<pcl::PointXYZ>().swap(*pointCloud_coor2);

	return static_cast<bool>(reg_pairs_f.size());
}


/*判断是否满足几何约束一致性;*/
bool CRegistration::JudgeTheGeometricConsistency(vector<StereoBinaryFeature> & src_sbf, vector<StereoBinaryFeature> & target_sbfs,
												 concurrencyVectorRegistrationPair & reg_pair, int seed_id1, int seed_id2, int seed_id3,
												 int candidate_id)
{
	float dis_src = 0.0f;
	float dis_target = 0.0f;
	Eigen::Vector3f src_pt1, src_pt2, src_pt3, target_pt1, target_pt2, target_pt3, candidate_src_pt, candidate_target_pt;
	src_pt1 = src_sbf[reg_pair[seed_id1].src_id].localSystem_.origin;
	src_pt2 = src_sbf[reg_pair[seed_id2].src_id].localSystem_.origin;
	src_pt3 = src_sbf[reg_pair[seed_id3].src_id].localSystem_.origin;

	target_pt1 = target_sbfs[reg_pair[seed_id1].target_id].localSystem_.origin;
	target_pt2 = target_sbfs[reg_pair[seed_id2].target_id].localSystem_.origin;
	target_pt3 = target_sbfs[reg_pair[seed_id3].target_id].localSystem_.origin;

	candidate_src_pt = src_sbf[reg_pair[candidate_id].src_id].localSystem_.origin;
	candidate_target_pt = target_sbfs[reg_pair[candidate_id].target_id].localSystem_.origin;

	dis_src = Comput3DDistanceBetweenPoints(src_pt1, candidate_src_pt);
	dis_target = Comput3DDistanceBetweenPoints(target_pt1, candidate_target_pt);

	if (abs(dis_src - dis_target) > m_coRgopt.tolerantEuclideanDis)
	{
		return false;
	}

	dis_src = Comput3DDistanceBetweenPoints(src_pt2, candidate_src_pt);
	dis_target = Comput3DDistanceBetweenPoints(target_pt2, candidate_target_pt);

	if (abs(dis_src - dis_target) > m_coRgopt.tolerantEuclideanDis)
	{
		return false;
	}

	dis_src = Comput3DDistanceBetweenPoints(src_pt3, candidate_src_pt);
	dis_target = Comput3DDistanceBetweenPoints(target_pt3, candidate_target_pt);

    return abs(dis_src - dis_target) > m_coRgopt.tolerantEuclideanDis ? false : true;

}


/*判断三角形全等;*/
bool CRegistration::JudgeTriangleEquivalent(vector<StereoBinaryFeature> & src_sbf, vector<StereoBinaryFeature> & target_sbfs,
											concurrencyVectorRegistrationPair & reg_pairs, int id1, int id2, int id3)
{
	float dis_src = 0.0f, dis_target = 0.0f;

	dis_src = Comput3DDistanceBetweenPoints(src_sbf[reg_pairs[id1].src_id].localSystem_.origin, src_sbf[reg_pairs[id2].src_id].localSystem_.origin);
	dis_target = Comput3DDistanceBetweenPoints(target_sbfs[reg_pairs[id1].target_id].localSystem_.origin, target_sbfs[reg_pairs[id2].target_id].localSystem_.origin);

	if (abs(dis_src - dis_target) > m_coRgopt.tolerantEuclideanDis)
	{
		return false;
	}

	dis_src = Comput3DDistanceBetweenPoints(src_sbf[reg_pairs[id1].src_id].localSystem_.origin, src_sbf[reg_pairs[id3].src_id].localSystem_.origin);
	dis_target = Comput3DDistanceBetweenPoints(target_sbfs[reg_pairs[id1].target_id].localSystem_.origin, target_sbfs[reg_pairs[id3].target_id].localSystem_.origin);
	//cout<<setiosflags(ios::fixed)<<setprecision(3)<<abs(dis_src-dis_target)<<endl;
	if (abs(dis_src - dis_target) > m_coRgopt.tolerantEuclideanDis)
	{
		return false;
	}

	dis_src = Comput3DDistanceBetweenPoints(src_sbf[reg_pairs[id2].src_id].localSystem_.origin, src_sbf[reg_pairs[id3].src_id].localSystem_.origin);
	dis_target = Comput3DDistanceBetweenPoints(target_sbfs[reg_pairs[id2].target_id].localSystem_.origin, target_sbfs[reg_pairs[id3].target_id].localSystem_.origin);
	//cout<<setiosflags(ios::fixed)<<setprecision(3)<<abs(dis_src-dis_target)<<endl;
	if (abs(dis_src - dis_target) > m_coRgopt.tolerantEuclideanDis)
	{
		return false;
	}

	return true;
}


/*计算满足特征一致性的点集中，满足几何约束一致性的点对集合;*/
bool CRegistration::GeometricConsistencyClusterExhaustivity(vector<StereoBinaryFeature> & src_sbfs, vector<StereoBinaryFeature> & target_sbfs,
															concurrencyVectorRegistrationPair & reg_pairs_f,
															concurrencyVectorVectorRegistrationPair & reg_pairs_g)
{
	concurrencyVectorRegistrationPair temp_reg_pairs;
    concurrencyVectorRegistrationPair().swap(temp_reg_pairs);

	for (size_t i = 0; i < reg_pairs_f.size()-2; ++i)
	{
		for (size_t j = i + 1; j < reg_pairs_f.size() - 1; ++j)
		{
			for (size_t n = j + 1; n < reg_pairs_f.size(); ++n)
			{
				temp_reg_pairs.push_back(reg_pairs_f[i]);
				temp_reg_pairs.push_back(reg_pairs_f[j]);
				temp_reg_pairs.push_back(reg_pairs_f[n]);

				if (JudgeTriangleEquivalent(src_sbfs, target_sbfs, reg_pairs_f, i, j, n))
				{
					for (size_t k = 0; k < reg_pairs_f.size(); ++k)
					{
						if ((k != i) && (k != j) && (k != n))
						{
							bool IsGeometricConsistency;
							IsGeometricConsistency = JudgeTheGeometricConsistency(src_sbfs, target_sbfs, reg_pairs_f, i, j, n, k);
							if (IsGeometricConsistency)
							{
								temp_reg_pairs.push_back(reg_pairs_f[i]);
							}
						}
					}
					reg_pairs_g.push_back(temp_reg_pairs);
				}
				temp_reg_pairs.clear();
			}
		}
	}

    concurrencyVectorRegistrationPair().swap(temp_reg_pairs);

    return reg_pairs_g.empty() ? false : true;
}

/*计算满足几何约束一致性的点对集合;*/
bool CRegistration::GeometricConsistencyClusterRandom(vector<StereoBinaryFeature> & src_sbfs, vector<StereoBinaryFeature> & target_sbfs,
													  concurrencyVectorRegistrationPair & reg_pairs_f,
													  concurrencyVectorVectorRegistrationPair & reg_pairs_g)
{
	concurrencyVectorRegistrationPair temp_reg_pairs;
    concurrencyVectorRegistrationPair().swap(temp_reg_pairs);

	//计算RANSAC迭代的次数k=log(1-p)/log(1-w^n);
	float probability(0.05f);//内点的比例;
	float tolerance(0.995f);//希望得到的成功率;
	int n(3);//适用于模型的最少数据个数;
	long long k = 0;//需要的迭代次数;
	k = static_cast<long long int>(log10(1 - tolerance) / (log10(1 - pow(probability, n))));

	//遍历每个对应点,把每个对应点对分别作为几何一致性聚类的种子点进行聚类,选择点数最多的类作为最终聚类结果;
	int iteration_num = 0;
	vector<int> haveCheckedIndex1, haveCheckedIndex2, haveCheckedIndex3;
	long long pairSize = static_cast<long long int>(reg_pairs_f.size());
	pairSize = (pairSize*(pairSize - 1)*(pairSize - 2)) / 6;
	srand((unsigned)time(NULL));



	while (iteration_num < min(k, pairSize))
	{
		int testIndex1, testIndex2, testIndex3;

		bool haveChecked;
		do
		{
			haveChecked = false;

			testIndex1 = static_cast<int>(rand() % reg_pairs_f.size());
			testIndex2 = static_cast<int>(rand() % reg_pairs_f.size());
			testIndex3 = static_cast<int>(rand() % reg_pairs_f.size());

			if (haveCheckedIndex1.empty() == true)
			{
				haveChecked = false;
			}
			else
			{
				for (int n = 0; n < haveCheckedIndex1.size(); ++n)
				{
					if ((haveCheckedIndex1[n] == testIndex1) && (haveCheckedIndex2[n] == testIndex2) && (haveCheckedIndex3[n] == testIndex3))
					{
						haveChecked = true;
						break;
					}
				}
			}

		} while (haveChecked);

		haveCheckedIndex1.push_back(testIndex1);
		haveCheckedIndex2.push_back(testIndex2);
		haveCheckedIndex3.push_back(testIndex3);

		temp_reg_pairs.push_back(reg_pairs_f[testIndex1]);
		temp_reg_pairs.push_back(reg_pairs_f[testIndex2]);
		temp_reg_pairs.push_back(reg_pairs_f[testIndex3]);


		if (JudgeTriangleEquivalent(src_sbfs, target_sbfs, reg_pairs_f, testIndex1, testIndex2, testIndex3))
		{
			for (int i = 0; i < reg_pairs_f.size(); i++)
			{
				if ((i != testIndex1) && (i != testIndex2) && (i != testIndex3))
				{
					bool IsGeometricConsistency;
					IsGeometricConsistency = JudgeTheGeometricConsistency(src_sbfs, target_sbfs, reg_pairs_f, testIndex1, testIndex2, testIndex3, i);
					if (IsGeometricConsistency)
					{
						temp_reg_pairs.push_back(reg_pairs_f[i]);
					}
				}
			}
			reg_pairs_g.push_back(temp_reg_pairs);
		}

		temp_reg_pairs.clear();
		iteration_num++;
	}

    concurrencyVectorRegistrationPair().swap(temp_reg_pairs);

    return reg_pairs_g.empty() ? false : true;
}


//根据对应关系计算旋转平移矩阵;
void CRegistration::CalculateTransformationBasedOnCPoints(vector<StereoBinaryFeature> &src_sbfs, vector<StereoBinaryFeature> &target_sbfs, concurrencyVectorRegistrationPair & reg_pairs, Eigen::Matrix4f &targetToSrc)
{
	/*将src和target的特征的坐标轴的原点构建PointCloud;*/
	pointCloudXYZPtr cloud_src(new pointCloudXYZ());
	pointCloudXYZPtr cloud_target(new pointCloudXYZ());
	pcl::PointXYZ pt;
	for (int i = 0; i < src_sbfs.size(); i++)
	{
		pt.x = src_sbfs[i].localSystem_.origin.x();
		pt.y = src_sbfs[i].localSystem_.origin.y();
		pt.z = src_sbfs[i].localSystem_.origin.z();
		cloud_src->points.push_back(pt);
	}

	for (int i = 0; i < target_sbfs.size(); i++)
	{
		pt.x = target_sbfs[i].localSystem_.origin.x();
		pt.y = target_sbfs[i].localSystem_.origin.y();
		pt.z =  target_sbfs[i].localSystem_.origin.z();
		cloud_target->points.push_back(pt);
	}

	/*根据reg_pairs创建对应关系correspondences;*/
	pcl::Correspondences  correspondences;
	pcl::Correspondence   correspondence;
	for (int i = 0; i < reg_pairs.size(); i++)
	{
		correspondence.index_match = static_cast<int>(reg_pairs[i].target_id);
		correspondence.index_query = static_cast<int>(reg_pairs[i].src_id);
		correspondences.push_back(correspondence);
	}

	//根据对应关系correspondences计算旋转平移矩阵;
	pcl::registration::TransformationEstimationSVD<pcl::PointXYZ, pcl::PointXYZ> trans_est;
	Eigen::Matrix4f trans;
	trans_est.estimateRigidTransformation(*cloud_src, *cloud_target, correspondences, trans);
	targetToSrc = trans.inverse();

	pointCloudXYZ().swap(*cloud_src);
	pointCloudXYZ().swap(*cloud_target);
}

//精配准;
double CRegistration::FineRegistration(pointCloudXYZIPtr cloud_src, pointCloudXYZIPtr cloud_target,
									   Eigen::Matrix4f &coarseTargetToSource, Eigen::Matrix4f &fineTargetToSource)
{
	Eigen::Vector3f  offset;
	double fitness_score = 0.0;
	//cloud_target根据targetToSource转换成了cloud_target_result,cloud_target_result为粗配准的结果;
	pointCloudXYZIPtr cloud_target_result(new pointCloudXYZI());

	pcl::transformPointCloud(*cloud_target, *cloud_target_result, coarseTargetToSource);
	fineTargetToSource = coarseTargetToSource;
	pointCloudXYZIPtr temp_cloud_src(new pointCloudXYZI());//用于存储读入的数据;
	pointCloudXYZIPtr temp_cloud_target(new pointCloudXYZI());//用于存储读入的数据;
	pointCloudXYZI reg_result;

	for (int i = 0; i < cloud_src->points.size(); i++)
	{
		temp_cloud_src->points.push_back(cloud_src->points[i]);
	}

	for (int i = 0; i < cloud_target_result->points.size(); i++)
	{
		temp_cloud_target->points.push_back(cloud_target_result->points[i]);
	}
	/*精配准*/
	pcl::IterativeClosestPoint<pcl::PointXYZI, pcl::PointXYZI> icp;//创建配准对象
	//创建旋转平移矩阵
	Eigen::Matrix4f Ti;

	double temp_euclideanFitnessEpsilon = m_reRgopt.euclideanFitnessEpsilon;
	double temp_transformationEpsilon = m_reRgopt.transformationEpsilon;
	double temp_maxCorrespondenceDistance = m_reRgopt.maxCorrespondenceDistance;
	while (temp_maxCorrespondenceDistance > 0.0)
	{
		icp.setEuclideanFitnessEpsilon(temp_euclideanFitnessEpsilon);//前后两次迭代最近点的都是距离变化值，小于该值认为已经收敛;
		icp.setTransformationEpsilon(temp_transformationEpsilon);//前后两次迭代旋转矩阵的差异阈值，小于该值认为已经收敛;
		icp.setMaximumIterations(m_reRgopt.maximumIterations);//设置迭代的最大次数
		icp.setMaxCorrespondenceDistance(temp_maxCorrespondenceDistance); //将两个对应关系之间的(src<->tgt)最大距离设置为50厘米，大于此值得点对不考虑。

		icp.setInputSource(temp_cloud_src);
		icp.setInputTarget(temp_cloud_target);

		//估计
		reg_result.points.clear();
		icp.align(reg_result);
		//在每个迭代之间累积源点云到目标点云转换矩阵Ti
		Ti = icp.getFinalTransformation();
		//得到从目标点云到源点云的变换
		Ti = Ti.inverse();
		fineTargetToSource = Ti*fineTargetToSource;
		pointCloudXYZI().swap(*temp_cloud_src);
		temp_cloud_src = reg_result.makeShared();
		temp_maxCorrespondenceDistance -= m_reRgopt.stepLength;
		temp_euclideanFitnessEpsilon /= m_reRgopt.stepError;
		temp_transformationEpsilon /= m_reRgopt.stepError;
	}

	fitness_score = icp.getFitnessScore();
	pointCloudXYZI().swap(*cloud_target_result);
	pointCloudXYZI().swap(*temp_cloud_src);
	pointCloudXYZI().swap(*temp_cloud_target);
	pointCloudXYZI().swap(reg_result);
	return fitness_score;
}

bool CRegistration::calculateCorrespondingKeypointNumber(concurrencyVectorRegistrationPair &reg_pairs_f,
														 vector<StereoBinaryFeature> &binaryShapeContextsPointCloudSrc,
														 vector<StereoBinaryFeature> &binaryShapeContextsPointCloudTarget,
														 unsigned int &trueCorrespondingNum)
{
	trueCorrespondingNum = 0;

	for (size_t i = 0; i < reg_pairs_f.size(); i++)
	{
		float dis, dertax, dertay, dertaz;
		dertax = binaryShapeContextsPointCloudSrc[reg_pairs_f[i].src_id].localSystem_.origin.x()
				 - binaryShapeContextsPointCloudTarget[reg_pairs_f[i].target_id].localSystem_.origin.x();

		dertay = binaryShapeContextsPointCloudSrc[reg_pairs_f[i].src_id].localSystem_.origin.y()
				 - binaryShapeContextsPointCloudTarget[reg_pairs_f[i].target_id].localSystem_.origin.y();

		dertaz = binaryShapeContextsPointCloudSrc[reg_pairs_f[i].src_id].localSystem_.origin.z()
				 - binaryShapeContextsPointCloudTarget[reg_pairs_f[i].target_id].localSystem_.origin.z();

		dis = sqrt(dertax*dertax + dertay*dertay + dertaz*dertaz);

		if (dis < m_coRgopt.tolerantEuclideanDis)
		{
			trueCorrespondingNum++;
		}
	}
	return static_cast<bool>(trueCorrespondingNum);
}


bool CRegistration::calculateCorrespondingKeypointsNumber(vector<StereoBinaryFeature> &binaryShapeContextsPointCloudSrc,
														  vector<StereoBinaryFeature> &binaryShapeContextsPointCloudTarget,
														  concurrencyVectorRegistrationPair &reg_pairs)
{
	RegistrationPair tempPair;

	if (binaryShapeContextsPointCloudTarget.empty() || binaryShapeContextsPointCloudSrc.empty())
	{
		return 0;
	}

	pointCloudXYZ srcPointCloud, tarPointCloud;
	for (size_t i = 0; i < binaryShapeContextsPointCloudSrc.size(); ++i)
	{
		pcl::PointXYZ pt;
		pt.x = binaryShapeContextsPointCloudSrc[i].localSystem_.origin.x();
		pt.y = binaryShapeContextsPointCloudSrc[i].localSystem_.origin.y();
		pt.z = binaryShapeContextsPointCloudSrc[i].localSystem_.origin.z();
		srcPointCloud.points.push_back(pt);
	}

	for (size_t i = 0; i < binaryShapeContextsPointCloudTarget.size(); ++i)
	{
		pcl::PointXYZ pt;
		pt.x = binaryShapeContextsPointCloudTarget[i].localSystem_.origin.x();
		pt.y = binaryShapeContextsPointCloudTarget[i].localSystem_.origin.y();
		pt.z = binaryShapeContextsPointCloudTarget[i].localSystem_.origin.z();
		tarPointCloud.points.push_back(pt);
	}


	pcl::ExtractIndices<pcl::PointXYZ> extract;

	pcl::KdTreeFLANN<pcl::PointXYZ> tree;
	tree.setInputCloud(tarPointCloud.makeShared());

	//邻域搜索所用变量
	vector<int> search_indices(1);
	vector<float> distances(1);

	for (size_t i = 0; i < srcPointCloud.points.size(); i++)
	{
        vector<int>().swap(search_indices);
        vector<float>().swap(distances);
		//搜索邻域

		unsigned int tempNum = 0;
		tempNum = static_cast<unsigned int>(tree.nearestKSearch(srcPointCloud.points[i], 1, search_indices, distances));
		if (1 == tempNum && sqrt(distances[0]) < m_coRgopt.tolerantEuclideanDis)
		{
			tempPair.src_id = i;
			tempPair.target_id = static_cast<size_t>(search_indices[0]);
			reg_pairs.push_back(tempPair);
		}
	}
	return static_cast<bool>(reg_pairs.size());
}

//zyc_10_17
bool CRegistration::PairwiseCoarseRegistrationBasedOnBsc(pointCloudXYZIPtr src_cloud, pointCloudXYZIPtr target_cloud,
														 vector<vector<StereoBinaryFeature>> &binaryShapeContextsPointCloudSrc,
														 vector<vector<StereoBinaryFeature>> &binaryShapeContextsPointCloudTarget,
														 unsigned int &CorrespondingPtNum,float &maxOverlap, Eigen::Matrix4f &coarse_transformation)
{
	//计算符合特征一致性的点对集合;
	concurrencyVectorRegistrationPair reg_pairs_f;//符合特征一致性的点对集合;
	CalculateFeatureConsistencyPointPairs(binaryShapeContextsPointCloudSrc[0],binaryShapeContextsPointCloudTarget[0],
										  binaryShapeContextsPointCloudTarget[1],reg_pairs_f);
	cout << "满足特征一致性点对数量:" << reg_pairs_f.size() << endl;
	//计算符合几何一致性的点对集合;
	concurrencyVectorVectorRegistrationPair reg_pairs_fg;//同时符合特征,几何一致性的点对集合;
	if (GeometricConsistencyClusterRandom(binaryShapeContextsPointCloudSrc[0],
										   binaryShapeContextsPointCloudTarget[0],
										   reg_pairs_f, reg_pairs_fg)==false)
	{
		cout << "满足几何一致性点对较少,配准失败！" << endl;
		return false;
	}

	//计算几何一致性集合配准后的重叠度;
	maxOverlap = calculateTransformationBasedOnMaxOverlap(src_cloud, target_cloud,
														  binaryShapeContextsPointCloudSrc, binaryShapeContextsPointCloudTarget,
														  reg_pairs_fg,coarse_transformation);

	cout << "配准后的重叠度:" << setiosflags(ios::fixed) << setprecision(3) << maxOverlap << endl;
	/*cout << "------------------------------------------------------------------" << endl;*/
    concurrencyVectorRegistrationPair().swap(reg_pairs_f);
    concurrencyVectorVectorRegistrationPair().swap(reg_pairs_fg);

	return true;
}


//评价描述子的描述性;
bool CRegistration::evaluateDescriptive(vector<vector<StereoBinaryFeature>> &binaryShapeContextsPointCloudSrc,
										vector<vector<StereoBinaryFeature>> &binaryShapeContextsPointCloudTarget,
										unsigned int &featureCorrespondingNum, unsigned int &trueCorrespondingNum)
{
	//计算符合特征一致性的点对集合;
	concurrencyVectorRegistrationPair reg_pairs_f;//符合特征一致性的点对集合;
	CalculateFeatureConsistencyPointPairs(binaryShapeContextsPointCloudSrc[0],
										  binaryShapeContextsPointCloudTarget[0],
										  binaryShapeContextsPointCloudTarget[1],
										  reg_pairs_f);

	cout << "满足特征一致性点对数量:" << reg_pairs_f.size() << endl;
	calculateCorrespondingKeypointNumber(reg_pairs_f, binaryShapeContextsPointCloudSrc[0],
										 binaryShapeContextsPointCloudTarget[0],trueCorrespondingNum);
	featureCorrespondingNum = reg_pairs_f.size();
	return true;
}


//评价描述子的鲁棒性;
bool CRegistration::evaluateRobust(vector<vector<StereoBinaryFeature>> &binaryShapeContextsPointCloudSrc,
								   vector<vector<StereoBinaryFeature>> &binaryShapeContextsPointCloudTarget)
{
	//利用相邻距离计算同名点对;
	concurrencyVectorRegistrationPair reg_pairs;
	calculateCorrespondingKeypointsNumber(binaryShapeContextsPointCloudSrc[0],binaryShapeContextsPointCloudTarget[0],reg_pairs);

	return true;
}

/*穷尽的两两配准;*/
bool CRegistration::ExhaustivePairWiseRegistration(std::vector<std::string> &fileNames,
												   tbb::concurrent_vector<pointCloudXYZI> &pointClouds,
												   vector<vector<vector<StereoBinaryFeature>>> &binaryShapeContextsPointClouds, Graph &graph)
{

	//遍历所有站，对所有站进行两两配准，找几何约束后配对的三角形个数最多的站作为基准站;
	tbb::parallel_for(size_t(0), fileNames.size()-1, [&](size_t i)
	{
		for (size_t j = i + 1; j < fileNames.size(); ++j)
		{
			Node src_node, target_node;
			Edge edge;
			unsigned int correspondingPtNum = 0;
			float maxOverlap = 0.0f;
			Eigen::Matrix4f coarse_transformation;
			PairwiseCoarseRegistrationBasedOnBsc(pointClouds[i].makeShared(), pointClouds[j].makeShared(),
												 binaryShapeContextsPointClouds[i], binaryShapeContextsPointClouds[j],
												 correspondingPtNum, maxOverlap, coarse_transformation);
			//给结点赋值;
			src_node.node_id = i;
			target_node.node_id = j;
			//给边赋值;
			edge.source_node_id = i;
			edge.target_node_id = j;
			edge.weightPtNum = correspondingPtNum;
			edge.weightOverlap = maxOverlap;
			edge.targetToSrc = coarse_transformation;


			//给图赋值;
			if (edge.weightOverlap > m_coRgopt.tolerantOverlap)
			{
				graph.edges.push_back(edge);
				graph.nodes.push_back(src_node);
				graph.nodes.push_back(target_node);

				pointCloudXYZI transformedPointCloud;
				pcl::transformPointCloud(pointClouds[j], transformedPointCloud, coarse_transformation);

				outputPairWiseRegistratedPointClouds(maxOverlap, fileNames[i], fileNames[j], pointClouds[i].makeShared(),
													 transformedPointCloud.makeShared());

				transformedPointCloud.points.clear();
			}
			else
			{
				cout << "重叠度太小。。。" << endl;
			}
		}
	});
	return graph.edges.size();
}

bool CRegistration::calculateTheMinSpanningTreeOfGraph(unsigned int nodesNum,  Graph &graph, Graph & min_st)
{
	//初始化结点nodes;
	vector<Node, Eigen::aligned_allocator<Node>> nodes;

	for (size_t i = 0; i < nodesNum; i++)
	{
		Node one_node;
		one_node.node_id = i;
		one_node.graph_id = i;//初始化每个结点拥有不同的graph_id;
		nodes.push_back(one_node);
	}

	//将边按照权值排序;
	sort(graph.edges.begin(), graph.edges.end(), CmpWeightOverlap);
	//依次遍历图中的每条边;
	for (size_t i = 0; i < graph.edges.size(); i++)
	{
		if (nodes[graph.edges[i].source_node_id].graph_id != nodes[graph.edges[i].target_node_id].graph_id)
		{
			min_st.edges.push_back(graph.edges[i]);
			//让结点的graph_id为source_node_graph_id和target_node_graph_id的结点保持相同的graph_id;
			int source_node_graph_id = nodes[graph.edges[i].source_node_id].graph_id;
			int target_node_graph_id = nodes[graph.edges[i].target_node_id].graph_id;
			nodes[graph.edges[i].source_node_id].children_node_ids.push_back(graph.edges[i].target_node_id);
			nodes[graph.edges[i].target_node_id].father_node_ids.push_back(graph.edges[i].source_node_id);

			for (size_t j = 0; j<nodesNum; j++)
			{
				if (nodes[j].graph_id == target_node_graph_id)
				{
					nodes[j].graph_id = source_node_graph_id;
				}
			}
		}

		//当最小生成树中边的个数等于nodes_num-1时，遍历结束;
		if (min_st.edges.size() > nodesNum - 2)
		{
			break;
		}
	}

	min_st.nodes = nodes;
	return nodes.size();
}



/*用精配准的转换矩阵更新最小生成树中各边的转换矩阵;*/
void CRegistration::refineTransformationOfMST(Graph & min_st, tbb::concurrent_vector<pointCloudXYZI> &pointClouds)
{
	//精配准graph.edges[i]连接的两个节点,更新两站之间的转换矩阵;
	for (size_t i = 0; i < min_st.edges.size(); ++i)
	{
		Eigen::Matrix4f fineTrans;
		FineRegistration(pointClouds[min_st.edges[i].source_node_id].makeShared(),
						 pointClouds[min_st.edges[i].target_node_id].makeShared(),
						 min_st.edges[i].targetToSrc, fineTrans);
		min_st.edges[i].targetToSrc = fineTrans;

		outputMatrix(fineTrans);
	}
}




bool  CRegistration::MultiviewMatchingBasedOnMST(std::vector<std::string> &fileNames, tbb::concurrent_vector<pointCloudXYZI> &pointClouds,
												 vector<vector<vector<StereoBinaryFeature>>> &binaryShapeContextsPointClouds,
												 tbb::concurrent_vector<pointCloudXYZI> &RegPointClouds)
{
	Graph graph;
	Eigen::MatrixXf similarMatrix;
	ExhaustivePairWiseRegistration(fileNames, pointClouds, binaryShapeContextsPointClouds, graph);

	Graph  min_spt;
	calculateTheMinSpanningTreeOfGraph(pointClouds.size(), graph, min_spt);

	/*用精配准的转换矩阵更新最小生成树中各边的转换矩阵;*/
	refineTransformationOfMST(min_spt, pointClouds);

	int baseStationId = 0;
	baseStationId = calculateTheBaseStationBasedOnNodeDegree(min_spt);


	cout << "基准站为：" << fileNames[baseStationId] << endl;

	for (size_t i = 0; i < pointClouds.size(); ++i)
	{
		if (i == baseStationId)
		{
			RegPointClouds[i] = pointClouds[i];
		}
		else
		{
			if (min_spt.nodes[i].father_node_ids.empty()
				&& min_spt.nodes[i].children_node_ids.empty())
			{
				cout << "点云" << fileNames[i] << "和其它站之间重叠度较小,无法完成配准！" << endl;
			}
			else
			{
				//计算每一站跟基准站之间的路径和转换矩阵;
				Path regPath;
				Eigen::Matrix4f target_to_base;
				if (findRegistrationPathBetweenBaseAndTarget(min_spt, baseStationId, i, regPath))
				{
					pointCloudXYZI regPointCloud;
					calculateTransformationBetweenBaseAndTarget(regPath, min_spt, target_to_base);
					pcl::transformPointCloud(pointClouds[i], regPointCloud, target_to_base);
					RegPointClouds[i] = regPointCloud;
				}
				else
				{
					cout << fileNames[i] << endl;
				}
			}
		}
	}
	return true;
}

/*根据结点的度确定基准站;*/
int CRegistration::calculateTheBaseStationBasedOnNodeDegree(Graph & min_st)
{
	int base_station_id = 0;
	int max_node_degree = 0;

	for (int i = 0; i < min_st.nodes.size(); i++)
	{
		int node_degree = 0;
		int father_node_degree;
		int children_node_degree;

		if (min_st.nodes[i].father_node_ids.empty())
		{
			father_node_degree = 0;
		}
		else
		{
			father_node_degree = min_st.nodes[i].father_node_ids.size();
		}

		if (min_st.nodes[i].children_node_ids.empty())
		{
			children_node_degree = 0;
		}
		else
		{
			children_node_degree = min_st.nodes[i].children_node_ids.size();
		}

		node_degree = father_node_degree + children_node_degree;

		if (node_degree > max_node_degree)
		{
			max_node_degree = node_degree;
			base_station_id = min_st.nodes[i].node_id;
		}
	}

	return base_station_id;
}

bool CRegistration::findRegistrationPathBetweenBaseAndTarget(Graph& min_st, int base_id, int target_id, Path &target_to_base_path)
{
	Path registration_path;
	//初始化最小生成树中的nodes为未访问;
	for (int i = 0; i < min_st.nodes.size(); i++)
	{
		min_st.nodes[i].has_visited = false;
	}

	PathNode node;
	node.node_id = target_id;
	node.is_valid = true;
	node.has_used = false;
	registration_path.node_ids.push_back(node);//将初始结点放入路径中;
	min_st.nodes[target_id].has_visited = true;//将初始结点标记为已经访问过;

	int current_node_id = min_st.nodes.size();//当前结点的id;
	int children_node_id = min_st.nodes.size();//当前结点的孩子结点的id;
	int father_node_id = min_st.nodes.size();//当前结点的父亲结点的id;
	bool allNodesIsUnvalid;

	do
	{
		bool has_unvisited_nodes = false;//用来标记该节点是否有未访问的相邻结点;
		int current_path_id;
		//种子点后进先出的深度优先搜索;
		for (int k = registration_path.node_ids.size() - 1; k > -1; k--)
		{
			if (registration_path.node_ids[k].is_valid == true)
			{
				current_node_id = registration_path.node_ids[k].node_id;//把路径中最后加入的未被访问的结点作为当前结点;
				current_path_id = k;//保留当前路径点的id;
				registration_path.node_ids[current_path_id].has_used = true;
				break;
			}

		}
		//遍历当前结点的所有父亲结点;
		for (int i = 0; i < min_st.nodes[current_node_id].father_node_ids.size(); i++)
		{
			father_node_id = min_st.nodes[current_node_id].father_node_ids[i];//当前结点的父亲结点的id;
			if (min_st.nodes[father_node_id].has_visited == false)//当前结点的父亲结点未被访问;
			{
				min_st.nodes[father_node_id].has_visited = true;//当前结点的父亲结点被被标记为“已经访问”;
				node.node_id = father_node_id;
				node.is_valid = true;
				node.has_used = false;
				registration_path.node_ids.push_back(node);//当前结点的父亲结点压入到路径集合中;
				has_unvisited_nodes = true;//当前结点有未被访问的父亲结点;
				if (father_node_id == base_id)
				{
					//保留registration_path中有效的结点;
					for (int j = 0; j < registration_path.node_ids.size(); j++)
					{
						if (registration_path.node_ids[j].is_valid == true
							&& (registration_path.node_ids[j].has_used == true || registration_path.node_ids[j].node_id == base_id))
						{
							target_to_base_path.node_ids.push_back(registration_path.node_ids[j]);
						}
					}
					return target_to_base_path.node_ids.size();
				}
			}
		}

		//遍历当前结点的所有孩子结点;
		for (int i = 0; i < min_st.nodes[current_node_id].children_node_ids.size(); i++)
		{
			children_node_id = min_st.nodes[current_node_id].children_node_ids[i];//当前结点的父亲结点的id;
			if (min_st.nodes[children_node_id].has_visited == false)//当前结点的父亲结点未被访问;
			{
				min_st.nodes[children_node_id].has_visited = true;//当前结点的父亲结点被被标记为“已经访问”;
				node.node_id = children_node_id;
				node.is_valid = true;
				node.has_used = false;
				registration_path.node_ids.push_back(node);//当前结点的孩子结点压入到路径集合中;
				has_unvisited_nodes = true;//当前结点有未被访问的父亲结点;
				if (children_node_id == base_id)
				{
					//保留registration_path中有效的结点;
					for (int j = 0; j < registration_path.node_ids.size(); j++)
					{
						if (registration_path.node_ids[j].is_valid == true
							&& (registration_path.node_ids[j].has_used == true || registration_path.node_ids[j].node_id == base_id))
						{
							target_to_base_path.node_ids.push_back(registration_path.node_ids[j]);
						}
					}
					return target_to_base_path.node_ids.size();
				}
			}
		}
		//如果当前结点没有未被访问的父亲和孩子结点,则从路径path中删除该结点;
		if (has_unvisited_nodes == false)
		{
			registration_path.node_ids[current_path_id].is_valid = false;
		}

		//判断是否存在有效的node;
		allNodesIsUnvalid = true;
		for (size_t k = 0; k <registration_path.node_ids.size(); ++k)
		{
			if (registration_path.node_ids[k].is_valid)
			{
				allNodesIsUnvalid = false;
				break;
			}
		}

	} while ((father_node_id != base_id) && (children_node_id != base_id) && (allNodesIsUnvalid == false));

	return target_to_base_path.node_ids.size();
}


void CRegistration::calculateTransformationBetweenBaseAndTarget(Path target_to_base_path, Graph &min_st, Eigen::Matrix4f & target_to_base)
{
	target_to_base = Eigen::Matrix4f::Identity(4, 4);//初始化为单位阵;

	for (int i = 0; i<target_to_base_path.node_ids.size() - 1; i++)
	{
		int source_node_id;
		int target_node_id;
		if (target_to_base_path.node_ids[i].node_id>target_to_base_path.node_ids[i + 1].node_id)
		{
			source_node_id = target_to_base_path.node_ids[i + 1].node_id;
			target_node_id = target_to_base_path.node_ids[i].node_id;
			for (int j = 0; j < min_st.edges.size(); j++)
			{
				if (min_st.edges[j].source_node_id == source_node_id
					&&min_st.edges[j].target_node_id == target_node_id)
				{
					target_to_base = min_st.edges[j].targetToSrc*target_to_base;
					min_st.edges[j].is_node_id_convert = true;//新增;
					break;
				}
			}
		}
		else
		{
			source_node_id = target_to_base_path.node_ids[i].node_id;
			target_node_id = target_to_base_path.node_ids[i + 1].node_id;
			for (int j = 0; j < min_st.edges.size(); j++)
			{
				if (min_st.edges[j].source_node_id == source_node_id
					&&min_st.edges[j].target_node_id == target_node_id)
				{
					target_to_base = min_st.edges[j].targetToSrc.inverse()*target_to_base;
					break;
				}
			}
		}
	}
}


void CRegistration::outputPairWiseRegistratedPointClouds(float overlap, const string & fileName1, const string & fileName2,
														 pointCloudXYZIPtr pointCloud1, pointCloudXYZIPtr pointCloud2)
{
	std::string folderName;
	folderName = "ExhaustivePairWiseRegistrationResult";
	//创建文件夹;
	if (!boost::filesystem::exists(folderName))
	{
		boost::filesystem::create_directory(folderName);
	}

	//将对应点的个数转换成字符串;
	string overlapString;
	strstream sstr;
	sstr << overlap;
	sstr >> overlapString;

	//获取不包含路径和后缀的文件名;
	std::string fileStem1, fileStem2;
	boost::filesystem::path dir1(fileName1);
	boost::filesystem::path dir2(fileName2);

	fileStem1 = dir1.stem().string();
	fileStem2 = dir2.stem().string();

	string  outputFileName;
	outputFileName = folderName + "\\" + overlapString + "_" + fileStem1 + "_" + fileStem2 + "_reg.las";

	pointCloudBound bound;
	getCloudBound(*pointCloud1, bound);

	std::ofstream ofs;
	ofs.open(outputFileName, std::ios::out | std::ios::binary);
	if (ofs.is_open())
	{
		liblas::Header header;
		header.SetDataFormatId(liblas::ePointFormat2);
		header.SetVersionMajor(1);
		header.SetVersionMinor(2);
		header.SetMin(bound.minx, bound.miny, bound.minz);
		header.SetMax(bound.maxx, bound.maxy, bound.maxz);
		header.SetOffset((bound.minx + bound.maxx) / 2.0, (bound.miny + bound.maxy) / 2.0, (bound.minz + bound.maxz) / 2.0);
		header.SetScale(0.000001, 0.000001, 0.0001);
		header.SetPointRecordsCount(pointCloud1->points.size() + pointCloud2->points.size());

		liblas::Writer writer(ofs, header);
		liblas::Point pt(&header);

		for (int i = 0; i < pointCloud1->points.size(); i++)
		{
			pt.SetCoordinates(pointCloud1->points[i].x,pointCloud1->points[i].y,pointCloud1->points[i].z);
			pt.SetIntensity(pointCloud1->points[i].intensity);
			pt.SetColor(liblas::Color(0, 255, 0));
			writer.WritePoint(pt);
		}

		for (int i = 0; i < pointCloud2->points.size(); i++)
		{
			pt.SetCoordinates(pointCloud2->points[i].x,pointCloud2->points[i].y,pointCloud2->points[i].z);
			pt.SetIntensity(pointCloud2->points[i].intensity);
			pt.SetColor(liblas::Color(255, 0, 0));
			writer.WritePoint(pt);
		}

		ofs.flush();
		ofs.close();
	}
}


void CRegistration::outputMatrix(float overlap, const string & fileName1, const string & fileName2, const Eigen::Matrix4f &transformation)
{

	std::string folderName;
	folderName = "TransformaMatrix";
	//创建文件夹;
	if (!boost::filesystem::exists(folderName))
	{
		boost::filesystem::create_directory(folderName);
	}

	//将对应点的个数转换成字符串;
	string overlapString;
	strstream sstr;
	sstr << overlap;
	sstr >> overlapString;

	//获取不包含路径和后缀的文件名;
	std::string fileStem1, fileStem2;
	boost::filesystem::path dir1(fileName1);
	boost::filesystem::path dir2(fileName2);

	fileStem1 = dir1.stem().string();
	fileStem2 = dir2.stem().string();

	string  outputFileName;
	outputFileName = folderName + "\\" + overlapString + "_" + fileStem1 + "_" + fileStem2 + "_matrix.txt";
	ofstream ofs(outputFileName);
	for (size_t i = 0; i < 4; ++i)
	{
		for (size_t j = 0; j < 4; ++j)
		{
			ofs << setiosflags(ios::fixed) << setprecision(3) << transformation(i, j) << " ";
		}
		ofs << endl;
	}

}


void CRegistration::outputMatrix(const Eigen::Matrix4f &transformation)
{
	std::string folderName;
	folderName = "TransformaMatrix";
	//创建文件夹;
	if (!boost::filesystem::exists(folderName))
	{
		boost::filesystem::create_directory(folderName);
	}

	std::string outputFileName = folderName + "/_matrix.txt";

	ofstream ofs(outputFileName);
	for (size_t i = 0; i < 4; ++i)
	{
		for (size_t j = 0; j < 4; ++j)
		{
			ofs << setiosflags(ios::fixed) << setprecision(3) << transformation(i, j) << " ";
		}
		ofs << endl;
	}
}

void CRegistration::outputMultiviewRegistrationPointClouds(const std::vector<std::string> &fileNames, tbb::concurrent_vector<pointCloudXYZI> &regPointClouds)
{
	srand((unsigned)time(NULL));
	unsigned int R, G, B;
	std::string folderName;
	folderName = "MultiviewRegistrationResult";
	//创建文件夹;
	if (!boost::filesystem::exists(folderName))
	{
		boost::filesystem::create_directory(folderName);
	}

//	//获取不包含路径和后缀的文件名;
//	std::string fileStem;
//	for (size_t i = 0; i < fileNames.size();++i)
//	{
//		boost::filesystem::path dir(fileNames[i]);
//		fileStem = dir.stem().string();
//		string  outputFileName;
//		outputFileName = folderName + "\\" + fileStem+ "_reg.las";
//
//		R = rand() % 255;
//		G = rand() % 255;
//		B = rand() % 255;
//		liblas::Color lasColor (R, G, B);
//		writeLasFile(outputFileName, regPointClouds[i], lasColor);
//	}
	/*2017-10-7 tanzby*/
	//获取不包含路径和后缀的文件名;
	std::string fileStem;
	for (size_t i = 0; i < fileNames.size();++i)
	{
		boost::filesystem::path dir(fileNames[i]);
		fileStem = dir.stem().string();
		string  outputFileName;
		outputFileName = folderName + "/" + fileStem+ "_reg.pcd";

		writePcdFile(outputFileName,regPointClouds[i]);
	}
}


float CRegistration::calculateOverlapOfTwoPointClouds(pointCloudXYZIPtr pointCloud1, pointCloudXYZIPtr pointCloud2)
{
	unsigned int correspondingPtNum = 0;
	float overlap = 0.0f;

	pcl::KdTreeFLANN<pcl::PointXYZI> tree;
	tree.setInputCloud(pointCloud1);

	//邻域搜索所用变量
	vector<int> search_indices(1);
	vector<float> distances(1);

	for (size_t i = 0; i < pointCloud2->points.size(); i++)
	{
        vector<int>().swap(search_indices);
        vector<float>().swap(distances);
		//搜索邻域
		int temp = 0;
		temp=tree.nearestKSearch(pointCloud2->points[i], 1, search_indices, distances);
		if (1 == temp && sqrt(distances[0]) < m_coRgopt.tolerantEuclideanDis)
		{
			correspondingPtNum++;
		}
	}

	overlap = (float)correspondingPtNum / (float)(std::min(pointCloud1->points.size(),pointCloud2->points.size()));

	return overlap;
}


float CRegistration::calculateOverlapOfTwoPointClouds(pointCloudXYZIPtr pointCloud1, pointCloudXYZIPtr pointCloud2,
													  const Eigen::Matrix4f &transformation, const float distanceT)
{
	unsigned int correspondingPtNum = 0;
	float overlap = 0.0f;

	pcl::KdTreeFLANN<pcl::PointXYZI> tree;
	tree.setInputCloud(pointCloud1);

	pointCloudXYZIPtr cloud_target_result(new pointCloudXYZI());

	pcl::transformPointCloud(*pointCloud2, *cloud_target_result, transformation);

	//邻域搜索所用变量
	vector<int> search_indices(1);
	vector<float> distances(1);

	for (size_t i = 0; i < cloud_target_result->points.size(); i++)
	{
        vector<int>().swap(search_indices);
        vector<float>().swap(distances);
		//搜索邻域
		int temp = 0;
		temp = tree.nearestKSearch(cloud_target_result->points[i], 1, search_indices, distances);
		if (1 == temp && sqrt(distances[0]) < distanceT)
		{
			correspondingPtNum++;
		}
	}

	overlap = 2.0*(float)correspondingPtNum / (float)(pointCloud1->points.size()+ pointCloud2->points.size());

	return overlap;
}

float CRegistration::calculateTransformationBasedOnMaxOverlap(pointCloudXYZIPtr pointCloud1, pointCloudXYZIPtr pointCloud2,
															  vector<vector<StereoBinaryFeature>> &binaryShapeContextsPointCloudSrc,
															  vector<vector<StereoBinaryFeature>> &binaryShapeContextsPointCloudTarget,
															  concurrencyVectorVectorRegistrationPair & reg_pairs_fg,
															  Eigen::Matrix4f &coarse_transformation)
{
	unsigned int regPairsNum = 1;
	if (reg_pairs_fg.size() < regPairsNum)
	{
		regPairsNum = reg_pairs_fg.size();
	}

	sort(reg_pairs_fg.begin(), reg_pairs_fg.end(), CmpRegPairNum);


	float maxOverlap = 0.0f;

	for (size_t i = 0; i < regPairsNum; ++i)
	{
		float overlap = 0.0f;
		Eigen::Matrix4f transformation;
		//利用符合几何一致性的点对计算转换矩阵,实现coarse registration;
		if (reg_pairs_fg[i].size()>3)
		{
			CalculateTransformationBasedOnCPoints(binaryShapeContextsPointCloudSrc[0], binaryShapeContextsPointCloudTarget[0],
												  reg_pairs_fg[i], transformation);

			pointCloudXYZI transformedPointCloud;
			pointCloudXYZI().swap(transformedPointCloud);

			pcl::transformPointCloud(*pointCloud2, transformedPointCloud, transformation);
			overlap = calculateOverlapOfTwoPointClouds(pointCloud1, transformedPointCloud.makeShared());
			//outputPairWiseRegistratedPointClouds(overlap, "0.las", "1.las", pointCloud1, transformedPointCloud.makeShared());
			cout << "满足几何一致性点对数量:" << reg_pairs_fg[i].size() << endl;

			if (overlap > maxOverlap)
			{
				maxOverlap = overlap;
				coarse_transformation = transformation;
			}
		}
	}

	return maxOverlap;
}


size_t CRegistration::calculateSeedPointCloudId(vector<vector<vector<StereoBinaryFeature>>> &binaryShapeContextsPointClouds)
{
	size_t seedPointCloudId = 0;
	unsigned int maxKeypointNum = 0;

	for (size_t i = 0; i < binaryShapeContextsPointClouds.size(); ++i)
	{
		if (binaryShapeContextsPointClouds[i][0].size() > maxKeypointNum)
		{
			maxKeypointNum = binaryShapeContextsPointClouds[i][0].size();
			seedPointCloudId = i;
		}
	}

	return seedPointCloudId;
}

void CRegistration::outPutTop5SimilarPC(const std::string &fileName, const Eigen::MatrixXf &matrixXf)
{
	std::ofstream ofs;
	ofs.open(fileName, std::ios::out);
	vector<IdSimilarity> vs;
	if (ofs.is_open())
	{
		for (size_t i = 0; i < matrixXf.rows(); ++i)
		{
			vs.clear();
			for (size_t j = 0; j < matrixXf.cols(); ++j)
			{
				IdSimilarity v;
				v.pcIndex = j;
				v.similarity = matrixXf(i, j);
				vs.push_back(v);
			}
			sort(vs.begin(), vs.end(), cmpSimilarity2);
			ofs << i + 1 << " ";
			for (size_t n = 1; n < vs.size(); ++n)
			{
				ofs << vs[n].pcIndex + 1 << " ";
				ofs << setiosflags(ios::fixed) << setprecision(3) << vs[n].similarity << " ";
			}
			ofs << endl;
		}
	}
	ofs.close();
    vector<IdSimilarity>().swap(vs);
}



/*2017-10-7  tanzby*/
#include <fstream>
ofstream pair_out("score.txt");
bool CRegistration::One2AllPairRegistration(std::vector<std::string> &fileNames,
											pointCloudXYZIPtr target,
											std::vector<std::vector<StereoBinaryFeature>> &binaryShapeContextsPointClouds_target,
											tbb::concurrent_vector<pointCloudXYZI> &pointClouds,
											std::vector<std::vector<std::vector<StereoBinaryFeature>>> &binaryShapeContextsPointClouds,
											int &most_similar_index) {
	int maxIndex=-1;
	float maxValue = 0;
    // tbb::concurrent_vector<float > Overlap(fileNames.size());

	// tbb::parallel_for(size_t(0), fileNames.size()-1, [&](size_t i)
	// {

	// 		unsigned int correspondingPtNum = 0;
	// 		float maxOverlap = 0.0f;
	// 		Eigen::Matrix4f coarse_transformation;
	// 		PairwiseCoarseRegistrationBasedOnBsc(target, pointClouds[i].makeShared(),
    //                                              binaryShapeContextsPointClouds_target, binaryShapeContextsPointClouds[i],
	// 											 correspondingPtNum, maxOverlap, coarse_transformation);
	// 		Overlap[i] = maxOverlap;
    //         cout <<fileNames[i]<<": "<<Overlap[i]<<endl;
	// 		pair_out <<fileNames[i]<<": "<<Overlap[i]<<endl;
	// });
	tbb::concurrent_vector<float > Overlap(fileNames.size());
	cout << fileNames.size() << endl;
	Lap Overlap_temp[1000];
	int temp_index = 0;
	for(int i=0;i< fileNames.size();i=i+10)
	{
			unsigned int correspondingPtNum = 0;
			float maxOverlap = 0.0f;
			Eigen::Matrix4f coarse_transformation;
			PairwiseCoarseRegistrationBasedOnBsc(target, pointClouds[i].makeShared(),
                                                 binaryShapeContextsPointClouds_target, binaryShapeContextsPointClouds[i],
												 correspondingPtNum, maxOverlap, coarse_transformation);
			Overlap[i] = maxOverlap;
            // cout <<fileNames[i]<<": "<<Overlap[i]<<endl;
			cout << fileNames[i] << endl;
			pair_out <<fileNames[i]<<": "<<Overlap[i]<<endl;
			Overlap_temp[temp_index].file = fileNames[i];
			Overlap_temp[temp_index].score = Overlap[i]; 
			Overlap_temp[temp_index].index = i;
			temp_index++;
	}
	//add by zyc_10_17
	sort(Overlap_temp,Overlap_temp+temp_index,compa);
	int start_index = Overlap_temp[0].index;
	int end_index = Overlap_temp[1].index;
	if(start_index > end_index)
	{
		int temp_index = start_index;
		start_index = end_index;
		end_index = temp_index;
		
	}
	for(int i=start_index;i<end_index;i++)
	{
		unsigned int correspondingPtNum = 0;
		float maxOverlap = 0.0f;
		Eigen::Matrix4f coarse_transformation;
		PairwiseCoarseRegistrationBasedOnBsc(target, pointClouds[i].makeShared(),
                                             binaryShapeContextsPointClouds_target, binaryShapeContextsPointClouds[i],
											 correspondingPtNum, maxOverlap, coarse_transformation);
		Overlap[i] = maxOverlap;
        // cout <<fileNames[i]<<": "<<Overlap[i]<<endl;
		cout << fileNames[i] << endl;
		pair_out <<fileNames[i]<<": "<<Overlap[i]<<endl;
	}
	for(int i=0;i<temp_index;i++)
	{
		cout << Overlap_temp[i].file << " " << Overlap_temp[i].index << " " << Overlap_temp[i].score << endl;
	}

	for(int i = 0;i < fileNames.size(); i++)
	{
		if(maxValue<Overlap[i])
		{
			maxIndex = i;
			maxValue = Overlap[i];
		}
	}
	most_similar_index = maxIndex;
	cout <<"最相近的："<< fileNames[most_similar_index]<<endl;

	return TRUE;
}
