#include <init/dataIo.h>
#include <init/utility.h>

#include <string>
#include <fstream>
#include <vector>
#include <algorithm>
#include <liblas/liblas.hpp>
#include <liblas/version.hpp>
#include <liblas/point.hpp>

using namespace  std;
using namespace  boost::filesystem;
using namespace  utility;

bool compa(string a,string b)
{
	if(a > b) return 1;
	else return 0;
}
bool DataIo::batchReadFileNamesInFolders(const string &folderName, const string & extension,vector<string> &fileNames)
{
	vector<string> fileNames_1;
	//利用boost遍历文件夹内的文件;
	if (!exists(folderName))
	{
		return 0;
	}
	else
	{
		//遍历该文件夹下的所有ply文件,并保存到fileNames中;
		directory_iterator end_iter;
		for (directory_iterator iter(folderName); iter != end_iter; ++iter)
		{
			if (is_regular_file(iter->status()))
			{
				string fileName;
				fileName = iter->path().string();

				path dir(fileName);

				if (!dir.extension().string().empty())
				{
					if (!fileName.substr(fileName.rfind('.')).compare(extension))
					{
						fileNames_1.push_back(fileName);
					}
				}
			}
		}
	}
	int length = fileNames_1.size();
	for(int i=0;i<length;i++)
	{
		char path[1000];
		sprintf(path,"%s%d.pcd",folderName.c_str(),i);
		string new_path;
		new_path = path;
		fileNames.push_back(new_path);
	}
	return 1;
}

bool DataIo::batchReadFileNamesInFoldersAndSubFolders(const std::string &folderName,//文件夹路径;
													  const std::string & extension,//目标文件的扩展名;
													  std::vector<std::string> &fileNames)//所有目标文件的路径+文件名+扩展名;
{
	boost::filesystem::path  fullpath(folderName);

	if (!exists(fullpath))
	{
		return false;
	}

	recursive_directory_iterator end_iter;
	for (recursive_directory_iterator iter(fullpath); iter != end_iter; iter++)
	{
		try
		{
			if (is_directory(*iter))
			{
			}
			else
			{
				std::string sFileName = iter->path().string();
				path dir(sFileName);

				if (!dir.extension().string().empty())
				{
					if (!sFileName.substr(sFileName.rfind('.')).compare(extension))
					{
						fileNames.push_back(sFileName);
					}
				}

			}
		}
		catch (const std::exception & ex)
		{
			std::cerr << ex.what() << std::endl;
			continue;
		}
	}
	return true;
}

bool DataIo::writeLasFile(const std::string &fileName, pcl::PointCloud<pcl::PointXYZI> &pointCloud)
{
	pointCloudBound bound;
	getCloudBound(pointCloud, bound);

	ofstream ofs;
	ofs.open(fileName, std::ios::out | std::ios::binary);
	if (ofs.is_open())
	{
		liblas::Header header;
		header.SetDataFormatId(liblas::ePointFormat2);
		header.SetVersionMajor(1);
		header.SetVersionMinor(2);
		header.SetMin(bound.minx, bound.miny, bound.minz);
		header.SetMax(bound.maxx, bound.maxy, bound.maxz);
		header.SetOffset((bound.minx + bound.maxx) / 2.0, (bound.miny + bound.maxy) / 2.0, (bound.minz + bound.maxz) / 2.0);

		header.SetScale(0.0000001, 0.0000001, 0.0000001);
		header.SetPointRecordsCount(pointCloud.points.size());

		liblas::Writer writer(ofs, header);
		liblas::Point pt(&header);

		for (int i = 0; i < pointCloud.points.size(); i++)
		{
			pt.SetCoordinates(pointCloud.points[i].x, pointCloud.points[i].y, pointCloud.points[i].z);
			pt.SetIntensity(pointCloud.points[i].intensity);
			writer.WritePoint(pt);
		}
		ofs.flush();
		ofs.close();
	}

	return 1;
}

bool DataIo::writeLasFile(const std::string &fileName, pcl::PointCloud<pcl::PointXYZI> &pointCloud, liblas::Color lasColor)
{
	pointCloudBound bound;
	getCloudBound(pointCloud, bound);

	ofstream ofs;
	ofs.open(fileName, std::ios::out | std::ios::binary);
	if (ofs.is_open())
	{
		liblas::Header header;
		header.SetDataFormatId(liblas::ePointFormat2);
		header.SetVersionMajor(1);
		header.SetVersionMinor(2);
		header.SetMin(bound.minx, bound.miny, bound.minz);
		header.SetMax(bound.maxx, bound.maxy, bound.maxz);
		header.SetOffset((bound.minx + bound.maxx) / 2.0, (bound.miny + bound.maxy) / 2.0, (bound.minz + bound.maxz) / 2.0);

		header.SetScale(0.0000001, 0.0000001, 0.0000001);

		header.SetPointRecordsCount(pointCloud.points.size());

		liblas::Writer writer(ofs, header);
		liblas::Point pt(&header);

		for (int i = 0; i < pointCloud.points.size(); i++)
		{
			pt.SetCoordinates((double)pointCloud.points[i].x, (double)pointCloud.points[i].y, (double)pointCloud.points[i].z);
			pt.SetIntensity(pointCloud.points[i].intensity);
			pt.SetColor(lasColor);
			writer.WritePoint(pt);
		}
		ofs.flush();
		ofs.close();
	}

	return 1;
}


bool DataIo::writeLasFile(const std::string &fileName, pcl::PointCloud<pcl::PointXYZRGB> &pointCloud)
{
	pointCloudBound bound;
	getCloudBound(pointCloud, bound);

	ofstream ofs;
	ofs.open(fileName, std::ios::out | std::ios::binary);
	if (ofs.is_open())
	{
		liblas::Header header;
		header.SetDataFormatId(liblas::ePointFormat2);
		header.SetVersionMajor(1);
		header.SetVersionMinor(2);
		header.SetMin(bound.minx, bound.miny, bound.minz);
		header.SetMax(bound.maxx, bound.maxy, bound.maxz);
		header.SetOffset((bound.minx + bound.maxx) / 2.0, (bound.miny + bound.maxy) / 2.0, (bound.minz + bound.maxz) / 2.0);

		header.SetScale(0.0000001, 0.0000001, 0.0000001);
		header.SetPointRecordsCount(pointCloud.points.size());

		liblas::Writer writer(ofs, header);
		liblas::Point pt(&header);

		for (int i = 0; i < pointCloud.points.size(); i++)
		{
			if (bound.maxx < 10.0&&bound.maxy < 10.0&&bound.maxz < 10.0)
			{
				pt.SetCoordinates((double)(pointCloud.points[i].x*1000.0),
								  (double)(pointCloud.points[i].y*1000.0),
								  (double)(pointCloud.points[i].z*1000.0));
			}
			else
			{
				pt.SetCoordinates((double)pointCloud.points[i].x, (double)pointCloud.points[i].y,
								  (double)pointCloud.points[i].z);
			}

			uint8_t red = pointCloud.points[i].r;
			uint8_t green = pointCloud.points[i].g;
			uint8_t blue = pointCloud.points[i].b;
			pt.SetColor(liblas::Color(red, green, blue));
			writer.WritePoint(pt);
		}
		ofs.flush();
		ofs.close();
	}

	return 1;
}


bool DataIo::batchWriteLasFile(const std::string &folderName, const std::vector<std::string> &fileNames,
							   std::vector<pcl::PointCloud<pcl::PointXYZI>> &pointClouds)
{
	path folderPath(folderName);

	//创建文件夹;
	if (!exists(folderName))
	{
		create_directory(folderName);
	}

	if (fileNames.empty())
	{
		return 0;
	}
	else
	{
		for (size_t i = 0; i < fileNames.size(); ++i)
		{
			path dir(fileNames[i]);
			string fileName;
			//获取不包含路径和后缀的文件名;
			fileName = dir.stem().string();
			fileName = folderName + "\\" + fileName + ".las";
			writeLasFile(fileName, pointClouds[i]);
		}
	}

	return 1;
}

bool DataIo::batchWriteLasFile(const std::string &folderName, const std::vector<std::string> &fileNames,
							   std::vector<pcl::PointCloud<pcl::PointXYZRGB>> &pointClouds)
{
	path folderPath(folderName);

	//创建文件夹;
	if (!exists(folderName))
	{
		create_directory(folderName);
	}

	if (fileNames.empty())
	{
		return 0;
	}
	else
	{
		for (size_t i = 0; i < fileNames.size(); ++i)
		{
			path dir(fileNames[i]);
			string fileName;
			//获取不包含路径和后缀的文件名;
			fileName = dir.stem().string();
			fileName = folderName + "\\" + fileName + ".las";
			writeLasFile(fileName, pointClouds[i]);
		}
	}

	return 1;
}


bool DataIo::readLasFileHeader(const std::string &fileName, liblas::Header& header)
{
	if (fileName.substr(fileName.rfind('.')).compare(".las"))
	{
		return 0;
	}
	else
	{
		std::ifstream ifs;
		ifs.open(fileName, std::ios::in | std::ios::binary);
		if (ifs.bad())
		{
			return 0;
		}

		liblas::ReaderFactory f;
		liblas::Reader reader = f.CreateWithStream(ifs);

		header = reader.GetHeader();
	}

	return 1;
}


bool DataIo::mergeLasFileHeaders(const std::vector<liblas::Header>& headers, liblas::Header& mergeFileHeader)
{
	if (headers.empty())
	{
		return 0;
	}

	unsigned int ptNum = 0;

	pointCloudBound bounds;
	bounds.minx = headers[0].GetMinX(); bounds.maxx = headers[0].GetMaxX();
	bounds.miny = headers[0].GetMinY(); bounds.maxy = headers[0].GetMaxY();
	bounds.minz = headers[0].GetMinZ(); bounds.maxz = headers[0].GetMaxZ();

	for (size_t i = 0; i < headers.size(); ++i)
	{
		ptNum += headers[i].GetPointRecordsCount();
		if (headers[i].GetMinX() < bounds.minx)
		{
			bounds.minx = headers[i].GetMinX();
		}
		if (headers[i].GetMinY() < bounds.miny)
		{
			bounds.miny = headers[i].GetMinY();
		}
		if (headers[i].GetMinZ() < bounds.minz)
		{
			bounds.minz = headers[i].GetMinZ();
		}

		if (headers[i].GetMaxX() > bounds.maxx)
		{
			bounds.maxx = headers[i].GetMaxX();
		}
		if (headers[i].GetMaxY() > bounds.maxy)
		{
			bounds.maxy = headers[i].GetMaxY();
		}
		if (headers[i].GetMaxZ() > bounds.maxz)
		{
			bounds.maxz = headers[i].GetMaxZ();
		}
	}
	mergeFileHeader.SetDataFormatId(liblas::ePointFormat2);
	mergeFileHeader.SetVersionMajor(1);
	mergeFileHeader.SetVersionMinor(2);
	mergeFileHeader.SetMin(bounds.minx, bounds.miny, bounds.minz);
	mergeFileHeader.SetMax(bounds.maxx, bounds.maxy, bounds.maxz);
	mergeFileHeader.SetOffset((bounds.minx + bounds.maxx) / 2.0, (bounds.miny + bounds.maxy) / 2.0, (bounds.minz + bounds.maxz) / 2.0);
	mergeFileHeader.SetScale(0.0000001, 0.0000001, 0.0000001);
	mergeFileHeader.SetPointRecordsCount(ptNum);
	return 1;
}


bool DataIo::readLasFile(const std::string &fileName, pcl::PointCloud<pcl::PointXYZI> &pointCloud)
{
	if (fileName.substr(fileName.rfind('.')).compare(".las"))
	{
		return 0;
	}

	std::ifstream ifs;
	ifs.open(fileName, std::ios::in | std::ios::binary);
	if (ifs.bad())
	{
		cout << "未发现匹配项" << endl;
	}
	liblas::ReaderFactory f;
	liblas::Reader reader = f.CreateWithStream(ifs);

	/*while循环中遍历所有的点;*/
	while (reader.ReadNextPoint())
	{
		const liblas::Point& p = reader.GetPoint();
		pcl::PointXYZI  pt;
		/*将重心化后的坐标和强度值赋值给PCL中的点;*/
		double temp;
		pt.x = p.GetX();
		pt.y = p.GetY();
		pt.z = p.GetZ();
		pt.intensity = p.GetIntensity();
		pointCloud.points.push_back(pt);
	}

	return 1;
}


bool DataIo::mergeLasFilesIntensity(const std::string &folderName)
{
	//获取文件夹下的las文件名;
	vector<string> fileNames;
	string extension;
	extension = ".las";
	batchReadFileNamesInFolders(folderName, extension, fileNames);

	//读取所有las文件的文件头;
	vector<liblas::Header> headers;
	for (size_t i = 0; i < fileNames.size(); ++i)
	{
		liblas::Header header;
		readLasFileHeader(fileNames[i], header);
		headers.push_back(header);
	}

	//确定合并后的las文件的文件头;
	liblas::Header mergeFileHeader;
	mergeLasFileHeaders(headers, mergeFileHeader);

	string mergeFileName;
	mergeFileName = folderName + "//" + "mergedFileIntensity.las";

	std::ofstream ofs;
	ofs.open(mergeFileName, std::ios::out | std::ios::binary);
	if (!ofs.is_open())
	{
		return 0;
	}
	else
	{
		liblas::Writer writer(ofs, mergeFileHeader);
		liblas::Point pt(&mergeFileHeader);
		//依次读取文件夹中的las文件,并随机赋色;
		srand((unsigned)time(NULL));
		for (size_t i = 0; i < fileNames.size(); ++i)
		{
			pcl::PointCloud<pcl::PointXYZI> pointCloud;
			readLasFile(fileNames[i], pointCloud);
			for (int i = 0; i < pointCloud.points.size(); ++i)
			{
				pt.SetCoordinates((double)pointCloud.points[i].x, (double)pointCloud.points[i].y, (double)pointCloud.points[i].z);
				pt.SetIntensity(pointCloud.points[i].intensity);
				writer.WritePoint(pt);
			}
		}
		ofs.flush();
		ofs.close();
	}

	return 1;
}

bool DataIo::mergeLasFilesColoredByFile(const std::string &folderName)
{
	//获取文件夹下的las文件名;
	vector<string> fileNames;
	string extension;
	extension = ".las";
	batchReadFileNamesInFolders(folderName, extension, fileNames);

	//读取所有las文件的文件头;
	vector<liblas::Header> headers;
	for (size_t i = 0; i < fileNames.size(); ++i)
	{
		liblas::Header header;
		readLasFileHeader(fileNames[i], header);
		headers.push_back(header);
	}

	//确定合并后的las文件的文件头;
	liblas::Header mergeFileHeader;
	mergeLasFileHeaders(headers, mergeFileHeader);

	string mergeFileName;
	mergeFileName = folderName + "//" + "mergedFileColor.las";

	std::ofstream ofs;
	ofs.open(mergeFileName, std::ios::out | std::ios::binary);
	if (!ofs.is_open())
	{
		return 0;
	}
	else
	{
		liblas::Writer writer(ofs, mergeFileHeader);
		liblas::Point pt(&mergeFileHeader);
		//依次读取文件夹中的las文件,并随机赋色;
		srand((unsigned)time(NULL));
		unsigned int R, G, B;
		for (size_t i = 0; i < fileNames.size(); ++i)
		{
			R = rand() % 255;
			G = rand() % 255;
			B = rand() % 255;
			pcl::PointCloud<pcl::PointXYZI> pointCloud;
			readLasFile(fileNames[i], pointCloud);
			for (int i = 0; i < pointCloud.points.size(); ++i)
			{
				pt.SetCoordinates((double)pointCloud.points[i].x, (double)pointCloud.points[i].y, (double)pointCloud.points[i].z);
				pt.SetIntensity(pointCloud.points[i].intensity);
				pt.SetColor(liblas::Color(R, G, B));
				writer.WritePoint(pt);
			}
		}
		ofs.flush();
		ofs.close();
	}

	return 1;
}

bool DataIo::batchReadLasFile(const std::string &folderName,
							  std::vector<pcl::PointCloud<pcl::PointXYZI>> &pointClouds,
							  vector<string> &fileNames)
{
	string extension = ".las";
	batchReadFileNamesInFolders(folderName, extension, fileNames);

	pcl::PointCloud<pcl::PointXYZI> pointCloud;
	for (size_t i = 0; i < fileNames.size(); ++i)
	{
		pointCloud.points.clear();
		readLasFile(fileNames[i], pointCloud);
		if (!pointCloud.points.empty())
		{
			pointClouds.push_back(pointCloud);
		}
		else
		{
			cout << "点云" << fileNames[i] << "中没有点。" << endl;
			return 0;
		}
	}

	cout << "数据读取结束。" << endl;
	return 1;
}




// Pcd文件读写;

bool DataIo::readPcdFile(const std::string &fileName, pcl::PointCloud<pcl::PointXYZI> &pointCloud)
{
    return pcl::io::loadPCDFile<pcl::PointXYZ> (fileName, dynamic_cast<pcl::PointCloud<pcl::PointXYZ> &>(pointCloud)) !=
           -1;
}

bool DataIo::batchReadPcdFile(const std::string &folderName,
                      std::vector<pcl::PointCloud<pcl::PointXYZI>> &pointClouds,
                      std::vector<std::string> &fileNames)
{
    string extension = ".pcd";
    batchReadFileNamesInFolders(folderName, extension, fileNames);

    pcl::PointCloud<pcl::PointXYZI> pointCloud;
    for (size_t i = 0; i < fileNames.size(); ++i)
    {
        pointCloud.points.clear();
        readPcdFile(fileNames[i], pointCloud);
        if (!pointCloud.points.empty())
        {
            pointClouds.push_back(pointCloud);
        }
        else
        {
            cout << "点云" << fileNames[i] << "中没有点。" << endl;
            return 0;
        }
    }
    cout << "数据读取结束。" << endl;
    return 1;
}

bool DataIo::writePcdFile(const std::string &fileName, pcl::PointCloud<pcl::PointXYZI> &pointCloud)
{
    return pcl::io::savePCDFileASCII (fileName, pointCloud) != -1;
}

//bool DataIo::writePcdFile(const std::string &fileName, pcl::PointCloud<pcl::PointXYZI> &pointCloud, liblas::Color lasColor)
//{
//    if(pcl::io::savePCDFileASCII (fileName, pointCloud)==-1)
//    {
//        return false;
//    }
//    else
//    {
//        return true;
//    }
//}

//bool DataIo::writePcdFile(const std::string &fileName, pcl::PointCloud<pcl::PointXYZRGB> &pointCloud)
//{
//    if(pcl::io::savePCDFileASCII (fileName, pointCloud)==-1)
//    {
//        return false;
//    }
//    else
//    {
//        return true;
//    }
//}


bool DataIo::batchWritePcdFile(const std::string &folderName, const std::vector<std::string> &fileNames,
                       std::vector<pcl::PointCloud<pcl::PointXYZI>> &pointClouds)
{
    path folderPath(folderName);

    //创建文件夹;
    if (!exists(folderName))
    {
        create_directory(folderName);
    }

    if (fileNames.empty())
    {
        return false;
    }
    else
    {
        for (size_t i = 0; i < fileNames.size(); ++i)
        {
            path dir(fileNames[i]);
            string fileName;
            //获取不包含路径和后缀的文件名;
            fileName = dir.stem().string();
            fileName = folderName + "\\" + fileName + ".pcd";
            writePcdFile(fileName, pointClouds[i]);
        }
    }

    return 1;
}

//bool DataIo::batchWritePcdFile(const std::string &folderName, const std::vector<std::string> &fileNames,
//                       std::vector<pcl::PointCloud<pcl::PointXYZRGB>> &pointClouds)
//{
//    this->batchWritePcdFile(folderName,fileNames,pointClouds);
//}

//bool mergePcdFileHeaders(const std::vector<liblas::Header>& header, liblas::Header& mergeFileHeader);
//
//bool mergePcdFilesColoredByFile(const std::string &folderName);
//
//bool mergePcdFilesIntensity(const std::string &folderName);