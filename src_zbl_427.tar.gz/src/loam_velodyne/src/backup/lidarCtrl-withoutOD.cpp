#include <opencv/cv.h>
#include <opencv/highgui.h>
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <pcl/registration/icp.h>
#include <pcl/point_cloud.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/kdtree/kdtree_flann.h>
#include <pcl/visualization/cloud_viewer.h>
#include <cstring>
#include <sensor_msgs/PointCloud2.h>
#include <Eigen/Dense>  
#include <boost/format.hpp>
#include <ros/ros.h>
#include <math.h>
#include <iostream>
#include <loam_velodyne/common.h>
#include <nav_msgs/Odometry.h>
#include <pcl_conversions/pcl_conversions.h>
#include <sensor_msgs/Imu.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_broadcaster.h>
#include <iomanip>
#include <fstream>
#include <loam_velodyne/LocalGeographicCS.hpp>
#include <loam_velodyne/Detect.h>
#include <loam_velodyne/getAngle.h>
#include <sensor_msgs/Imu.h>
#include <sensor_msgs/NavSatFix.h>
#include <geometry_msgs/PoseStamped.h>

#include <loam_velodyne/serial.h>
#include <loam_velodyne/control_car.h>
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <string> 
#include <pthread.h>
#include "std_msgs/String.h"
#include "std_msgs/Int64.h"
#include "std_msgs/Int8.h"
#include <pthread.h>
#include <boost/lexical_cast.hpp>
#include <boost/thread/thread.hpp>
#include <ctime>
#include <time.h>
#include <unistd.h>

using namespace Eigen; 
using namespace std;
using namespace cv;

#define IS_AUTO 1

CarPara carpara;//小车参数变量
string ALL_MAP;//动态路径
double target_length = 1.0;//距离预瞄点的距离
double to_turn_dis = 0.2;//距离拐点的距离
//other ros topic
ros::Publisher down_send;
ros::Publisher mode_send;
ros::Publisher car_info_send;
ros::Publisher current_send;//current index send to location

ros::Subscriber subfinal;
ros::Subscriber sub_delay;
ros::Subscriber sub_map_data;

ros::Subscriber task_sub;
ros::Subscriber stop_sub;
ros::Subscriber sub_move;

bool new_path_rece = false;
bool new_move_order = false;
///////task point
double task_x,task_y,task_heading;
int is_arrive_task = 0;
double task_dis = 1000;
int task_index = 10000;
///////
int delay_end = 0;//sbg will send the msg to ctrl while the vo was ready
static int is_stop = 0;//后台发送stop指令
bool obstacle_stop = false;//超声波检测到障碍物并停止
double real_time_x,real_time_y,real_time_heading;//实时定位信息

vector<GPSPoint> all_map;//all map data

car cc;//车辆控制指令实例
double o1,o2,o3,o4,a1,a2,a3,a4;
double sm1,sm2,sm3,sm4;
int car_mode;

float a_mode = 0;
float a_speed = 0;
float a_angle = 0;

pthread_t id;//read info from the car and open a thread to send to other node
int i,ret;
////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////
/*******************************原地转弯************************************************/
int first_turn = 1;
int calculat_turn = 1;

int target_index = 0;
int turn_index = 0;
int current_index = 0;
double turn_dis = 0;//与最近拐点的最近距离
double last_turn_dis = 0;//上一次与拐点的最近距离
/**************************************************************************************/
void FinalHandler(const std_msgs::String::ConstPtr &msg)
{
  real_time_x = 0;
  real_time_y = 0;
  real_time_heading = 0;

  string moves = msg->data;
  stringstream stringin(moves);
  stringin>>setprecision(12)>>real_time_x>>real_time_y>>real_time_heading;
  real_time_heading = real_time_heading * 180.0 / 3.14159265;
}

void delay_Handler(const std_msgs::Int64::ConstPtr &msg){
  delay_end = msg->data;
  cout<<"delay_end: "<<delay_end<<endl;
}

void task_Handler(const std_msgs::String::ConstPtr &msg){

  task_x = 0;
  task_y = 0;

  string moves = msg->data;
  stringstream stringin(moves);
  stringin>>setprecision(12)>>task_x>>task_y;

  cout<<"任务点： "<<task_x<<" "<<task_y<<endl;
  cout<<"解除stop命令！"<<endl;
}

void stop_Handler(const std_msgs::Int8::ConstPtr &msg){
  is_stop = msg->data;
  cout<<"!!!!!!!!!!!!!!!!!!!!!"<<" "<<is_stop<<endl;
}

void map_Handler(const std_msgs::String::ConstPtr &msg){
  ALL_MAP = msg->data;
  cout<<"path have receive! ctrl"<<endl;

  decodePath(ALL_MAP,all_map);//解析规划路径
  cout<<"map size: "<<all_map.size()<<endl;

  for(int i=0; i<all_map.size(); i++){
    all_map[i].heading = all_map[i].heading * 180.0 / 3.14159265; 
  }

  ////////////edit by equal//////////////
  cout<<"now heading: "<<real_time_heading<<" map heading :"<<all_map[0].heading<<endl;

  if(fabs(fabs(real_time_heading) - fabs(all_map[0].heading)) > 70)
  {
      cout<<"first point have set turn point"<<endl;
      all_map[0].is_turn = 1;
  }
  //////////////////////////////////////

  new_path_rece = true;
}

void move_Handler(const std_msgs::String::ConstPtr &msg){
  string moves = msg->data;
  stringstream stringin(moves);
  stringin>>setprecision(12)>>a_mode>>a_angle>>a_speed;

  new_move_order = true;
}

void ctrl_init(ros::NodeHandle nh){
	  down_send = nh.advertise<std_msgs::String>("/odo_send",1000);

	  car_info_send = nh.advertise<std_msgs::String>("/car_info",100);

	  mode_send = nh.advertise<std_msgs::String>("chmod",5);

	  subfinal = nh.subscribe<std_msgs::String>("/final_data",1000,FinalHandler);

	  current_send = nh.advertise<std_msgs::Int64>("index_send",5);

	  sub_delay = nh.subscribe<std_msgs::Int64>("vo_time",50,delay_Handler);

	  task_sub = nh.subscribe<std_msgs::String>("/task_net",1000,task_Handler);
	  stop_sub = nh.subscribe<std_msgs::Int8>("stop_net",100,stop_Handler);
    sub_move = nh.subscribe<std_msgs::String>("/move_net",1000,move_Handler);//后台发送遥控指令

    sub_map_data = nh.subscribe<std_msgs::String>("/map_send",1000,map_Handler);
}
//////////////////////////////////////////////////////////////////////////////////
void send_mode_vo(double x,double y,double heading,int mode){
  string tmp,r;

  tmp.clear();r.clear();
  tmp = boost::lexical_cast<string>(x);
  r = tmp;

  tmp.clear();
  tmp = boost::lexical_cast<string>(y);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(heading);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(mode);
  r.append(" ").append(tmp);

  std_msgs::String msg;
  msg.data = r;
  mode_send.publish(msg);
}
void send_info_to(){
  string tmp,r;

  tmp.clear();r.clear();
  tmp = boost::lexical_cast<string>(o1);
  r = tmp;

  tmp.clear();
  tmp = boost::lexical_cast<string>(o2);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(o3);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(o4);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(a1);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(a2);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(a3);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(a4);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(car_mode);
  r.append(" ").append(tmp);

  std_msgs::String msg;
  msg.data = r;
  down_send.publish(msg);
}
void send_CarInfo_to(){
  stringstream ss;
  string tmp,r;
  //////////
  tmp.clear();r.clear();
  tmp = boost::lexical_cast<string>(cmode);
  r = tmp;

  tmp.clear();
  tmp = boost::lexical_cast<string>(cangle);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cspeed);
  r.append(" ").append(tmp);
  //////////
  tmp.clear();
  tmp = boost::lexical_cast<string>(cangle1);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cangle2);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cangle3);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cangle4);
  r.append(" ").append(tmp);
  //////////
  tmp.clear();
  tmp = boost::lexical_cast<string>(ccur_m1);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(ccur_m2);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(ccur_m3);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(ccur_m4);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cspeed_m1);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cspeed_m2);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cspeed_m3);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cspeed_m4);
  r.append(" ").append(tmp);
  //////////
  tmp.clear();
  tmp = boost::lexical_cast<string>(cpul_m1);
  r.append(" ").append(tmp);
  
  tmp.clear();
  tmp = boost::lexical_cast<string>(cpul_m2);
  r.append(" ").append(tmp);
  
  tmp.clear();
  tmp = boost::lexical_cast<string>(cpul_m3);
  r.append(" ").append(tmp);
  
  tmp.clear();
  tmp = boost::lexical_cast<string>(cpul_m4);
  r.append(" ").append(tmp);
  //////////
  tmp.clear();
  tmp = boost::lexical_cast<string>(cus1);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cus2);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cus3);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cus4);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cus5);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cus6);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cus7);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cus8);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cobstacle);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cdis_keep);
  r.append(" ").append(tmp);
  //////////
  for(int i=0;i<12;i++)
  {
    tmp.clear();
    tmp = boost::lexical_cast<string>(ccell[i]);
    r.append(" ").append(tmp);
  }
  //////////
  tmp.clear();
  tmp = boost::lexical_cast<string>(cmaxV);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cminV);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cmaxVP);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cminVP);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cVD);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cAV);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cTV);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cCC);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cDC);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cSOC);
  r.append(" ").append(tmp);
  //////////
  tmp.clear();
  tmp = boost::lexical_cast<string>(cTem1);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cTem2);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cTem3);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cTem4);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cTem5);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cTem6);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cmaxTem);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cminTem);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cavrTem);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cenvirTem);
  r.append(" ").append(tmp);
  ///////////
  tmp.clear();
  tmp = boost::lexical_cast<string>(cRc);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cWr);
  r.append(" ").append(tmp);
  //////////
  
  std_msgs::String msg;
  msg.data = r;
  //cout<<r<<endl;
  car_info_send.publish(msg);
}
void* getData(void* args)//get data from car and send 
{
    while(true){
      cc.DataReceive();
      o1 = cc.pul1_data;//四个里程计数据
      o2 = cc.pul2_data;
      o3 = cc.pul3_data;
      o4 = cc.pul4_data;

      a1 = cc.sv1_ac_data;
      a2 = cc.sv2_ac_data;
      a3 = cc.sv3_ac_data;
      a4 = cc.sv4_ac_data;

      sm1 = cc.m1_data;
      sm2 = cc.m2_data;
      sm3 = cc.m3_data;
      sm4 = cc.m4_data;

      car_mode = cc.mode_data;

      cmode = cc.mode_data;
      cangle = cc.angle_data;
      cspeed = cc.speed_data;

      cangle1 = cc.sv1_ang_data;
      cangle2 = cc.sv2_ang_data;
      cangle3 = cc.sv3_ang_data;
      cangle4 = cc.sv4_ang_data;

      ccur_m1 = cc.cur1_data;
      ccur_m2 = cc.cur2_data;
      ccur_m3 = cc.cur3_data;
      ccur_m4 = cc.cur4_data;
      cspeed_m1 = cc.m1_data;
      cspeed_m2 = cc.m2_data;
      cspeed_m3 = cc.m3_data;
      cspeed_m4 = cc.m4_data;

      cpul_m1 = cc.dis1_data;
      cpul_m2 = cc.dis2_data;
      cpul_m3 = cc.dis3_data;
      cpul_m4 = cc.dis4_data;

      cus1 = cc.us1_data;
      cus2 = cc.us2_data;
      cus3 = cc.us3_data;
      cus4 = cc.us4_data;
      cus5 = cc.us5_data;
      cus6 = cc.us6_data;
      cus7 = cc.us7_data;
      cus8 = cc.us8_data;
      cobstacle = cc.obstacle_data;
      cdis_keep = cc.dis_keep_data;

      ccell[0] = cc.cell1_data;
      ccell[1] = cc.cell2_data;
      ccell[2] = cc.cell3_data;
      ccell[3] = cc.cell4_data;
      ccell[4] = cc.cell5_data;
      ccell[5] = cc.cell6_data;
      ccell[6] = cc.cell7_data;
      ccell[7] = cc.cell8_data;
      ccell[8] = cc.cell9_data;
      ccell[9] = cc.cell10_data;
      ccell[10] = cc.cell11_data;
      ccell[11] = cc.cell12_data;

      cmaxV = cc.max_voltage_data;
      cminV = cc.min_voltage_data;
      cmaxVP = cc.max_voltage_pos_data;
      cminVP = cc.min_voltage_pos_data;
      cVD = cc.voltage_diff_data;
      cAV = cc.avg_voltage_data;
      cTV = cc.total_voltage_data;
      cCC = cc.charge_cur_data;
      cDC = cc.discharge_cur_data;
      cSOC = cc.soc_data;

      cTem1 = cc.temperature1_data;
      cTem2 = cc.temperature2_data;
      cTem3 = cc.temperature3_data;
      cTem4 = cc.temperature4_data;
      cTem5 = cc.temperature5_data;
      cTem6 = cc.temperature6_data;
      cmaxTem = cc.max_temp_data;
      cminTem = cc.min_temp_data;
      cavrTem = cc.avg_temp_data;
      cenvirTem = cc.envirmnt_temp_data;

      cRc = cc.Rc_data;
      cWr = cc.Wr_data;
      //cout<<"odo:"<<o1<<" "<<o2<<" "<<o3<<" "<<o4<<endl<<endl;
      send_info_to();
      send_CarInfo_to();
    }
}
//////////////////////////////////////////////////////////////////////////////////
int main(int argc, char** argv)
{
	  ros::init(argc, argv, "laserCtrl");
	  ros::NodeHandle nh;
	  DecodePara("/home/chen/sysuzyc/catkin_yf_lidar/src/loam_velodyne/carPara.ini",carpara);//"/home/shenrk/catkin_car/src/loam_velodyne/carPara.ini"

    int start_turn = carpara.start_turn;
    int end_turn = carpara.end_turn;

	  ctrl_init(nh);
	  ret = pthread_create(&id,NULL,getData,NULL);

    //cout<<carpara.map_file_name<<endl;

          float speed = 0.25;
	  double angle = 0;
	  int mode = 0;
	  int is_dirction = 0;//thr dirction of  turn

    ALL_MAP = "";

	  ros::Rate rate(15);
  	bool status = ros::ok();
  	while(status)
	  {
	    ros::spinOnce();

      if(new_move_order == false)//后台未发送遥控指令
      {
        if(ALL_MAP.compare("") != 0 && all_map.size() > 0)//已收到新的导航轨迹
        {
          //new_path_rece = false;
          int path_size = all_map.size();

          if(task_x == 0 && task_y == 0)
          {
            task_x = all_map[path_size-1].x;//任务点坐标
            task_y = all_map[path_size-1].y;
          }

          task_dis = length_two_points(real_time_x,real_time_y,task_x,task_y);//当前位置与任务点的距离
          
          // if(task_dis < 0.2 || is_stop == 1)//到达任务点或者后台发送停止指令
          // {
          //   //cout<<"task_dis: "<<task_dis<<endl;
          //   #ifdef IS_AUTO
          //   cc.GetInfo(0,0,0);
          //   #endif
          //   //ALL_MAP.clear();
          //   //all_map.clear();
          //   continue;
          // }

          if(obstacle_stop == false && delay_end == 201)//前方没有障碍物或者陀螺仪静态误差累计消除完成
          {

            GPSPoint s,target;

            s.x = real_time_x;
            s.y = real_time_y;    
            s.GaussX = real_time_x;
            s.GaussY = real_time_y;
            s.heading = real_time_heading;
            /*****************************************/
            for(int i = start_turn; i < all_map.size(); i++)
            {
              if(all_map[i].is_turn == 1 && all_map[i].is_finish_turn == 0)
              {
                end_turn = i;
                break;
              }
            }

            current_index = Current_index_Return(real_time_x,real_time_y,all_map,start_turn,end_turn);//搜索当前最近的index

            if(task_dis < 3.5)///zyc
            {
              task_index = Current_index_Return(task_x,task_y,all_map,start_turn,end_turn);
            }

            if(current_index > task_index || is_stop == 1)
            {
              //cout<<"current and task_index:"<<current_index<<" "<<task_index<<endl;
              #ifdef IS_AUTO
              cc.GetInfo(0,0,0);
              #endif
              task_index = 10000;
              continue;
            }

            std_msgs::Int64 msg;
            msg.data = current_index;
            current_send.publish(msg);
            /*****************************************/
            for(int i = current_index; i < all_map.size(); i++)
            {
              if(all_map[i].is_turn == 1 && all_map[i].is_finish_turn == 0)
              {
                turn_index = i; //最近拐点的index
                if(calculat_turn == 1)//计算与最近拐点的最小距离 turn_dis
                {
                  if(fabs(real_time_heading-180) < 40 || fabs(real_time_heading) < 40)
                  {
                    turn_dis = fabs(all_map[turn_index].y - real_time_y);
                  }else if(fabs(real_time_heading - 90) < 40 || fabs(real_time_heading + 90) < 40){
                    turn_dis = fabs(all_map[turn_index].x - real_time_x);
                  }else{
                    turn_dis = length_two_points(real_time_x,real_time_y,all_map[i].x,all_map[i].y);
                  }
                  last_turn_dis = turn_dis;
                }else{
                  turn_dis = last_turn_dis;
                }
                break;
              }
            }
            /*****************************************/
            for(int j = current_index + 1; j < all_map.size(); j++)//计算预瞄点
            {
              double t_dis = length_two_points(all_map[current_index].x,all_map[current_index].y,all_map[j].x,all_map[j].y);
              if(t_dis > target_length)
              {
                target_index = j;//预描点的index
                break;
              }
            }
            /*****************************************/
            if(turn_dis < to_turn_dis)//与拐点的距离小于阈值时开始原地转弯
            {
              send_mode_vo(real_time_x,real_time_y,real_time_heading,1);//通知里程计已经切换小车模式并停止航位推算
              if(first_turn == 1)
              {
                #ifdef IS_AUTO
                cc.GetInfo(1,0,0);
                #endif

                first_turn = 0;
                calculat_turn = 0;
                if(fabs(real_time_heading - all_map[turn_index].heading) > 180)
                {
                  is_dirction = all_map[turn_index].heading < real_time_heading;
                }
                else
                {
                  is_dirction = all_map[turn_index].heading > real_time_heading;
                }
                cout<<"first in turn  "<<" "<<real_time_heading<<" "<<all_map[turn_index].heading<<" "<<is_dirction<<endl<<endl;
              }
              else
              {
                if(fabs(real_time_heading - all_map[turn_index].heading) > 5)
                {
                  #ifdef IS_AUTO
                  cc.GetInfo(1, 0, is_dirction?-0.15:0.15);
                  #endif

                  continue;
                }
                else
                {
                  cout<<"final heading: "<<real_time_heading<<endl;
                  #ifdef IS_AUTO
                  cc.GetInfo(0,0,0);
                  #endif

                  calculat_turn = 1;
                  send_mode_vo(real_time_x,real_time_y,real_time_heading,0);
                  first_turn = 1; 
                  all_map[turn_index].is_finish_turn = 1;
                  start_turn = end_turn;
                }
              }
            }else{

              if(target_index > turn_index)
              {
                target_index = turn_index;
              }

              double Lx,Ly;

              target.x = all_map[target_index].x;
              target.y = all_map[target_index].y;

              target.GaussX = all_map[target_index].x;
              target.GaussY = all_map[target_index].y;

              WorldtoMap(s,target.GaussX,target.GaussY,Lx,Ly);
              target.LX = Lx;
              target.LY = Ly;

              target.heading = all_map[target_index].heading;
              angle = getAngle(-target.LX,target.LY);
              //cout<<"angle: "<<angle<<endl;
              #ifdef IS_AUTO
              cc.GetInfo(mode,angle,speed); 
              #endif
            }
            /*****************************************/
          }else{
            #ifdef IS_AUTO
            //cc.GetInfo(0,0,0);
            #endif
          }
        }else{
          // #ifdef IS_AUTO
          // cc.GetInfo(0,0,0);
          // #endif
        }
      }else{
        new_move_order = false;
        cc.GetInfo(a_mode,a_angle,a_speed);//发送遥控指令
        
        cout<<"send: "<<a_mode<<" "<<a_angle<<" "<<a_speed<<endl;
      }

      
	    status = ros::ok();
    	rate.sleep();
	  }

	  return 0;
}
