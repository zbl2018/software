#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <pcl/registration/icp.h>
#include <pcl/point_cloud.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/kdtree/kdtree_flann.h>
#include <pcl/visualization/cloud_viewer.h>
#include <cstring>
#include <sensor_msgs/PointCloud2.h>
#include <Eigen/Dense>  
#include <boost/format.hpp>
#include <ros/ros.h>
#include <math.h>
#include <iostream>
#include <loam_velodyne/common.h>
#include <nav_msgs/Odometry.h>
#include <pcl_conversions/pcl_conversions.h>
#include <sensor_msgs/Imu.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_broadcaster.h>
#include <iomanip>
#include <fstream>
#include <loam_velodyne/LocalGeographicCS.hpp>
#include <loam_velodyne/Detect.h>
#include <loam_velodyne/getAngle.h>
#include <sensor_msgs/Imu.h>
#include <sensor_msgs/NavSatFix.h>
#include <geometry_msgs/PoseStamped.h>

#include <loam_velodyne/serial.h>
#include <loam_velodyne/control_car.h>
#include <loam_velodyne/ModifyTargetPoint.hpp>
#include <loam_velodyne/SmTarPoi.hpp>                                                        

#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <string> 
#include <pthread.h>
#include "std_msgs/String.h"
#include "std_msgs/Int64.h"
#include "std_msgs/Int8.h"
#include <pthread.h>
#include <boost/lexical_cast.hpp>
#include <boost/thread/thread.hpp>
#include <ctime>
#include <time.h>
#include <unistd.h>
#include <exception> 

using namespace Eigen; 
using namespace std;

#define IS_AUTO 1

std::ofstream ctrl_log("/home/dky/catkin_lidar/src/loam_velodyne/output/ctrl_log.txt");

std::ofstream angle_log("/home/dky/catkin_lidar/src/loam_velodyne/output/angle_log.txt");

std::ofstream turnctrl_log("/home/dky/catkin_lidar/src/loam_velodyne/output/turnctrl_log.txt");

std::ofstream initctrl_log("/home/dky/catkin_lidar/src/loam_velodyne/output/initctrl_log.txt");
CarPara carpara;//小车参数变量
string ALL_MAP;//动态路径
double target_length = 1.5;//距离预瞄点的距离
double to_turn_dis = 0.2;//距离拐点的距离

int is_init_end = 0;

int is_car_start = 0;//车最开始启动的状态
//other ros topic
ros::Publisher down_send;
ros::Publisher mode_send;
ros::Publisher car_info_send;
ros::Publisher current_send;//current index send to location

ros::Publisher turn_end_pub;

ros::Publisher pub_v_a_mode;//send angle to sbg

ros::Subscriber subfinal;
ros::Subscriber sub_delay;
ros::Subscriber sub_map_data;

ros::Subscriber task_sub;
ros::Subscriber stop_sub;
ros::Subscriber sub_move;
ros::Subscriber sub_init_end;

ros::Subscriber obstacle_rev;//edit by equal obstacle
string obstacle_string;
vector<Point> obstacle_point;

///////////////////////
double end_pos_x = 0;
double end_pos_y = 0;
double end_dis = 0;
///////////////////////
int start_turn = 0;
int end_turn = 0;

bool new_path_rece = false;
bool new_move_order = false;
///////task point
double task_x,task_y,task_heading,task_speed;
int is_arrive_task = 0;
double task_dis = 1000;
int task_index = 10000;
///////
int delay_end = 0;//sbg will send the msg to ctrl while the vo was ready
static int is_stop = 0;//后台发送stop指令
bool obstacle_stop = false;//超声波检测到障碍物并停止
double real_time_x,real_time_y,real_time_heading;//实时定位信息

vector<GPSPoint> all_map;//all map data

car cc;//车辆控制指令实例
double o1,o2,o3,o4,a1,a2,a3,a4;
double sm1,sm2,sm3,sm4;
int car_mode;

float a_mode = 0;
float a_speed = 0;
float a_angle = 0;

pthread_t id;//read info from the car and open a thread to send to other node
int i,ret;
////////////////////////////////////////////////////////////////////////////////////////
// ofstream T("/home/chen/sysuzyc/catkin_yf_lidar/src/loam_velodyne/output/target.txt");
////////////////////////////////////////////////////////////////////////////////////////
/*******************************原地转弯************************************************/
int first_turn = 1;
int calculat_turn = 1;

int target_index = 0;
int turn_index = 0;
int current_index = 0;
double turn_dis = 0;//与最近拐点的最近距离
double last_turn_dis = 0;//上一次与拐点的最近距离

int is_can_turn = 0;

int is_all_init = 0;//the car init at the first

double delta_turn_angle = 0;
/**************************************************************************************/

void send_mode_vo(double x,double y,double heading,int mode){
  string tmp,r;

  tmp.clear();r.clear();
  tmp = boost::lexical_cast<string>(x);
  r = tmp;

  tmp.clear();
  tmp = boost::lexical_cast<string>(y);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(heading);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(mode);
  r.append(" ").append(tmp);

  std_msgs::String msg;
  msg.data = r;
  mode_send.publish(msg);
}
void FinalHandler(const std_msgs::String::ConstPtr &msg)
{
  real_time_x = 0;
  real_time_y = 0;
  real_time_heading = 0;

  string moves = msg->data;
  stringstream stringin(moves);
  stringin>>setprecision(12)>>real_time_x>>real_time_y>>real_time_heading;
  real_time_heading = real_time_heading * 180.0 / 3.14159265;
}

void delay_Handler(const std_msgs::Int64::ConstPtr &msg){
  delay_end = msg->data;
  cout<<"delay_end: "<<delay_end<<endl;
}

void Init_End_Handler(const std_msgs::Int8::ConstPtr &msg){
	is_init_end = msg->data;
	cout<<"location have init finish!"<<endl;
}

void task_Handler(const std_msgs::String::ConstPtr &msg){

  task_x = 0;
  task_y = 0;
  task_speed = 0.2;

  string moves = msg->data;
  stringstream stringin(moves);
  stringin>>setprecision(12)>>task_x>>task_y>>task_speed;

  cout<<"任务点： "<<task_x<<" "<<task_y<<" "<<task_speed<<endl;
  cout<<"解除stop命令！"<<endl;
}

void stop_Handler(const std_msgs::Int8::ConstPtr &msg){
  is_stop = msg->data;
  cout<<"!!!!!!!!!!!!!!!!!!!!!"<<" "<<is_stop<<endl;
}

void map_Handler(const std_msgs::String::ConstPtr &msg){

  ALL_MAP.clear();
  all_map.clear();

  start_turn = 0;
  end_turn = 0;
  is_stop = 0;
  task_index = 10000;
  turn_dis = 0;
  last_turn_dis = 0;

  

  task_x = 0;
  task_y = 0;

  ALL_MAP = msg->data;
  cout<<"path have receive! ctrl"<<endl;

  //send_mode_vo(real_time_x,real_time_y,real_time_heading,0);

  decodePath(ALL_MAP,all_map);//解析规划路径
  cout<<"map size: "<<all_map.size()<<endl;

  if(!all_map.empty()){
    cout<<"init angle: "<<all_map[0].heading<<endl;

    for(int i=0; i<all_map.size(); i++){
      all_map[i].heading = all_map[i].heading * 180.0 / 3.14159265; 
    }

    ////////////edit by equal//////////////
    cout<<"path first x: "<<all_map[0].x<<" y: "<<all_map[0].y<<endl;
    cout<<"now heading: "<<real_time_heading<<" map heading :"<<all_map[0].heading<<endl;

  //  if(fabs(real_time_heading - all_map[0].heading) > 70)
  //  {
  //      cout<<"first point have set turn point"<<endl;
  //      all_map[0].is_turn = 1;
  //  }
    all_map[0].is_turn = 1;
    all_map[all_map.size()-1].is_turn = 1;
    //////////////////////////////////////

    end_pos_x = all_map[all_map.size()-1].x;
    end_pos_y = all_map[all_map.size()-1].y;

    new_path_rece = true;
  }
}

void move_Handler(const std_msgs::String::ConstPtr &msg){

  string moves = msg->data;
  stringstream stringin(moves);
  stringin>>setprecision(12)>>a_mode>>a_angle>>a_speed;

  new_move_order = true;
}


////////////////////obstaclepoint//////////////////
void obstacle_Handler(const std_msgs::String::ConstPtr &msg){
  obstacle_string = "";
  obstacle_string = msg->data;

  stringstream ss(obstacle_string);
  string tmp_s;

  obstacle_point.clear();

  while(getline(ss,tmp_s,';')){
    Point newpoint;
    stringstream final_s(tmp_s);

    final_s>>setprecision(12)>>newpoint.x>>newpoint.y;
    obstacle_point.push_back(newpoint);
  }

}
///////////////////////////////////////////////////


void ctrl_init(ros::NodeHandle nh){
	down_send = nh.advertise<std_msgs::String>("/odo_send",1000);

	car_info_send = nh.advertise<std_msgs::String>("/car_info",100);

	mode_send = nh.advertise<std_msgs::String>("chmod",5);

	subfinal = nh.subscribe<std_msgs::String>("/final_data",1000,FinalHandler);

	current_send = nh.advertise<std_msgs::Int64>("index_send",5);

	sub_delay = nh.subscribe<std_msgs::Int64>("vo_time",50,delay_Handler);

	task_sub = nh.subscribe<std_msgs::String>("/task_net",1000,task_Handler);
	stop_sub = nh.subscribe<std_msgs::Int8>("stop_net",100,stop_Handler);
  sub_move = nh.subscribe<std_msgs::String>("/move_net",1000,move_Handler);//后台发送遥控指令

    sub_map_data = nh.subscribe<std_msgs::String>("/map_send",1000,map_Handler);

    obstacle_rev = nh.subscribe<std_msgs::String>("/obstacle_out",1000,obstacle_Handler);

    sub_init_end = nh.subscribe<std_msgs::Int8>("init_finish",5,Init_End_Handler);

    pub_v_a_mode = nh.advertise<std_msgs::String>("car_move_info",5);

    turn_end_pub = nh.advertise<std_msgs::Int8>("turn_finish",5);
}
//////////////////////////////////////////////////////////////////////////////////

void send_info_to(){
  string tmp,r;

  tmp.clear();r.clear();
  tmp = boost::lexical_cast<string>(o1);
  r = tmp;

  tmp.clear();
  tmp = boost::lexical_cast<string>(o2);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(o3);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(o4);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(a1);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(a2);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(a3);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(a4);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(car_mode);
  r.append(" ").append(tmp);

  std_msgs::String msg;
  msg.data = r;
  down_send.publish(msg);
}
void send_CarInfo_to(){
  stringstream ss;
  string tmp,r;
  //////////
  tmp.clear();r.clear();
  tmp = boost::lexical_cast<string>(cmode);
  r = tmp;

  tmp.clear();
  tmp = boost::lexical_cast<string>(cangle);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cspeed);
  r.append(" ").append(tmp);
  //////////
  tmp.clear();
  tmp = boost::lexical_cast<string>(cangle1);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cangle2);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cangle3);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cangle4);
  r.append(" ").append(tmp);
  //////////
  tmp.clear();
  tmp = boost::lexical_cast<string>(ccur_m1);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(ccur_m2);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(ccur_m3);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(ccur_m4);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cspeed_m1);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cspeed_m2);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cspeed_m3);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cspeed_m4);
  r.append(" ").append(tmp);
  //////////
  tmp.clear();
  tmp = boost::lexical_cast<string>(cpul_m1);
  r.append(" ").append(tmp);
  
  tmp.clear();
  tmp = boost::lexical_cast<string>(cpul_m2);
  r.append(" ").append(tmp);
  
  tmp.clear();
  tmp = boost::lexical_cast<string>(cpul_m3);
  r.append(" ").append(tmp);
  
  tmp.clear();
  tmp = boost::lexical_cast<string>(cpul_m4);
  r.append(" ").append(tmp);
  //////////
  tmp.clear();
  tmp = boost::lexical_cast<string>(cus1);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cus2);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cus3);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cus4);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cus5);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cus6);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cus7);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cus8);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cobstacle);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cdis_keep);
  r.append(" ").append(tmp);
  //////////
  for(int i=0;i<12;i++)
  {
    tmp.clear();
    tmp = boost::lexical_cast<string>(ccell[i]);
    r.append(" ").append(tmp);
  }
  //////////
  tmp.clear();
  tmp = boost::lexical_cast<string>(cmaxV);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cminV);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cmaxVP);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cminVP);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cVD);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cAV);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cTV);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cCC);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cDC);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cSOC);
  r.append(" ").append(tmp);
  //////////
  tmp.clear();
  tmp = boost::lexical_cast<string>(cTem1);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cTem2);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cTem3);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cTem4);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cTem5);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cTem6);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cmaxTem);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cminTem);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cavrTem);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cenvirTem);
  r.append(" ").append(tmp);
  ///////////
  tmp.clear();
  tmp = boost::lexical_cast<string>(cRc);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cWr);
  r.append(" ").append(tmp);
  //////////
  
  std_msgs::String msg;
  msg.data = r;
  //cout<<r<<endl;
  car_info_send.publish(msg);
}
void* getData(void* args)//get data from car and send 
{
    while(true){
      cc.DataReceive();
      o1 = cc.pul1_data;//四个里程计数据
      o2 = cc.pul2_data;
      o3 = cc.pul3_data;
      o4 = cc.pul4_data;

      a1 = cc.sv1_ac_data;
      a2 = cc.sv2_ac_data;
      a3 = cc.sv3_ac_data;
      a4 = cc.sv4_ac_data;

      sm1 = cc.m1_data;
      sm2 = cc.m2_data;
      sm3 = cc.m3_data;
      sm4 = cc.m4_data;

      car_mode = cc.mode_data;

      cmode = cc.mode_data;
      cangle = cc.angle_data;
      cspeed = cc.speed_data;

      cangle1 = cc.sv1_ang_data;
      cangle2 = cc.sv2_ang_data;
      cangle3 = cc.sv3_ang_data;
      cangle4 = cc.sv4_ang_data;

      ccur_m1 = cc.cur1_data;
      ccur_m2 = cc.cur2_data;
      ccur_m3 = cc.cur3_data;
      ccur_m4 = cc.cur4_data;
      cspeed_m1 = cc.m1_data;
      cspeed_m2 = cc.m2_data;
      cspeed_m3 = cc.m3_data;
      cspeed_m4 = cc.m4_data;

      cpul_m1 = cc.dis1_data;
      cpul_m2 = cc.dis2_data;
      cpul_m3 = cc.dis3_data;
      cpul_m4 = cc.dis4_data;

      cus1 = cc.us1_data;
      cus2 = cc.us2_data;
      cus3 = cc.us3_data;
      cus4 = cc.us4_data;
      cus5 = cc.us5_data;
      cus6 = cc.us6_data;
      cus7 = cc.us7_data;
      cus8 = cc.us8_data;
      cobstacle = cc.obstacle_data;
      cdis_keep = cc.dis_keep_data;

      ccell[0] = cc.cell1_data;
      ccell[1] = cc.cell2_data;
      ccell[2] = cc.cell3_data;
      ccell[3] = cc.cell4_data;
      ccell[4] = cc.cell5_data;
      ccell[5] = cc.cell6_data;
      ccell[6] = cc.cell7_data;
      ccell[7] = cc.cell8_data;
      ccell[8] = cc.cell9_data;
      ccell[9] = cc.cell10_data;
      ccell[10] = cc.cell11_data;
      ccell[11] = cc.cell12_data;

      cmaxV = cc.max_voltage_data;
      cminV = cc.min_voltage_data;
      cmaxVP = cc.max_voltage_pos_data;
      cminVP = cc.min_voltage_pos_data;
      cVD = cc.voltage_diff_data;
      cAV = cc.avg_voltage_data;
      cTV = cc.total_voltage_data;
      cCC = cc.charge_cur_data;
      cDC = cc.discharge_cur_data;
      cSOC = cc.soc_data;

      cTem1 = cc.temperature1_data;
      cTem2 = cc.temperature2_data;
      cTem3 = cc.temperature3_data;
      cTem4 = cc.temperature4_data;
      cTem5 = cc.temperature5_data;
      cTem6 = cc.temperature6_data;
      cmaxTem = cc.max_temp_data;
      cminTem = cc.min_temp_data;
      cavrTem = cc.avg_temp_data;
      cenvirTem = cc.envirmnt_temp_data;

      cRc = cc.Rc_data;
      cWr = cc.Wr_data;
      //cout<<"odo:"<<o1<<" "<<o2<<" "<<o3<<" "<<o4<<endl<<endl;
      send_info_to();
      send_CarInfo_to();
    }
}

//////////////////////////////////////////////////////////////////////////////////
int main(int argc, char** argv)
{
	  ros::init(argc, argv, "laserCtrl");
	  ros::NodeHandle nh;
	  DecodePara("/home/dky/catkin_lidar/src/loam_velodyne/carPara.ini",carpara);//"/home/shenrk/catkin_car/src/loam_velodyne/carPara.ini"

	  ctrl_init(nh);
	  ret = pthread_create(&id,NULL,getData,NULL);

    /*************cls ********************/
    Point tempt = {0,0};
    Point PointOfTarget;
    Detect Detection;
    int IsCrashed = 0;
    double CanCalculate = 1;
    obstacle_point.push_back(tempt);
    int one_end = 1;
    /***************end*******************/

    //cout<<carpara.map_file_name<<endl;

    float speed = 0.30;
    /****cls**/
    // float target_speed = 1.0;
    // float dis_now2mission = 0;
    // float NowTimeSpeed = (float)(cspeed_m3 + cspeed_m4) / 2 / 60.0 * 80.110613 / 100.0;

    /******/

	double angle = 0;
	int mode = 0;
	int is_dirction = 0;//thr dirction of  turn

  ALL_MAP = "";

	ros::Rate rate(15);
  	bool status = ros::ok();
  	while(status)
	  {
	    ros::spinOnce();

      // try
      // {
        if(new_move_order == false)//后台未发送遥控指令
        {
          if(!all_map.empty() && (all_map.size() > 15))//已收到新的导航轨迹 && is_init_end == 1
          {
            //new_path_rece = false;

            int path_size = all_map.size();

            if(task_x == 0 && task_y == 0)
            {
              task_x = all_map[path_size-1].x;//任务点坐标
              task_y = all_map[path_size-1].y;
            }

            task_dis = length_two_points(real_time_x,real_time_y,task_x,task_y);//当前位置与任务点的距离
            
            end_dis = length_two_points(real_time_x,real_time_y,end_pos_x,end_pos_y);

            

            if(obstacle_stop == false && delay_end == 201 && is_init_end == 1)//前方没有障碍物或者陀螺仪静态误差累计消除完成
            {

              GPSPoint s,target;

              s.x = real_time_x;
              s.y = real_time_y;    
              s.GaussX = real_time_x;
              s.GaussY = real_time_y;
              s.heading = real_time_heading;
              /*****************************************/
              for(int i = start_turn; i < all_map.size(); i++)
              {
                if(all_map[i].is_turn == 1 && all_map[i].is_finish_turn == 0)
                {
                  end_turn = i;
                  //cout<<"s & e: "<<start_turn<<" "<<end_turn<<endl;
                  break;
                }
              }

              current_index = Current_index_Return(real_time_x,real_time_y,all_map,start_turn,end_turn);//搜索当前最近的index

              if(task_dis < 1.5)///zyc
              {
                //cout<<"tx ty: "<<task_x<<" "<<task_y<<endl;
                task_index = Current_index_Return(task_x,task_y,all_map,start_turn,end_turn);
              }

              if(((current_index >= task_index)) || is_stop == 1)//current !=0 ? 
              {
                //cout<<"current and task_index:"<<current_index<<" "<<task_index<<" is_stop: "<<is_stop<<" tx ty: "<<task_x<<" "<<task_y<<endl;
                #ifdef IS_AUTO
                cc.GetInfo(0,0,0);
                #endif
                task_index = 10000;

              //   if(is_stop != 1)
              //   {
	            	// is_init_end = 0;
	            	// delay_end = 0;
              //   }
                //send_mode_vo(real_time_x,real_time_y,real_time_heading,1);
                if(one_end == 1)
                {
                	ctrl_log<<" "<<endl;
                	one_end=0;

                	cout<<"car have arrive and reset the parma"<<endl;
                }
                continue;
              }

              std_msgs::Int64 msg;
              msg.data = current_index;
              current_send.publish(msg);
              /*****************************************/
              for(int i = current_index; i < all_map.size(); i++)
              {
                if(all_map[i].is_turn == 1 && all_map[i].is_finish_turn == 0)
                {
                  turn_index = i; //最近拐点的index

                  //cout<<"turnindex "<<turn_index<<endl;
                  
                  if(calculat_turn == 1)//计算与最近拐点的最小距离 turn_dis
                  {
                    if(fabs(real_time_heading-180) < 40 || fabs(real_time_heading) < 40)
                    {
                      turn_dis = fabs(all_map[turn_index].y - real_time_y);
                    }else if(fabs(real_time_heading - 90) < 40 || fabs(real_time_heading + 90) < 40){
                      turn_dis = fabs(all_map[turn_index].x - real_time_x);
                    }else{
                      turn_dis = length_two_points(real_time_x,real_time_y,all_map[i].x,all_map[i].y);
                    }
                    last_turn_dis = turn_dis;
                  }else{
                    turn_dis = last_turn_dis;
                  }
                  break;
                }
              }
              
              
              SmTarPoi stp;
              stp.GetAllMap(all_map);
              target_index = stp.GetDataAndReturn(s,current_index,speed);
              /*****************************************/
              //cout<<"ctrl info: "<<turn_dis<<" "<<length_two_points(real_time_x,real_time_y,task_x,task_y)<<endl;

              if((turn_dis < to_turn_dis) && (current_index < task_index))//与拐点的距离小于阈值时开始原地转弯
              {
                //cout<<"turn dis: "<<turn_dis<<" c index: "<<current_index<<" t index: "<<task_index<<" x: "<<task_x<<" y: "<<task_y<<endl;
                send_mode_vo(real_time_x,real_time_y,real_time_heading,1);//通知里程计已经切换小车模式并停止航位推算

                int delta_angle_rh = (((int)real_time_heading) - ((int)all_map[turn_index].heading))%(360);

                if(first_turn == 1)
                {

                  
                  // if(delta_angle_rh > 6.0){//当前的heading和地图的目标heading的差小于2时不会旋转
                  //   #ifdef IS_AUTO
                  //   cc.GetInfo(1,0,0);
                  //   #endif
                  //   //is_can_turn = 1;
                  //   cout<<"delta_angle_rh : "<<delta_angle_rh<<" "<<real_time_heading<<" "<<all_map[turn_index].heading<<endl;

                  //   turnctrl_log<<setprecision(12)<<current_index<<" rh "<<real_time_heading<<" mh "<<all_map[turn_index].heading<<" ";
                  // }

                  first_turn = 0;
                  calculat_turn = 0;

                  if(fabs((real_time_heading) - (all_map[turn_index].heading)) > 150)
                  {
                    is_dirction = all_map[turn_index].heading < real_time_heading;
                  }
                  else
                  {
                    is_dirction = all_map[turn_index].heading > real_time_heading;
                  }

                  delta_turn_angle = fabs(fabs(real_time_heading) - fabs(all_map[turn_index].heading));

                  cout<<"first in turn  "<<" "<<real_time_heading<<" "<<all_map[turn_index].heading<<" "<<is_dirction<<endl<<endl;
                }
                else
                {
                  if(fabs((real_time_heading) - (all_map[turn_index].heading)) > 3.0)
                  {

                  	angle_log<<setprecision(12)<< ros::Time::now() << " " <<real_time_heading<<" "<<all_map[turn_index].heading<<endl;

                    #ifdef IS_AUTO
                    cc.GetInfo(1, 0, is_dirction?-0.10:0.10);
                    #endif

                    continue;
                  }
                  else
                  {
                    cout<<"final heading: "<<real_time_heading<<endl;

                    while(cmode != 0){
                    	#ifdef IS_AUTO
	                    cc.GetInfo(0,0,0);
	                    #endif
                    }

                    angle_log<<endl<<endl;

                    turnctrl_log<<setprecision(12)<<" fh "<<real_time_heading<<endl;

                    calculat_turn = 1;
                    send_mode_vo(real_time_x,real_time_y,real_time_heading,0);
                    first_turn = 1; 
                    all_map[turn_index].is_finish_turn = 1;
                    start_turn = end_turn;

                    bool is_car_stop = (cc.m1_data == 0)&&(cc.m2_data == 0)&&(cc.m3_data == 0)&&(cc.m4_data == 0);

                    initctrl_log<<new_path_rece<<" "<<is_all_init<<" "<<current_index<<" "<<all_map.size()-10<<endl;

                    if(new_path_rece == true && (is_all_init == 1) && (current_index < (all_map.size()-20)))//&& is_car_stop == true
                    {

                      std_msgs::Int8 msg;
                      msg.data = 1;
                      turn_end_pub.publish(msg);

                      is_init_end = 0;
	            	  delay_end = 0;

	            	  #ifdef IS_AUTO
                      cc.GetInfo(0,0,0);
                      #endif

                      cout<<"turn finish and notify the relocation "<<current_index<<" "<<all_map.size()-15<<endl;
                    }else{
	                  is_all_init = 1;
	                  new_path_rece = false;


	                  cout<<"the car have complete the first init "<<is_car_stop<<endl;
                    }

                    
                  }
                }//cls modified
              }else if(IsCrashed == 0 && car_mode == 0){

                if((turn_index - target_index) < 2)//target_index >= turn_index
                {
                  target_index = turn_index;
                }

                double Lx,Ly;

                target.x = all_map[target_index].x;
                target.y = all_map[target_index].y;

                target.GaussX = all_map[target_index].x;
                target.GaussY = all_map[target_index].y;

                ModifyTargetPoint mtp;
                //target = mtp.ModifiedTargetPoint(s,all_map.size()-1,all_map,target);
                if(turn_index > 3){
                	target = mtp.ModifiedTargetPoint(s,turn_index-2,all_map,target);
                }else{
                	target = mtp.ModifiedTargetPoint(s,turn_index,all_map,target);
                }

                WorldtoMap(s,target.GaussX,target.GaussY,Lx,Ly);
                target.LX = Lx;
                target.LY = Ly;
                /***********************遇障碍物停车********************************/
                PointOfTarget.x = Lx;
                PointOfTarget.y = Ly;

                Detection.GetData(PointOfTarget,obstacle_point);
                //IsCrashed = Detection.mode;
                IsCrashed = 0;

                if(IsCrashed == 1)
                {
                  cc.GetInfo(0,0,0);
                  continue;
                }
                /*****************************end**************************/

                target.heading = all_map[target_index].heading;
                angle = getAngle(-target.LX,target.LY);
                //cout<<"angle: "<<angle<<endl;
                ctrl_log<<setprecision(12)<<"LXY: "<<Lx<<" "<<Ly<<" rxy: "<<real_time_x<<" "<<real_time_y<<" "<<real_time_heading<<" txy: "<<all_map[target_index].x<<" "<<all_map[target_index].y<<" "<<all_map[target_index].heading<<" angle: "<<angle<<endl;
 			        	one_end = 1;
                #ifdef IS_AUTO

                cc.GetInfo(mode,angle,speed); 
                /***************************/
                string tmp,r;

                tmp.clear();r.clear();
                tmp = boost::lexical_cast<string>(mode);
                r = tmp;

                tmp.clear();
                tmp = boost::lexical_cast<string>(angle);
                r.append(" ").append(tmp);

                tmp.clear();
                tmp = boost::lexical_cast<string>(speed);
                r.append(" ").append(tmp);

                std_msgs::String msg;
                msg.data = r;
                pub_v_a_mode.publish(msg);

                /***************************/

                //cout<<start_turn<<" "<<end_turn<<" "<<"turn : "<<turn_dis<<" "<<turn_index<<" "<<current_index<<" "<<task_index<<" "<<is_stop<<endl;
                //cout<<"mode: "<<mode<<" angle: "<<angle<<" speed: "<<speed<<endl;
                #endif
              }//遇障碍停车的状态/****************遇到遇障碍****************************/
              else if(IsCrashed == 1)
              {
                /*********遇障碍停车***********/

                //send_mode_vo(real_time_x,real_time_y,real_time_heading,0);
                IsCrashed = 0;

                /*********end********/
              }
              /**************************end********************************/
              /*****************************************/
            }else{
              #ifdef IS_AUTO
              cc.GetInfo(0,0,0);
              #endif
            }
          }else{
          	#ifdef IS_AUTO
            cc.GetInfo(0,0,0);
            #endif
          
          }
        }else{
          new_move_order = false;
          cc.GetInfo(a_mode,a_angle,a_speed);//发送遥控指令
          
          cout<<"send: "<<a_mode<<" "<<a_angle<<" "<<a_speed<<endl;
        }
     
	    status = ros::ok();
    	rate.sleep();
	  }

	  return 0;
}