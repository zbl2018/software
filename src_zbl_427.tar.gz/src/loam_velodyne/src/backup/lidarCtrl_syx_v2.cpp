#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <pcl/registration/icp.h>
#include <pcl/point_cloud.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/kdtree/kdtree_flann.h>
#include <pcl/visualization/cloud_viewer.h>
#include <cstring>
#include <sensor_msgs/PointCloud2.h>
#include <Eigen/Dense>  
#include <boost/format.hpp>
#include <ros/ros.h>
#include <math.h>
#include <iostream>
#include <loam_velodyne/common.h>
#include <nav_msgs/Odometry.h>
#include <pcl_conversions/pcl_conversions.h>
#include <sensor_msgs/Imu.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_broadcaster.h>
#include <iomanip>
#include <fstream>
#include <loam_velodyne/LocalGeographicCS.hpp>
#include <loam_velodyne/Detect.h>
#include <loam_velodyne/getAngle.h>
#include <sensor_msgs/Imu.h>
#include <sensor_msgs/NavSatFix.h>
#include <geometry_msgs/PoseStamped.h>
#include <loam_velodyne/serial.h>
#include <loam_velodyne/Simulation.hpp>
#include <loam_velodyne/control_car.h>
#include <loam_velodyne/ModifyTargetPoint.hpp>
#include <loam_velodyne/SmTarPoi.hpp>                                                     
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <string> 
#include <pthread.h>
#include "std_msgs/String.h"
#include "std_msgs/Int64.h"
#include "std_msgs/Int8.h"
#include <pthread.h>
#include <boost/lexical_cast.hpp>
#include <boost/thread/thread.hpp>
#include <ctime>
#include <time.h>
#include <unistd.h>
#include <exception> 
#include <loam_velodyne/TurnWhichDirection.h>
#include <loam_velodyne/LORDeterminer.hpp>

#include <loam_velodyne/GLogHelper.h>
#include <loam_velodyne/SpeedSmooth.h>
#include <loam_velodyne/AngleBetweenLocationAndPath.h>
#include <glog/logging.h>

using namespace Eigen; 
using namespace std;

#define IS_AUTO 1

std::ofstream ctrl_log("/home/dky/catkin_lidar/src/loam_velodyne/output/ctrl_log.txt");
std::ofstream save_turn_info("/home/dky/catkin_lidar/src/loam_velodyne/output/turn_info.txt");
std::ofstream save_task_info("/home/dky/catkin_lidar/src/loam_velodyne/output/turn_task_info.txt");

std::ofstream angle_log("/home/dky/catkin_lidar/src/loam_velodyne/output/angle_log.txt");

std::ofstream turnctrl_log("/home/dky/catkin_lidar/src/loam_velodyne/output/turnctrl_log.txt");

std::ofstream initctrl_log("/home/dky/catkin_lidar/src/loam_velodyne/output/initctrl_log.txt");





CarPara carpara;//小车参数变量
string ALL_MAP("");//动态路径
double to_target_point_dis = 1.5;//距离预瞄点的距离
double to_turn_point_dis = 0.2;//距离拐点的距离
bool is_init_end = false;
float speed = 0.10; //小车直走速度
const float turning_speed = 0.1; // 小车转弯速度

bool is_turn_over = true;

//other ros topic
ros::Publisher down_send;
ros::Publisher mode_send;
ros::Publisher car_info_send;
ros::Publisher current_send;//current index send to location
ros::Publisher turn_end_pub;
ros::Publisher pub_v_a_mode;//send angle to sbg
ros::Publisher pub_car_arrive;
ros::Publisher pub_obstacle_replan;

ros::Subscriber subfinal;
ros::Subscriber sub_delay;
ros::Subscriber sub_map_data;
ros::Subscriber task_sub;
ros::Subscriber stop_sub;
ros::Subscriber sub_move;
ros::Subscriber sub_init_end;
ros::Subscriber obstacle_rev;//edit by equal obstacle
ros::Subscriber charge_recv;

string obstacle_string;
vector<Point> obstacle_point;
int is_obstacle_sent = 1;
bool new_map_have_recieved = false;

///////////////////////
double end_pos_x = 0;
double end_pos_y = 0;
double end_dis = 0;
///////////////////////
int start_turn = 0;
int end_turn = 0;

bool new_path_race = false;
bool CONTROLLER_ORDER_REV = false;

bool is_arrived = false;
int  is_arrived_sent = 1;

int is_finish_location = 1;

///////task point
double task_x,task_y,task_heading,task_speed;
double task_dis = 1000;
int task_index = 10000;

///////
int delay_end = 0;//sbg will send the msg to ctrl while the vo was ready
static int is_stop = 0;//后台发送stop指令
bool obstacle_stop = false;//超声波检测到障碍物并停止

//////////////自动充电///////////
static int is_charge = 0;
double charge_x = 7.0892252922100001;
double charge_y = 0;
bool charge_vo_send = true;
bool charge_turn_end = true;
bool charge_vo_sent = true;
///////////////////////////////

GPSPoint real_time_location;

vector<GPSPoint> all_map;//all map data

car cc;//车辆控制指令实例
double o1,o2,o3,o4,a1,a2,a3,a4;
double sm1,sm2,sm3,sm4;
int car_mode;

float a_mode = 0;
float a_speed = 0;
float a_angle = 0;

pthread_t id;//read info from the car and open a thread to send to other node
int i,ret;
////////////////////////////////////////////////////////////////////////////////////////
// ofstream T("/home/chen/sysuzyc/catkin_yf_lidar/src/loam_velodyne/output/target.txt");
////////////////////////////////////////////////////////////////////////////////////////
/*******************************原地转弯************************************************/
int first_turn = 1;
int calculat_turn = 1;
int target_index = 0;
int turn_index = 0;
int current_index = 0;
double turn_dis = 0;     //与最近拐点的最近距离
double last_turn_dis = 0;//上一次与拐点的最近距离
int is_can_turn = 0;
bool re_icp_location = 0; 
double delta_turn_angle = 0;

/**************************************************************************************/

void send_mode_vo(double x,double y,double heading,int mode){
  string tmp,r;

  tmp.clear();r.clear();
  tmp = boost::lexical_cast<string>(x);
  r = tmp;

  tmp.clear();
  tmp = boost::lexical_cast<string>(y);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(heading);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(mode);
  r.append(" ").append(tmp);

  std_msgs::String msg;
  msg.data = r;
  mode_send.publish(msg);
}


void FinalHandler(const std_msgs::String::ConstPtr &msg)
{
  double real_time_x = 0,real_time_y = 0,real_time_heading = 0;
  string moves = msg->data;
  stringstream stringin(moves);
  stringin>>setprecision(12)>>real_time_x>>real_time_y>>real_time_heading;
  real_time_heading = real_time_heading * 180.0 / 3.14159265;

  real_time_location.x = real_time_x;
  real_time_location.y = real_time_y;    
  real_time_location.GaussX = real_time_x;
  real_time_location.GaussY = real_time_y;
  real_time_location.heading = real_time_heading;
}


void delay_Handler(const std_msgs::Int64::ConstPtr &msg){
  delay_end = msg->data;
  cout<<"delay_end: "<<delay_end<<endl;
}


void Init_End_Handler(const std_msgs::Int8::ConstPtr &msg){
	is_init_end = msg->data;
	cout<<"location have init finish!"<<endl;
}


void task_Handler(const std_msgs::String::ConstPtr &msg){

  task_x = 0;
  task_y = 0;
  task_speed = 0.2;

  string moves = msg->data;
  stringstream stringin(moves);
  stringin>>setprecision(12)>>task_x>>task_y>>task_speed;

  cout<<"任务点： "<<task_x<<" "<<task_y<<" "<<task_speed<<endl;
  cout<<"解除stop命令！"<<endl;
}


void stop_Handler(const std_msgs::Int8::ConstPtr &msg){
  is_stop = msg->data;
  cout<<"!!!!!!!!!!!!!!!!!!!!!"<<" "<<is_stop<<endl;
}

void Charge_Handler(const std_msgs::Int8::ConstPtr &msg){
  is_charge = msg->data;
  cout<<"Charge!!!!"<<endl;
}


void map_Handler(const std_msgs::String::ConstPtr &msg){

  ALL_MAP.clear();
  all_map.clear();

  start_turn = 0;
  end_turn = 0;

  is_stop = 0;

  task_index = 10000;
  task_dis = 10;

  turn_dis = 0;
  turn_index = 0;
  last_turn_dis = 0;

  is_arrived = false;
  is_arrived_sent = 1;

  new_map_have_recieved = true;
  //is_obstacle_sent = 1;

  // task_x = 0;
  // task_y = 0;

  ALL_MAP = msg->data;
  cout<<"path have receive! ctrl"<<endl;

  //send_mode_vo(real_time_location.x,real_time_location.y,real_time_location.heading,0);

  decodePath(ALL_MAP,all_map);//解析规划路径
  

  if(!all_map.empty()){

  	cout<<"map size: "<<all_map.size()<<endl;

    cout<<"init angle: "<<all_map[0].heading<<endl;

    for(int i=0; i<all_map.size(); i++){
      all_map[i].heading = all_map[i].heading * 180.0 / 3.14159265; 
    }

    ////////////edit by equal//////////////
    cout<<"path first x: "<<all_map[0].x<<" y: "<<all_map[0].y<<endl;
    cout<<"now heading: "<<real_time_location.heading<<" map heading :"<<all_map[0].heading<<endl;

  //  if(fabs(real_time_heading - all_map[0].heading) > 70)
  //  {
  //      cout<<"first point have set turn point"<<endl;
  //      all_map[0].is_turn = 1;
  //  }
    all_map[0].is_turn = 1;
    all_map[all_map.size()-1].is_turn = 1;
    //////////////////////////////////////

    end_pos_x = all_map[all_map.size()-1].x;
    end_pos_y = all_map[all_map.size()-1].y;

    new_path_race = true;
  }
}


void move_Handler(const std_msgs::String::ConstPtr &msg){

  string moves = msg->data;
  stringstream stringin(moves);
  stringin>>setprecision(12)>>a_mode>>a_angle>>a_speed;
  CONTROLLER_ORDER_REV = true;
}


void obstacle_Handler(const std_msgs::String::ConstPtr &msg){
  obstacle_string = "";
  obstacle_string = msg->data;

  stringstream ss(obstacle_string);
  string tmp_s;

  obstacle_point.clear();

  while(getline(ss,tmp_s,';')){
    Point newpoint;
    stringstream final_s(tmp_s);

    final_s>>setprecision(12)>>newpoint.x>>newpoint.y;
    obstacle_point.push_back(newpoint);
  }
}


void ctrl_init(ros::NodeHandle nh){
	down_send = nh.advertise<std_msgs::String>("/odo_send",1000);

	car_info_send = nh.advertise<std_msgs::String>("/car_info",100);

	mode_send = nh.advertise<std_msgs::String>("chmod",5);

	subfinal = nh.subscribe<std_msgs::String>("/final_data",1000,FinalHandler);

	current_send = nh.advertise<std_msgs::Int64>("index_send",5);

	sub_delay = nh.subscribe<std_msgs::Int64>("vo_time",50,delay_Handler);

	task_sub = nh.subscribe<std_msgs::String>("/task_net",1000,task_Handler);
	stop_sub = nh.subscribe<std_msgs::Int8>("stop_net",100,stop_Handler);

    sub_move = nh.subscribe<std_msgs::String>("/move_net",1000,move_Handler);//后台发送遥控指令

    sub_map_data = nh.subscribe<std_msgs::String>("/map_send",1000,map_Handler);

    obstacle_rev = nh.subscribe<std_msgs::String>("/obstacle_out",1000,obstacle_Handler);

    charge_recv = nh.subscribe<std_msgs::Int8>("charge",5,Charge_Handler);

    sub_init_end = nh.subscribe<std_msgs::Int8>("init_finish",5,Init_End_Handler);

    pub_v_a_mode = nh.advertise<std_msgs::String>("car_move_info",5);

    turn_end_pub = nh.advertise<std_msgs::Int8>("turn_finish",5);

    pub_car_arrive = nh.advertise<std_msgs::Int8>("car_arrive",5);

    pub_obstacle_replan = nh.advertise<std_msgs::Int8>("obstacle_plan",5);
}


void send_info_to(){
  string tmp,r;

  tmp.clear();r.clear();
  tmp = boost::lexical_cast<string>(o1);
  r = tmp;

  tmp.clear();
  tmp = boost::lexical_cast<string>(o2);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(o3);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(o4);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(a1);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(a2);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(a3);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(a4);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(car_mode);
  r.append(" ").append(tmp);

  std_msgs::String msg;
  msg.data = r;
  down_send.publish(msg);
}


void send_CarInfo_to(){
  stringstream ss;
  string tmp,r;
  //////////
  tmp.clear();r.clear();
  tmp = boost::lexical_cast<string>(cmode);
  r = tmp;

  tmp.clear();
  tmp = boost::lexical_cast<string>(cangle);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cspeed);
  r.append(" ").append(tmp);
  //////////
  tmp.clear();
  tmp = boost::lexical_cast<string>(cangle1);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cangle2);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cangle3);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cangle4);
  r.append(" ").append(tmp);
  //////////
  tmp.clear();
  tmp = boost::lexical_cast<string>(ccur_m1);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(ccur_m2);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(ccur_m3);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(ccur_m4);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cspeed_m1);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cspeed_m2);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cspeed_m3);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cspeed_m4);
  r.append(" ").append(tmp);
  //////////
  tmp.clear();
  tmp = boost::lexical_cast<string>(cpul_m1);
  r.append(" ").append(tmp);
  
  tmp.clear();
  tmp = boost::lexical_cast<string>(cpul_m2);
  r.append(" ").append(tmp);
  
  tmp.clear();
  tmp = boost::lexical_cast<string>(cpul_m3);
  r.append(" ").append(tmp);
  
  tmp.clear();
  tmp = boost::lexical_cast<string>(cpul_m4);
  r.append(" ").append(tmp);
  //////////
  tmp.clear();
  tmp = boost::lexical_cast<string>(cus1);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cus2);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cus3);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cus4);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cus5);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cus6);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cus7);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cus8);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cobstacle);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cdis_keep);
  r.append(" ").append(tmp);
  //////////
  for(int i=0;i<12;i++)
  {
    tmp.clear();
    tmp = boost::lexical_cast<string>(ccell[i]);
    r.append(" ").append(tmp);
  }
  //////////
  tmp.clear();
  tmp = boost::lexical_cast<string>(cmaxV);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cminV);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cmaxVP);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cminVP);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cVD);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cAV);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cTV);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cCC);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cDC);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cSOC);
  r.append(" ").append(tmp);
  //////////
  tmp.clear();
  tmp = boost::lexical_cast<string>(cTem1);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cTem2);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cTem3);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cTem4);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cTem5);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cTem6);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cmaxTem);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cminTem);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cavrTem);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cenvirTem);
  r.append(" ").append(tmp);
  ///////////
  tmp.clear();
  tmp = boost::lexical_cast<string>(cRc);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cWr);
  r.append(" ").append(tmp);
  //////////
  
  std_msgs::String msg;
  msg.data = r;
  //cout<<r<<endl;
  car_info_send.publish(msg);
}


void* getData(void* args)//get data from car and send 
{
    while(true){
      cc.DataReceive();
      o1 = cc.pul1_data;//四个里程计数据
      o2 = cc.pul2_data;
      o3 = cc.pul3_data;
      o4 = cc.pul4_data;

      a1 = cc.sv1_ac_data;
      a2 = cc.sv2_ac_data;
      a3 = cc.sv3_ac_data;
      a4 = cc.sv4_ac_data;

      sm1 = cc.m1_data;
      sm2 = cc.m2_data;
      sm3 = cc.m3_data;
      sm4 = cc.m4_data;

      car_mode = cc.mode_data;

      cmode = cc.mode_data;
      cangle = cc.angle_data;
      cspeed = cc.speed_data;

      cangle1 = cc.sv1_ang_data;
      cangle2 = cc.sv2_ang_data;
      cangle3 = cc.sv3_ang_data;
      cangle4 = cc.sv4_ang_data;

      ccur_m1 = cc.cur1_data;
      ccur_m2 = cc.cur2_data;
      ccur_m3 = cc.cur3_data;
      ccur_m4 = cc.cur4_data;
      cspeed_m1 = cc.m1_data;
      cspeed_m2 = cc.m2_data;
      cspeed_m3 = cc.m3_data;
      cspeed_m4 = cc.m4_data;

      cpul_m1 = cc.dis1_data;
      cpul_m2 = cc.dis2_data;
      cpul_m3 = cc.dis3_data;
      cpul_m4 = cc.dis4_data;

      cus1 = cc.us1_data;
      cus2 = cc.us2_data;
      cus3 = cc.us3_data;
      cus4 = cc.us4_data;
      cus5 = cc.us5_data;
      cus6 = cc.us6_data;
      cus7 = cc.us7_data;
      cus8 = cc.us8_data;
      cobstacle = cc.obstacle_data;
      cdis_keep = cc.dis_keep_data;

      ccell[0] = cc.cell1_data;
      ccell[1] = cc.cell2_data;
      ccell[2] = cc.cell3_data;
      ccell[3] = cc.cell4_data;
      ccell[4] = cc.cell5_data;
      ccell[5] = cc.cell6_data;
      ccell[6] = cc.cell7_data;
      ccell[7] = cc.cell8_data;
      ccell[8] = cc.cell9_data;
      ccell[9] = cc.cell10_data;
      ccell[10] = cc.cell11_data;
      ccell[11] = cc.cell12_data;

      cmaxV = cc.max_voltage_data;
      cminV = cc.min_voltage_data;
      cmaxVP = cc.max_voltage_pos_data;
      cminVP = cc.min_voltage_pos_data;
      cVD = cc.voltage_diff_data;
      cAV = cc.avg_voltage_data;
      cTV = cc.total_voltage_data;
      cCC = cc.charge_cur_data;
      cDC = cc.discharge_cur_data;
      cSOC = cc.soc_data;

      cTem1 = cc.temperature1_data;
      cTem2 = cc.temperature2_data;
      cTem3 = cc.temperature3_data;
      cTem4 = cc.temperature4_data;
      cTem5 = cc.temperature5_data;
      cTem6 = cc.temperature6_data;
      cmaxTem = cc.max_temp_data;
      cminTem = cc.min_temp_data;
      cavrTem = cc.avg_temp_data;
      cenvirTem = cc.envirmnt_temp_data;

      cRc = cc.Rc_data;
      cWr = cc.Wr_data;
      //cout<<"odo:"<<o1<<" "<<o2<<" "<<o3<<" "<<o4<<endl<<endl;
      send_info_to();
      send_CarInfo_to();
    }
}


inline void pub_v_a_modeHandler(int mode,double angle,float speed)
{
  string tmp,r;
  tmp.clear();r.clear();
  tmp = boost::lexical_cast<string>(mode);
  r = tmp;

  tmp.clear();
  tmp = boost::lexical_cast<string>(angle);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(speed);
  r.append(" ").append(tmp);

  std_msgs::String msg;
  msg.data = r;
  pub_v_a_mode.publish(msg);
}


#define CONTROLLER_MODE 0   /*遥控模式*/
#define STOP            1   /*停车模式*/
#define INITIAL_NAV     2   /*更新任务点信息*/
#define UPDATE_LOCATION 3   /*计算当前帧、目标帧*/
#define UPDATE_TURNING  4   /*计算最近拐点与预锚点*/
#define FORWARD_MODE    5   /*直走模式*/
#define TURNING_PRE     6   /*原地转弯准备*/
#define TURNING_        7   /*原地转弯中*/
#define TURNING_END     8   /*原地转弯结束*/
#define AVOIDOBSTACLE   9   /*避障*/
#define CHARGE          10  /*auto charge*/
ofstream log_("/home/dky/catkin_lidar/src/loam_velodyne/log.txt");
ofstream plan_("/home/dky/catkin_lidar/src/loam_velodyne/output/plan_log.txt");

int main(int argc, char** argv)
{
  ros::init(argc, argv, "laserCtrl");
  ros::NodeHandle nh;
  GLogHelper gh(argv[0]);

  DecodePara("/home/dky/catkin_lidar/src/loam_velodyne/carPara.ini",carpara);
  ctrl_init(nh);
  ret = pthread_create(&id,NULL,getData,NULL);

  /*************cls ********************/
  Point tempt = {0,0};
  Point PointOfTarget;
  Detect Detection;
  int IsCrashed = 0;
  GPSPoint Mic_target;
  Simulation Mic;
  double CanCalculate = 1;
  obstacle_point.push_back(tempt);
  int last_target_index = 0;
  InfoToSS itss;
  itss.TargetSpeed = 0.3;
  /***************end*******************/


  double angle = 0;
  int MODE = 0, direction_ = 0;//the dirction of turn

  log_<<"MODE,x,y,heading\n";

  ros::Rate rate(15);
  bool status = ros::ok();
  int count_pass_turn_point=0;// used to count how many passed turn  points.
  int count_pass_task_point=0;// used to count how many passed task points. 
  while(status)
  {
    ros::spinOnce();

    //MODE = is_charge?CHARGE:MODE;
    MODE = CONTROLLER_ORDER_REV?CONTROLLER_MODE:MODE; /*遥控模式/自动模式*/
    MODE = is_stop? STOP:MODE; /*是否停下的检测*/  // comment temperally by DYQ

    log_<< ros::Time::now()<<","<<MODE<<","<<real_time_location.x<<","<<real_time_location.y<<","<<real_time_location.heading<<",";
    //cout<< ros::Time::now() << " MODE: "<<MODE<<endl;

    switch(MODE)
    {
      cout<<"current MODE is: "<<MODE<<endl;
      case CONTROLLER_MODE:
      {
        CONTROLLER_ORDER_REV = false; 
        cc.GetInfo(a_mode,a_angle,a_speed);
        a_mode = a_angle = a_speed = 0.0;
        MODE = INITIAL_NAV;
        break;
      }

      case STOP:
      {
        #ifdef IS_AUTO
        cc.GetInfo(0,0,0);
        #endif
        cout<<"MODE from STOP to INITIAL_NAV"<<endl;
        MODE=INITIAL_NAV; // 跳转导航模块
        break;
      }

      case INITIAL_NAV:
      {
        if(!all_map.empty())  //是否收到了导航信息,15 is ? zyc
        {
          	if(!obstacle_stop)// whether receive the stop command 
          	{
          		cout<<"no obstacle stop command"<<endl;
              cout<<"delay_end: "<<delay_end<<endl;
          		if(delay_end == 101)// delete the float error of imu 
          		{
          			cout<<"finish the imu error deletion"<<endl;
          			if(is_init_end)// whether finish the initial location，
          				//需要考虑是否更新任务点，因为UPDATE_LOCATION需要用到任务点，回中大解决。单云霄
          			{
 						      cout<<"finish the initial location, prepare to go now"<<endl;
                  cout<<"MODE from INITIAL_NAV to UPDATE_LOCATION"<<endl;
          				MODE=UPDATE_LOCATION;// enter into update_location mode
          			}
          			else
          			{
          				cout<<"have not finished the initial locaiton"<<endl;
          				MODE=STOP;
          			}

          		}
          		else
          		{
          			cout<<"have not finished the imu deletion"<<endl;
          			MODE=STOP;
          		}
          		//pcctrl_log<<delay_end<<" "<<is_init_end<<" "<<newLaserCloudSurfLast<<endl;
          	}
          	else
          	{
          		cout<<"receive the obstacle stop command"<<endl;
          		MODE=STOP;
          	}     
        }
        break;
      }

      case UPDATE_LOCATION:
      {
        /*
        计算当前路径(直线)上的 “当前帧” 与 任务目标点的 “目标帧”
        从起点开始遍历找到当前路段的范围，在此基础上寻找最近的“当前帧”
        */
        for(int i = start_turn; i < all_map.size(); i++)
        {
          if(all_map[i].is_turn == 1 && all_map[i].is_finish_turn == 0)
          {
            end_turn = i;
            // 当前帧
            current_index = Current_index_Return(real_time_location.x,
                                                 real_time_location.y,
                                                 all_map,start_turn,
                                                 end_turn);
            // 目标点的帧 SRK1205
           
            if(task_dis < 1.5){
              task_index = Current_index_Return(task_x,task_y,all_map,
                                                start_turn,end_turn);
            }

            if(fabs(real_time_location.heading-180) < 40 || fabs(real_time_location.heading) < 40)
            {
              task_dis = fabs(task_y - real_time_location.y);
            }
            else if(fabs(real_time_location.heading - 90) < 40 || fabs(real_time_location.heading + 90) < 40){
              task_dis = fabs(task_x - real_time_location.x);
            }
            else{
               task_dis = length_two_points(real_time_location.x,
                                         real_time_location.y,
                                         task_x,task_y); //当前位置与任务点的距离
            }

            break;
          }
        }
        log_<<current_index<<","<<task_dis<<",";
        // cout<<"current_index: "<<current_index<<"  task_index: "<<task_index<<endl;

        

         if(IsBeyondTheEndPoint(all_map, real_time_location, task_index) || task_dis < 0.2)
        {
          // task_index = 10000;
           log_<<"Stop";

           is_arrived = true;

           if(is_arrived_sent >0)
           {
              std_msgs::Int8 msg;//
              msg.data = 1;
              pub_car_arrive.publish(msg);
              cout<<"publish the stop of car"<<endl;
              is_arrived_sent--;
           }
           count_pass_task_point++;
           save_task_info<<real_time_location.x<<' '<<real_time_location.y<<' '
           <<all_map[task_index].x<<' '<<all_map[task_index].y<<" "<<task_index<<" "<<all_map[start_turn].x<<' '
           <<all_map[start_turn].y<<" "<<count_pass_task_point<<endl;
           //LOG(ERROR) << "task_index:" << " " << task_index << endl;
           LOG(ERROR)<<"task xy..."<<task_x<<" "<<task_y<<" "<<task_index;
         //cout<<"publish the stop of car"<<endl;
         //LOG(INFO)<<"current_index: "<<current_index<<"  task_index: "<<task_index;
           cout<<"MODE from UPDATE_LOCATION to STOP and we arrived at task point"<<endl;

           MODE=STOP;

           continue;
        }

        /* 发送当前帧 */
        std_msgs::Int64 msg;
        msg.data = current_index;
        current_send.publish(msg);

        /* 计算最近拐点及与之的距离  zyc */  
        for(int i = current_index; i < all_map.size(); i++)
        {
          if(all_map[i].is_turn == 1 && all_map[i].is_finish_turn == 0)
          {
            turn_index = i; //最近拐点的index
            if(fabs(real_time_location.heading-180) < 40 || fabs(real_time_location.heading) < 40)
            {
              turn_dis = fabs(all_map[turn_index].y - real_time_location.y);
            }
            else if(fabs(real_time_location.heading - 90) < 40 || fabs(real_time_location.heading + 90) < 40){
              turn_dis = fabs(all_map[turn_index].x - real_time_location.x);
            }
            else{
              turn_dis = length_two_points(real_time_location.x,real_time_location.y,all_map[i].x,all_map[i].y);
            }

            turn_dis = length_two_points(real_time_location.x,real_time_location.y,all_map[i].x,all_map[i].y);
            break;
          }
        }
        //turn_dis = length_two_points(real_time_location.x,real_time_location.y,all_map[turn_index].x,all_map[turn_index].y);

        //LOG(INFO)<<"current_index: "<<current_index<<"  task_index: "<<task_index;

        /*
        停下的判断，使用“当前帧”与“地图帧”的index比较作为判据
        满足停下条件，将MODE修改为停下
        */
        // if(((current_index >= task_index)))
       

        if(IsBeyondTheEndPoint(all_map, real_time_location, turn_index) || turn_dis < 0.2)
        {
          count_pass_turn_point++;
          save_turn_info<< real_time_location.x<<' '<<real_time_location.y<<' '
                        << all_map[turn_index].x<<' '<<all_map[turn_index].y<<" "<<turn_index<<
                        ' '<<all_map[start_turn].x<<' '<<all_map[start_turn].y<<' '
                        <<count_pass_turn_point<<endl;
          LOG(ERROR) << "turn_index:" << " " << turn_index << endl; 
          /*
          与拐点的距离小于阈值时开始原地转弯
          current_index < task_index 确保在任务结束时不会转弯
          通知里程计已经切换小车模式并停止航位推算
          切换MODE到转弯前准备阶段
          */
          send_mode_vo(real_time_location.x,
                       real_time_location.y,
                       real_time_location.heading,1);
          cout<<"MODE from UPDATE_LOCATION to TURNING_PRE we arrive at turn point"<<endl;
          MODE = TURNING_PRE;
        }
        else
        {
          /*
          未满足条件切换到直走模式
          */
          cout<<"MODE from UPDATE_LOCATION to FORWARD_MODE, we keep go forward"<<endl;
          MODE = FORWARD_MODE;
        }
        // cout << MODE << " " << is_obstacle_sent << " " << new_map_have_recieved << " " << turn_dis << " " << to_turn_point_dis << " " << real_time_location.x << " " << real_time_location.y << " " << all_map[turn_index].x << " " << all_map[turn_index].y << " " << turn_index << " " << current_index << endl;
        plan_ << ros::Time::now() << " " << MODE << " " << is_obstacle_sent << " " << new_map_have_recieved << " " << turn_dis << " " << to_turn_point_dis << " " << real_time_location.x << " " << real_time_location.y << " " << real_time_location.heading << " " << all_map[turn_index].x << " " << all_map[turn_index].y << " " << all_map[turn_index].heading << " " << all_map[current_index].x << " " << all_map[current_index].y << " " << all_map[current_index].heading << " " << turn_index << " " << current_index << endl;
        break;
      }

      case TURNING_PRE:
      {
        /*
        在此模块进行最优转弯方向确定
        计算需要的转弯角度
        切换模式到 Turning 
        */
 
        /*cls*/

        // if(fabs((real_time_location.heading) - (all_map[turn_index].heading)) > 150)
        // {
        //   direction_ = all_map[turn_index].heading < real_time_location.heading;
        // }
        // else
        // {
        //   direction_ = all_map[turn_index].heading > real_time_location.heading;
        // }

      	direction_ = !DetermineTurnDirection(real_time_location.heading, all_map[turn_index].heading);

        cout<<"Into the TURNING_PRE phase: "<<"from real_time_heading "<<real_time_location.heading<<" to map_turning_heading "<<all_map[turn_index].heading<<" "<<direction_<<endl<<endl;

        LOG(ERROR)<<"first in turn  "<<" "<<real_time_location.heading<<" "<<all_map[turn_index].heading<<" "<<direction_;

        MODE = TURNING_;
        break;
      }

      case TURNING_:
      {


      //   if(real_time_location.heading > 0 && all_map[turn_index].heading < 0 && direction_ >0)
      //   {
      //     if(real_time_location.heading < 0 && real_time_location.heading > all_map[turn_index].heading-10)
      //       {
      //         is_turn_over = true;
      //       }
      //       else{
      //       is_turn_over = false;
      //     }
      //   }
      //   else
      //     {
      //       if(real_time_location.heading < 0 && all_map[turn_index].heading > 0 && direction_ <0)
      //   {
      //     if(real_time_location.heading > 0 && real_time_location.heading < all_map[turn_index].heading+10)
      //       {
      //         is_turn_over = true;
      //       }
      //       else{
      //       is_turn_over = false;
      //     }
      //   }
      // }

        // 12-7xiugai
        if(direction_ > 0) //turning to left
        {
          if(all_map[turn_index].heading - 10 < -180)
          {
            all_map[turn_index].heading = all_map[turn_index].heading + 360;
          } 
          if(real_time_location.heading > all_map[turn_index].heading-10)
          {
            if((real_time_location.heading * all_map[turn_index].heading) >= 0)
              is_turn_over = true;
            else{
              is_turn_over = false;
            }
          }
          else
          {
            is_turn_over = false;
          }
        }
        else  //direction_ < 0,turning to right
        {
          if(all_map[turn_index].heading + 10 > 180)
          {
            all_map[turn_index].heading = all_map[turn_index].heading - 360;
          } 
          if(real_time_location.heading < all_map[turn_index].heading+10){
            if((real_time_location.heading * all_map[turn_index].heading) >= 0)
              is_turn_over = true;
            else{
              is_turn_over = false;
            }
          }
          else
          {
            is_turn_over = false;
          }
        }
        //LOG(ERROR)<<"turning from "<<real_time_location.heading<<" to "<<all_map[turn_index].heading;
        turnctrl_log <<"turning from "<<real_time_location.heading<<" to "<<all_map[turn_index].heading << endl;
        //fabs((real_time_location.heading) - (all_map[turn_index].heading)) > 12.0
        if (is_turn_over == false)
        {
          /*
          负速度往右 正速度往左
          未达到目标角度前一直发送转弯命令
          转弯速度为 turning_speed 
          否则跳转到转弯结束后续处理模块
          */
          cc.GetInfo(1, 0, direction_? -turning_speed:turning_speed);
        }
        else
        { 
          cout<<"MODE from TURNING_ to TURNING_END, we want to finish the turn."<<endl;
          MODE = TURNING_END;
        }
        break;
      }

      case TURNING_END:
      {
        // 通知里程计进行位置航推
        send_mode_vo(real_time_location.x,real_time_location.y,real_time_location.heading,0);

        cout<<"final heading: "<<real_time_location.heading<<endl;
        LOG(ERROR)<<"final heading: "<<real_time_location.heading;
        /*
        标记拐点turn_index已使用
        每一段路径由两个拐点组成，当前原地转弯结束之后将当前拐点置为新路段的起点
        */
        while(cmode !=0)
        {
          #ifdef IS_AUTO
          cc.GetInfo(0,0,0);
          #endif
        }

        all_map[turn_index].is_finish_turn = 1; 

        start_turn = end_turn; // 初始状态的时候 ？？
        MODE = STOP;
        int count_new_path=0;//计数经过多少次迭代才能获取到新数据 单云霄

        if(turn_index == all_map.size()-1)
        {
          cout<<"MODE from TURNING_END to STOP."<<endl;
          MODE = STOP;
          bool is_car_stop = (cc.m1_data == 0)&&(cc.m2_data == 0)&&(cc.m3_data == 0)&&(cc.m4_data == 0);
          cout<<"the car have complete the first init "<<is_car_stop<<endl;
          is_finish_location = 1;        	
        }
        else
        {
          cout<<"turn_end_pub sent!!!"<<endl;
          std_msgs::Int8 msg;
          msg.data = 1;
          turn_end_pub.publish(msg);
          cout<<"MODE from TURNING_END to STOP,"<<endl;
          MODE = STOP;

          is_init_end = true;
          delay_end = 0;

          cout<<"turn finish and notify the relocation "<<current_index<<" "<<all_map.size()-10<<endl;        	
        }

        new_map_have_recieved = false;
        break;
      }

      case FORWARD_MODE:
      {
        // 动态预锚点计算
        SmTarPoi stp;
        stp.GetAllMap(all_map);
        target_index = stp.GetDataAndReturn(real_time_location,current_index,turn_index,speed);
        angle_log << ros::Time::now() << " " << current_index << " " << turn_index << " ";

        if(target_index >= turn_index)
        {
          target_index = turn_index;
        }
        

        double Lx,Ly;
        GPSPoint target;
        target.x = all_map[target_index].x;
        target.y = all_map[target_index].y;
        target.GaussX = all_map[target_index].x;
        target.GaussY = all_map[target_index].y;
        angle_log << target.x << " " << target.y << " " << target_index << " " << last_target_index << " ";
 

        ModifyTargetPoint mtp;
        target = mtp.ModifiedTargetPoint(real_time_location,turn_index,all_map,target, stp.target_length);

        WorldtoMap(real_time_location,target.GaussX,target.GaussY,Lx,Ly);
        target.LX = Lx;
        target.LY = Ly;
        angle = getAngle(-target.LX,target.LY);
        target.x = all_map[target_index].x;
        target.y = all_map[target_index].y;
        WorldtoMap(real_time_location,target.x,target.y,Lx,Ly);
        PointOfTarget.x = Lx;
        PointOfTarget.y = Ly;
        target.heading = all_map[target_index].heading;

        double disofnow2path = 3;
        for (int i = 0; i < all_map.size(); ++i)
        {
          double temdon2p = length_two_points(all_map[i].x, all_map[i].y, real_time_location.x, real_time_location.y);
          if(temdon2p < disofnow2path)
            disofnow2path = temdon2p;
        }
        angle_log << angle << " " << disofnow2path << " " << " " << target.x << " " << target.y << " " << target.LX << " " << target.LY << " " << real_time_location.x << " " << real_time_location.y << " " << real_time_location.heading << endl;


        #ifdef IS_AUTO
        itss.SendSpeed = speed;
        itss.LeftBackTire = cspeed_m3;
        itss.RightBackTire = cspeed_m4;
        itss.Distance2Stop = turn_dis;
        speed = SendInfoAndMakeSpeedSmooth(itss);
        cc.GetInfo(0,angle,0.25); 
        pub_v_a_modeHandler(0,angle,speed);
        #endif
        cout<<"MODE from FORWARD_MODE to UPDATE_LOCATION"<<endl;
        MODE = UPDATE_LOCATION; // 跳转到定位

        //MODE = Detection.GetData(PointOfTarget,obstacle_point)?AVOIDOBSTACLE:MODE;
        break;
      }

      case AVOIDOBSTACLE:
      {
        if(fabs(cspeed) > 0.01)
        {
          cc.GetInfo(0,0,0);
          MODE = AVOIDOBSTACLE;
          break;
        }

        if(is_obstacle_sent > 0)
        {
          std_msgs::Int8 msg;
          msg.data = 1;
          pub_obstacle_replan.publish(msg);
          is_obstacle_sent--;
          MODE = AVOIDOBSTACLE;
          break;
        }

        if(new_map_have_recieved)
        {
          MODE=INITIAL_NAV;  
          send_mode_vo(real_time_location.x,
                       real_time_location.y,
                       real_time_location.heading,0);
          is_obstacle_sent = 1;
          //new_map_have_recieved = false;
        }
        else
        {
          MODE = AVOIDOBSTACLE;
          break;
        }
        break;

      }
      case CHARGE:
      {
        if(fabs((real_time_location.heading) - 0.0) > 2.0  && charge_turn_end)
        {
          if(charge_vo_send)
          {
            send_mode_vo(real_time_location.x,
                       real_time_location.y,
                       real_time_location.heading,1);
            charge_vo_send = false;
          }
          int direction__ = !DetermineTurnDirection(real_time_location.heading, 0.0);
          cc.GetInfo(1, 0, direction__? -0.1:0.1);
          cout<<"daoche"<<endl;
          break;
        }
        
        charge_turn_end = false;

        if(cmode!=0)
        {
          cc.GetInfo(0,0,0);
          charge_x = real_time_location.x;
          charge_y = real_time_location.y;
          break;
        }

        if(charge_vo_sent)
        {
          send_mode_vo(real_time_location.x,
             real_time_location.y,
             real_time_location.heading,0);
          charge_vo_sent = false;
        }

        /////////往后倒车/////////
        if(length_two_points(real_time_location.x,real_time_location.y,charge_x,charge_y) < 0.2)
        {
          cc.GetInfo(0,0,-0.1);
          cout<<"倒车请注意!!!"<<"  x: "<<real_time_location.x<<"  y: "<<real_time_location.y<<"  chargex:"<<charge_x<<" chargey: "<<charge_y<<endl;
          break;
        }
        else
        {
          cc.GetInfo(0,0,0);
          is_charge = 0;
          charge_vo_send = true;
          charge_turn_end = true;
          charge_vo_sent = true;
          cout<<"car have arrive charge point!"<<endl;
          MODE = STOP;
        }
        
        ////////////////////////

        break;
      }

    }
    log_<<endl;
    status = ros::ok();
    rate.sleep();
  }
  return 0;
}