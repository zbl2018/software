#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <pcl/registration/icp.h>
#include <pcl/point_cloud.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/kdtree/kdtree_flann.h>
#include <pcl/visualization/cloud_viewer.h>
#include <cstring>
#include <sensor_msgs/PointCloud2.h>
#include <Eigen/Dense>  
#include <boost/format.hpp>
#include <ros/ros.h>
#include <math.h>
#include <iostream>
#include <loam_velodyne/common.h>
#include <nav_msgs/Odometry.h>
#include <pcl_conversions/pcl_conversions.h>
#include <sensor_msgs/Imu.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_broadcaster.h>
#include <iomanip>
#include <fstream>
#include <loam_velodyne/LocalGeographicCS.hpp>
#include <loam_velodyne/Detect.h>
#include <loam_velodyne/getAngle.h>
#include <sensor_msgs/Imu.h>
#include <sensor_msgs/NavSatFix.h>
#include <geometry_msgs/PoseStamped.h>
#include <loam_velodyne/serial.h>
#include <loam_velodyne/Simulation.hpp>
#include <loam_velodyne/control_car.h>
#include <loam_velodyne/ModifyTargetPoint.hpp>
#include <loam_velodyne/SmTarPoi.hpp>                                                     
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <string> 
#include <pthread.h>
#include "std_msgs/String.h"
#include "std_msgs/Int64.h"
#include "std_msgs/Int8.h"
#include <pthread.h>
#include <boost/lexical_cast.hpp>
#include <boost/thread/thread.hpp>
#include <ctime>
#include <time.h>
#include <unistd.h>
#include <exception> 
#include <loam_velodyne/TurnWhichDirection.h>
#include <loam_velodyne/LORDeterminer.hpp>

#include <loam_velodyne/GLogHelper.h>
#include <glog/logging.h>

using namespace Eigen; 
using namespace std;

#define IS_AUTO 1

#define CONTROLLER_MODE 0   /*遥控模式*/
#define STOP            1   /*停车模式*/
#define INITIAL_NAV     2   /*更新任务点信息*/
#define UPDATE_LOCATION 3   /*计算当前帧、目标帧*/
#define UPDATE_TURNING  4   /*计算最近拐点与预锚点*/
#define FORWARD_MODE    5   /*直走模式*/
#define TURNING_PRE     6   /*原地转弯准备*/
#define TURNING_        7   /*原地转弯中*/
#define TURNING_END     8   /*原地转弯结束*/
#define AVOIDOBSTACLE   9   /*避障*/

int MODE = 0, direction_ = 0;//the dirction of turn

std::ofstream ctrl_log("/home/dky/catkin_lidar/src/loam_velodyne/output/ctrl_log.txt");

std::ofstream angle_log("/home/dky/catkin_lidar/src/loam_velodyne/output/angle_log.txt");

std::ofstream turnctrl_log("/home/dky/catkin_lidar/src/loam_velodyne/output/turnctrl_log.txt");

std::ofstream initctrl_log("/home/dky/catkin_lidar/src/loam_velodyne/output/initctrl_log.txt");

std::ofstream pcctrl_log("/home/dky/catkin_lidar/src/loam_velodyne/output/pcctrl_log.txt");

CarPara carpara;//小车参数变量
string ALL_MAP("");//动态路径
double to_target_point_dis = 1.5;//距离预瞄点的距离
double to_turn_point_dis = 0.2;//距离拐点的距离
bool is_init_end = false;
const float speed = 0.25; //小车直走速度
const float turning_speed = 0.15; // 小车转弯速度

//other ros topic
ros::Publisher down_send;
ros::Publisher mode_send;
ros::Publisher car_info_send;
ros::Publisher current_send;//current index send to location
ros::Publisher turn_end_pub;
ros::Publisher pub_v_a_mode;//send angle to sbg
ros::Publisher pub_car_arrive;

ros::Subscriber subfinal;
ros::Subscriber sub_delay;
ros::Subscriber sub_map_data;
ros::Subscriber task_sub;
ros::Subscriber stop_sub;
ros::Subscriber sub_move;
ros::Subscriber sub_init_end;
ros::Subscriber obstacle_rev;//edit by equal obstacle

ros::Subscriber subLaserCloudSurfLast;

string obstacle_string;
vector<Point> obstacle_point;

///////////////////////
double end_pos_x = 0;
double end_pos_y = 0;
double end_dis = 0;
///////////////////////
int start_turn = 0;
int end_turn = 0;

bool new_path_race = false;
bool CONTROLLER_ORDER_REV = false;

bool newLaserCloudSurfLast = false;

bool is_arrived = false;
int is_arrived_sent = 3;

///////task point
double task_x,task_y,task_heading,task_speed;
double task_dis = 1000;
int task_index = 10000;

///////
int delay_end = 0;//sbg will send the msg to ctrl while the vo was ready
static int is_stop = 0;//后台发送stop指令
bool obstacle_stop = false;//超声波检测到障碍物并停止

GPSPoint real_time_location;

vector<GPSPoint> all_map;//all map data

car cc;//车辆控制指令实例
double o1,o2,o3,o4,a1,a2,a3,a4;
double sm1,sm2,sm3,sm4;
int car_mode;

float a_mode = 0;
float a_speed = 0;
float a_angle = 0;

pthread_t id;//read info from the car and open a thread to send to other node
int i,ret;
////////////////////////////////////////////////////////////////////////////////////////
// ofstream T("/home/chen/sysuzyc/catkin_yf_lidar/src/loam_velodyne/output/target.txt");
////////////////////////////////////////////////////////////////////////////////////////
/*******************************原地转弯************************************************/
int first_turn = 1;
int calculat_turn = 1;
int target_index = 0;
int turn_index = 0;
int current_index = 0;
double turn_dis = 0;     //与最近拐点的最近距离
double last_turn_dis = 0;//上一次与拐点的最近距离
int is_can_turn = 0;
bool re_icp_location = 0; 
double delta_turn_angle = 0;

/**************************************************************************************/

void send_mode_vo(double x,double y,double heading,int mode){
  string tmp,r;

  tmp.clear();r.clear();
  tmp = boost::lexical_cast<string>(x);
  r = tmp;

  tmp.clear();
  tmp = boost::lexical_cast<string>(y);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(heading);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(mode);
  r.append(" ").append(tmp);

  std_msgs::String msg;
  msg.data = r;
  mode_send.publish(msg);
}


void FinalHandler(const std_msgs::String::ConstPtr &msg)
{
  double real_time_x = 0,real_time_y = 0,real_time_heading = 0;
  string moves = msg->data;
  stringstream stringin(moves);
  stringin>>setprecision(12)>>real_time_x>>real_time_y>>real_time_heading;
  real_time_heading = real_time_heading * 180.0 / 3.14159265;

  real_time_location.x = real_time_x;
  real_time_location.y = real_time_y;    
  real_time_location.GaussX = real_time_x;
  real_time_location.GaussY = real_time_y;
  real_time_location.heading = real_time_heading;
}


void delay_Handler(const std_msgs::Int64::ConstPtr &msg){
  delay_end = msg->data;
  cout<<"delay_end: "<<delay_end<<endl;
}


void Init_End_Handler(const std_msgs::Int8::ConstPtr &msg){
	is_init_end = msg->data;
	cout<<"location have init finish!"<<endl;
}


void task_Handler(const std_msgs::String::ConstPtr &msg){

  task_x = 0;
  task_y = 0;
  task_speed = 0.2;

  string moves = msg->data;
  stringstream stringin(moves);
  stringin>>setprecision(12)>>task_x>>task_y>>task_speed;

  cout<<"任务点： "<<task_x<<" "<<task_y<<" "<<task_speed<<endl;
  cout<<"解除stop命令！"<<endl;
}


void stop_Handler(const std_msgs::Int8::ConstPtr &msg){
  is_stop = msg->data;
  cout<<"!!!!!!!!!!!!!!!!!!!!!"<<" "<<is_stop<<endl;
}


void map_Handler(const std_msgs::String::ConstPtr &msg){

  ALL_MAP.clear();
  all_map.clear();

  start_turn = 0;
  end_turn = 0;

  is_stop = 0;

  task_index = 10000;
  task_dis = 0;

  turn_dis = 0;
  turn_index = 0;
  last_turn_dis = 0;

  is_arrived = false;

  is_arrived_sent = 3;

  newLaserCloudSurfLast = false;

  MODE = STOP;

  // task_x = 0;
  // task_y = 0;

  ALL_MAP = msg->data;
  cout<<"path have receive! ctrl"<<endl;

  //send_mode_vo(real_time_location.x,real_time_location.y,real_time_location.heading,0);

  decodePath(ALL_MAP,all_map);//解析规划路径
  

  if(!all_map.empty()){

  	cout<<"map size: "<<all_map.size()<<endl;

    cout<<"init angle: "<<all_map[0].heading<<endl;

    for(int i=0; i<all_map.size(); i++){
      all_map[i].heading = all_map[i].heading * 180.0 / 3.14159265; 
    }

    ////////////edit by equal//////////////
    cout<<"path first x: "<<all_map[0].x<<" y: "<<all_map[0].y<<endl;
    cout<<"now heading: "<<real_time_location.heading<<" map heading :"<<all_map[0].heading<<endl;

  //  if(fabs(real_time_heading - all_map[0].heading) > 70)
  //  {
  //      cout<<"first point have set turn point"<<endl;
  //      all_map[0].is_turn = 1;
  //  }
    all_map[0].is_turn = 1;
    all_map[all_map.size()-1].is_turn = 1;
    //////////////////////////////////////

    end_pos_x = all_map[all_map.size()-1].x;
    end_pos_y = all_map[all_map.size()-1].y;

    new_path_race = true;

    //pcctrl_log<<"new map "<<delay_end<<" "<<is_init_end<<" "<<newLaserCloudSurfLast<<endl;
  }
}


void move_Handler(const std_msgs::String::ConstPtr &msg){

  string moves = msg->data;
  stringstream stringin(moves);
  stringin>>setprecision(12)>>a_mode>>a_angle>>a_speed;
  CONTROLLER_ORDER_REV = true;
}

void laserCloudSurfLastHandler(const sensor_msgs::PointCloud2ConstPtr& laserCloudSurfLast2)
{
  // laserCloudSurfLast->clear();
  // pcl::fromROSMsg(*laserCloudSurfLast2, *laserCloudSurfLast);

  newLaserCloudSurfLast = true;
}

void obstacle_Handler(const std_msgs::String::ConstPtr &msg){
  obstacle_string = "";
  obstacle_string = msg->data;

  stringstream ss(obstacle_string);
  string tmp_s;

  obstacle_point.clear();

  while(getline(ss,tmp_s,';')){
    Point newpoint;
    stringstream final_s(tmp_s);

    final_s>>setprecision(12)>>newpoint.x>>newpoint.y;
    obstacle_point.push_back(newpoint);
  }
}


void ctrl_init(ros::NodeHandle nh){
	down_send = nh.advertise<std_msgs::String>("/odo_send",1000);

	car_info_send = nh.advertise<std_msgs::String>("/car_info",100);

	mode_send = nh.advertise<std_msgs::String>("chmod",5);

	subfinal = nh.subscribe<std_msgs::String>("/final_data",1000,FinalHandler);

	current_send = nh.advertise<std_msgs::Int64>("index_send",5);

	sub_delay = nh.subscribe<std_msgs::Int64>("vo_time",50,delay_Handler);

	task_sub = nh.subscribe<std_msgs::String>("/task_net",1000,task_Handler);
	stop_sub = nh.subscribe<std_msgs::Int8>("stop_net",100,stop_Handler);

    sub_move = nh.subscribe<std_msgs::String>("/move_net",1000,move_Handler);//后台发送遥控指令

    sub_map_data = nh.subscribe<std_msgs::String>("/map_send",1000,map_Handler);

    obstacle_rev = nh.subscribe<std_msgs::String>("/obstacle_out",1000,obstacle_Handler);

    sub_init_end = nh.subscribe<std_msgs::Int8>("init_finish",5,Init_End_Handler);

    pub_v_a_mode = nh.advertise<std_msgs::String>("car_move_info",5);

    turn_end_pub = nh.advertise<std_msgs::Int8>("turn_finish",5);

    pub_car_arrive = nh.advertise<std_msgs::Int8>("car_arrive",5);

    subLaserCloudSurfLast = nh.subscribe<sensor_msgs::PointCloud2>
                                            ("/laser_cloud_surf_last", 2, laserCloudSurfLastHandler);
}


void send_info_to(){
  string tmp,r;

  tmp.clear();r.clear();
  tmp = boost::lexical_cast<string>(o1);
  r = tmp;

  tmp.clear();
  tmp = boost::lexical_cast<string>(o2);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(o3);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(o4);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(a1);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(a2);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(a3);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(a4);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(car_mode);
  r.append(" ").append(tmp);

  std_msgs::String msg;
  msg.data = r;
  down_send.publish(msg);
}


void send_CarInfo_to(){
  stringstream ss;
  string tmp,r;
  //////////
  tmp.clear();r.clear();
  tmp = boost::lexical_cast<string>(cmode);
  r = tmp;

  tmp.clear();
  tmp = boost::lexical_cast<string>(cangle);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cspeed);
  r.append(" ").append(tmp);
  //////////
  tmp.clear();
  tmp = boost::lexical_cast<string>(cangle1);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cangle2);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cangle3);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cangle4);
  r.append(" ").append(tmp);
  //////////
  tmp.clear();
  tmp = boost::lexical_cast<string>(ccur_m1);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(ccur_m2);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(ccur_m3);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(ccur_m4);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cspeed_m1);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cspeed_m2);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cspeed_m3);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cspeed_m4);
  r.append(" ").append(tmp);
  //////////
  tmp.clear();
  tmp = boost::lexical_cast<string>(cpul_m1);
  r.append(" ").append(tmp);
  
  tmp.clear();
  tmp = boost::lexical_cast<string>(cpul_m2);
  r.append(" ").append(tmp);
  
  tmp.clear();
  tmp = boost::lexical_cast<string>(cpul_m3);
  r.append(" ").append(tmp);
  
  tmp.clear();
  tmp = boost::lexical_cast<string>(cpul_m4);
  r.append(" ").append(tmp);
  //////////
  tmp.clear();
  tmp = boost::lexical_cast<string>(cus1);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cus2);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cus3);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cus4);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cus5);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cus6);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cus7);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cus8);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cobstacle);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cdis_keep);
  r.append(" ").append(tmp);
  //////////
  for(int i=0;i<12;i++)
  {
    tmp.clear();
    tmp = boost::lexical_cast<string>(ccell[i]);
    r.append(" ").append(tmp);
  }
  //////////
  tmp.clear();
  tmp = boost::lexical_cast<string>(cmaxV);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cminV);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cmaxVP);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cminVP);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cVD);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cAV);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cTV);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cCC);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cDC);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cSOC);
  r.append(" ").append(tmp);
  //////////
  tmp.clear();
  tmp = boost::lexical_cast<string>(cTem1);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cTem2);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cTem3);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cTem4);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cTem5);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cTem6);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cmaxTem);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cminTem);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cavrTem);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cenvirTem);
  r.append(" ").append(tmp);
  ///////////
  tmp.clear();
  tmp = boost::lexical_cast<string>(cRc);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cWr);
  r.append(" ").append(tmp);
  //////////
  
  std_msgs::String msg;
  msg.data = r;
  //cout<<r<<endl;
  car_info_send.publish(msg);
}


void* getData(void* args)//get data from car and send 
{
    while(true){
      cc.DataReceive();
      o1 = cc.pul1_data;//四个里程计数据
      o2 = cc.pul2_data;
      o3 = cc.pul3_data;
      o4 = cc.pul4_data;

      a1 = cc.sv1_ac_data;
      a2 = cc.sv2_ac_data;
      a3 = cc.sv3_ac_data;
      a4 = cc.sv4_ac_data;

      sm1 = cc.m1_data;
      sm2 = cc.m2_data;
      sm3 = cc.m3_data;
      sm4 = cc.m4_data;

      car_mode = cc.mode_data;

      cmode = cc.mode_data;
      cangle = cc.angle_data;
      cspeed = cc.speed_data;

      cangle1 = cc.sv1_ang_data;
      cangle2 = cc.sv2_ang_data;
      cangle3 = cc.sv3_ang_data;
      cangle4 = cc.sv4_ang_data;

      ccur_m1 = cc.cur1_data;
      ccur_m2 = cc.cur2_data;
      ccur_m3 = cc.cur3_data;
      ccur_m4 = cc.cur4_data;
      cspeed_m1 = cc.m1_data;
      cspeed_m2 = cc.m2_data;
      cspeed_m3 = cc.m3_data;
      cspeed_m4 = cc.m4_data;

      cpul_m1 = cc.dis1_data;
      cpul_m2 = cc.dis2_data;
      cpul_m3 = cc.dis3_data;
      cpul_m4 = cc.dis4_data;

      cus1 = cc.us1_data;
      cus2 = cc.us2_data;
      cus3 = cc.us3_data;
      cus4 = cc.us4_data;
      cus5 = cc.us5_data;
      cus6 = cc.us6_data;
      cus7 = cc.us7_data;
      cus8 = cc.us8_data;
      cobstacle = cc.obstacle_data;
      cdis_keep = cc.dis_keep_data;

      ccell[0] = cc.cell1_data;
      ccell[1] = cc.cell2_data;
      ccell[2] = cc.cell3_data;
      ccell[3] = cc.cell4_data;
      ccell[4] = cc.cell5_data;
      ccell[5] = cc.cell6_data;
      ccell[6] = cc.cell7_data;
      ccell[7] = cc.cell8_data;
      ccell[8] = cc.cell9_data;
      ccell[9] = cc.cell10_data;
      ccell[10] = cc.cell11_data;
      ccell[11] = cc.cell12_data;

      cmaxV = cc.max_voltage_data;
      cminV = cc.min_voltage_data;
      cmaxVP = cc.max_voltage_pos_data;
      cminVP = cc.min_voltage_pos_data;
      cVD = cc.voltage_diff_data;
      cAV = cc.avg_voltage_data;
      cTV = cc.total_voltage_data;
      cCC = cc.charge_cur_data;//////////////////////////////
      cDC = cc.discharge_cur_data;
      cSOC = cc.soc_data;

      cTem1 = cc.temperature1_data;
      cTem2 = cc.temperature2_data;
      cTem3 = cc.temperature3_data;
      cTem4 = cc.temperature4_data;
      cTem5 = cc.temperature5_data;
      cTem6 = cc.temperature6_data;
      cmaxTem = cc.max_temp_data;
      cminTem = cc.min_temp_data;
      cavrTem = cc.avg_temp_data;
      cenvirTem = cc.envirmnt_temp_data;

      cRc = cc.Rc_data;
      cWr = cc.Wr_data;
      //cout<<"odo:"<<o1<<" "<<o2<<" "<<o3<<" "<<o4<<endl<<endl;
      if(cSOC > 5.0){
        send_info_to();
        send_CarInfo_to();
      }
    }
}


inline void pub_v_a_modeHandler(int mode,double angle,float speed)
{
  string tmp,r;
  tmp.clear();r.clear();
  tmp = boost::lexical_cast<string>(mode);
  r = tmp;

  tmp.clear();
  tmp = boost::lexical_cast<string>(angle);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(speed);
  r.append(" ").append(tmp);

  std_msgs::String msg;
  msg.data = r;
  pub_v_a_mode.publish(msg);
}



ofstream log_("/home/dky/Tanzby/log.txt");

int main(int argc, char** argv)
{
  ros::init(argc, argv, "laserCtrl");
  ros::NodeHandle nh;
  GLogHelper gh(argv[0]);

  DecodePara("/home/dky/catkin_lidar/src/loam_velodyne/carPara.ini",carpara);
  ctrl_init(nh);
  ret = pthread_create(&id,NULL,getData,NULL);

  /*************cls ********************/
  Point tempt = {0,0};
  Point PointOfTarget;
  Detect Detection;
  int IsCrashed = 0;
  GPSPoint Mic_target;
  Simulation Mic;
  double CanCalculate = 1;
  obstacle_point.push_back(tempt);
  int last_target_index = 0;
  /***************end*******************/


  double angle = 0;
  

  log_<<"MODE,x,y\n";

  ros::Rate rate(15);
  bool status = ros::ok();
  while(status)
  {
    ros::spinOnce();

    MODE = CONTROLLER_ORDER_REV?CONTROLLER_MODE:MODE; /*遥控模式/自动模式*/
    MODE = is_stop? STOP:MODE; /*是否停下的检测*/

    log_<<MODE<<","<<real_time_location.x<<","<<real_time_location.y<<",";


    //LOG(WARNING)<<"current mode: "<<MODE;

    switch(MODE)
    {
      case CONTROLLER_MODE:
      {
        CONTROLLER_ORDER_REV = false; 
        cc.GetInfo(a_mode,a_angle,a_speed);
        a_mode = a_angle = a_speed = 0.0;
        MODE = INITIAL_NAV;
        break;
      }

      case STOP:
      {
        #ifdef IS_AUTO
        cc.GetInfo(0,0,0);
        #endif
        MODE=INITIAL_NAV; // 跳转导航模块
        break;
      }

      case INITIAL_NAV:
      {
        if(!all_map.empty())  //是否收到了导航信息,15 is ? zyc
        {
          if(true)//fabs(task_x)>1E-16 && fabs(task_y)>1E-16
          {

            if (!obstacle_stop && delay_end == 101 && is_init_end && newLaserCloudSurfLast == true)
            {
              newLaserCloudSurfLast = false;
              MODE = UPDATE_LOCATION; // 确定导航信息之后，跳转到更新位置模块

            }else{
            	if(newLaserCloudSurfLast == false)
              {
            		cc.GetInfo(0,0,0);
                MODE = STOP;
            	}
            }
          }      
        }
        
        break;
      }

      case UPDATE_LOCATION:
      {
        /*
        计算当前路径(直线)上的 “当前帧” 与 任务目标点的 “目标帧”
        从起点开始遍历找到当前路段的范围，在此基础上寻找最近的“当前帧”
        */
        for(int i = start_turn; i < all_map.size(); i++)
        {
          if(all_map[i].is_turn == 1 && all_map[i].is_finish_turn == 0)
          {
            end_turn = i;
            // 当前帧
            current_index = Current_index_Return(real_time_location.x,
                                                 real_time_location.y,
                                                 all_map,start_turn,
                                                 end_turn);

            task_dis = length_two_points(real_time_location.x,
                                         real_time_location.y,
                                         task_x,task_y); //当前位置与任务点的距离
            // 目标点的帧
            if(task_dis < 1.5)
            {
              task_index = Current_index_Return(task_x,task_y,all_map,
                                                start_turn,end_turn);
              if(task_index > 9000){
                LOG(WARNING)<<"task index out of 10000..."<<task_x<<" "<<task_y<<" "<<start_turn<<" "<<end_turn;
              }
            }
            break;
          }
        }
        log_<<current_index<<","<<task_dis<<",";
        /*
        停下的判断，使用“当前帧”与“地图帧”的index比较作为判据
        满足停下条件，将MODE修改为停下
        */
        if(current_index >= task_index || task_dis < 0.3)//((current_index >= task_index))
        {
          // task_index = 10000;
           log_<<"Stop";

           is_arrived = true;

           if(is_arrived_sent > 0){
           	 std_msgs::Int8 msg;//
		         msg.data = 1;
		         pub_car_arrive.publish(msg);

		         is_arrived_sent--;

		         LOG(WARNING)<<"STOP!";
             LOG(WARNING)<<"task_x y "<<task_x<<" "<<task_y<<" real xy "<<real_time_location.x<<" "<<real_time_location.y<<" "<<task_dis;
           }
	       
	       //cout<<"publish the stop of car"<<endl;
	        LOG(INFO)<<"current_index: "<<current_index<<"  task_index: "<<task_index;

           MODE=STOP;

           continue;
        }

        /* 发送当前帧 */
        std_msgs::Int64 msg;
        msg.data = current_index;
        current_send.publish(msg);

        /* 计算最近拐点及与之的距离  zyc */  
        for(int i = current_index; i < all_map.size(); i++)
        {
          if(all_map[i].is_turn == 1 && all_map[i].is_finish_turn == 0)
          {
            turn_index = i; //最近拐点的index
            if(fabs(real_time_location.heading-180) < 40 || fabs(real_time_location.heading) < 40)
            {
              turn_dis = fabs(all_map[turn_index].y - real_time_location.y);
            }
            else if(fabs(real_time_location.heading - 90) < 40 || fabs(real_time_location.heading + 90) < 40){
              turn_dis = fabs(all_map[turn_index].x - real_time_location.x);
            }
            else{
              turn_dis = length_two_points(real_time_location.x,real_time_location.y,all_map[i].x,all_map[i].y);
            }
            break;
          }
        }

        //LOG(INFO)<<"current_index: "<<current_index<<"  task_index: "<<task_index;

        if((turn_dis < to_turn_point_dis) || turn_index == 0)
        {
          
          /*
          与拐点的距离小于阈值时开始原地转弯
          current_index < task_index 确保在任务结束时不会转弯
          通知里程计已经切换小车模式并停止航位推算
          切换MODE到转弯前准备阶段
          */
          send_mode_vo(real_time_location.x,
                       real_time_location.y,
                       real_time_location.heading,1);
          MODE = TURNING_PRE;
        }
        else
        {
          /*
          未满足条件切换到直走模式
          */
          MODE = FORWARD_MODE;
        }
        break;
      }

      case TURNING_PRE:
      {
        /*
        在此模块进行最优转弯方向确定
        计算需要的转弯角度
        切换模式到 Turning 
        */
 
        /*cls*/

        // if(fabs((real_time_location.heading) - (all_map[turn_index].heading)) > 150)
        // {
        //   direction_ = all_map[turn_index].heading < real_time_location.heading;
        // }
        // else
        // {
        //   direction_ = all_map[turn_index].heading > real_time_location.heading;
        // }

      	if(current_index < all_map.size()-10){
          //LOG(WARNING)
          direction_ = !DetermineTurnDirection(real_time_location.heading, all_map[turn_index].heading);

          cout<< ros::Time::now() <<" first in turn  "<<" "<<real_time_location.heading<<" "<<all_map[turn_index].heading<<" "<<direction_<<endl<<endl;

          MODE = TURNING_;
        }else{
          MODE = STOP;
        }
        break;
      }

      case TURNING_:
      {
        if (fabs((real_time_location.heading) - (all_map[turn_index].heading)) > 12.0)
        {
          /*
          未达到目标角度前一直发送转弯命令
          转弯速度为 turning_speed 
          否则跳转到转弯结束后续处理模块
          */
          cc.GetInfo(1, 0, direction_? -turning_speed:turning_speed);
        }
        else MODE = TURNING_END;
        break;
      }

      case TURNING_END:
      {
        // 通知里程计进行位置航推
        send_mode_vo(real_time_location.x,real_time_location.y,real_time_location.heading,0);

        cout<<"final heading: "<<real_time_location.heading<<endl;

        while(cmode != 0){
        	#ifdef IS_AUTO
            cc.GetInfo(0,0,0);
          #endif
        }
        /*
        标记拐点turn_index已使用
        每一段路径由两个拐点组成，当前原地转弯结束之后将当前拐点置为新路段的起点
        */
        all_map[turn_index].is_finish_turn = 1; 

        start_turn = end_turn; // 初始状态的时候 ？？
        
        if(new_path_race && re_icp_location && (current_index < (all_map.size()-5)))
        {
          /*
          发送转弯完毕重新进行icp匹配信息
          切换模式到STOP
          */
          std_msgs::Int8 msg;
          msg.data = 1;
          turn_end_pub.publish(msg);
          MODE = STOP;

          is_init_end = true;
          delay_end = 0;

          cout<<"turn finish and notify the relocation "<<current_index<<" "<<all_map.size()-10<<endl;
        }
        else
        {
          MODE = STOP;
          re_icp_location = true;
          new_path_race = false;
          bool is_car_stop = (cc.m1_data == 0)&&(cc.m2_data == 0)&&(cc.m3_data == 0)&&(cc.m4_data == 0);
          cout<<"the car have complete the first init "<<is_car_stop<<endl;
        }

        break;
      }

      case FORWARD_MODE:
      {
        // 动态预锚点计算
        SmTarPoi stp;
        stp.GetAllMap(all_map);
        target_index = stp.GetDataAndReturn(real_time_location, current_index, turn_index, speed);
        angle_log << ros::Time::now() << " " << current_index << " " << turn_index << " ";

        //cout<<"fm 1"<<endl;

        
        if(abs(turn_index - target_index) < 2)
        {
          target_index = turn_index;
        }
        

        double Lx,Ly;
        GPSPoint target;
        target.x = all_map[target_index].x;
        target.y = all_map[target_index].y;
        target.GaussX = all_map[target_index].x;
        target.GaussY = all_map[target_index].y;
        angle_log << target.x << " " << target.y << " " << target_index << " " << last_target_index << " ";
        ModifyTargetPoint mtp;

        
        target = mtp.ModifiedTargetPoint(real_time_location,turn_index,all_map,target, stp.target_length);
        

        WorldtoMap(real_time_location,target.GaussX,target.GaussY,Lx,Ly);
        target.LX = Lx;
        target.LY = Ly;
        PointOfTarget.x = Lx;
        PointOfTarget.y = Ly;
        //MODE = Detection.GetData(PointOfTarget,obstacle_point)?AVOIDOBSTACLE:MODE;
        target.heading = all_map[target_index].heading;
        angle = getAngle(-target.LX,target.LY);
        turnctrl_log<<ros::Time::now()<<" "<<real_time_location.x<<" "<<real_time_location.y<<" "<<real_time_location.heading<<" "<<angle<<endl;
        #ifdef IS_AUTO
        cc.GetInfo(0,angle,speed); 
        pub_v_a_modeHandler(0,angle,speed);

        pcctrl_log<<angle<<" "<<a1/100.0<<" "<<a2/100.0<<" "<<a3/100.0<<" "<<a4/100.0<<endl;
        double disofnow2path = 3;
        for (int i = 0; i < all_map.size(); ++i)
        {
        	double temdon2p = length_two_points(all_map[i].x, all_map[i].y, real_time_location.x, real_time_location.y);
        	if(temdon2p < disofnow2path)
        		disofnow2path = temdon2p;
        }

        angle_log << angle << " " << disofnow2path << " " << " " << target.x << " " << target.y << " " << target.LX << " " << target.LY << " " << real_time_location.x << " " << real_time_location.y << " " << real_time_location.heading << endl;

        //LOG(WARNING)<<ros::Time::now()<<" "<<angle<<" "<<speed;
        #endif

        MODE = UPDATE_LOCATION; // 跳转到定位

        break;
      }

      case AVOIDOBSTACLE:
      {
        static bool AVOIDOBSTACLE_TURNING = false;
        if(!AVOIDOBSTACLE_TURNING) // 计算角度
        {
          AVOIDOBSTACLE_TURNING = true;
          cc.GetInfo(0,0,0);
          send_mode_vo(real_time_location.x,
                       real_time_location.y,
                       real_time_location.heading,1);

          int mic_target_index = target_index;
          Point TemptPointOfTarget={0,0};
          for(int j=current_index+1; j<all_map.size(); j++)
          {
            double t_dis = length_two_points(all_map[current_index].x,all_map[current_index].y,all_map[j].x,all_map[j].y);
            double min_obstacle_dis = 0;
            double tempt_dis=0;
            WorldtoMap(real_time_location,all_map[j].x,all_map[j].y,TemptPointOfTarget.x,TemptPointOfTarget.y);
            min_obstacle_dis = length_two_points(TemptPointOfTarget.x,TemptPointOfTarget.y,(obstacle_point.begin())->x,(obstacle_point.begin())->y);
            for(vector<Point>::iterator it=obstacle_point.begin()+1; it != obstacle_point.end(); it++)
            {
              tempt_dis = length_two_points(TemptPointOfTarget.x,TemptPointOfTarget.y,it->x,it->y);
              if(tempt_dis < min_obstacle_dis)
              {
                  min_obstacle_dis = tempt_dis;
              }
            }
            if(t_dis > 2.5 && min_obstacle_dis > 1.2)
            {
              mic_target_index = j;//预描点的index
              break;
            }
          }
          Mic_target.x = all_map[mic_target_index].x;
          Mic_target.y = all_map[mic_target_index].y;

          Mic.GetRoadHeading(all_map[current_index].heading);
          
          LORDeterminer lrd;

          lrd.GetData(PointOfTarget, all_map[current_index].heading, real_time_location.heading, obstacle_point, Mic.LeftOrRightSimulate);

          Mic.GetData(Mic_target,real_time_location,obstacle_point);

          if(!Mic.SimulationTimes())
          {
            last_target_index = mic_target_index;
          }
          else
          {
            MODE = STOP;
          }
          direction_ = !DetermineTurnDirection(real_time_location.heading, Mic.ObjectHeading);
        }
        else if(fabs(real_time_location.heading - Mic.ObjectHeading) > 3) // 转弯中
        {
          cc.GetInfo(1, 0, direction_? -turning_speed:turning_speed);
        }
        else
        {
          AVOIDOBSTACLE_TURNING=false;
          MODE=FORWARD_MODE;  
          send_mode_vo(real_time_location.x,
                       real_time_location.y,
                       real_time_location.heading,0);      
        }
        break;
      }

    }


    log_<<endl;
    status = ros::ok();
    rate.sleep();
  }
  return 0;
}