#include <math.h>
#include <fstream>
#include <string>
#include <sstream>
#include <loam_velodyne/common.h>
#include <loam_velodyne/LocalGeographicCS.hpp>
#include <loam_velodyne/getAngle.h>
#include <nav_msgs/Odometry.h>
#include <opencv/cv.h>
#include <pcl/io/pcd_io.h>
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/kdtree/kdtree_flann.h>
#include <ros/ros.h>
#include <sensor_msgs/Imu.h>
#include <sensor_msgs/PointCloud2.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_broadcaster.h>
#include <boost/format.hpp>
#include <iomanip>
#include "std_msgs/Int64.h"
#include "std_msgs/Int8.h"
#include "std_msgs/String.h"
#include <boost/format.hpp>

#include <loam_velodyne/GaussProjection.h>
#include <loam_velodyne/pcdTool.h>
#include <loam_velodyne/LocalGeographicCS.hpp>
#include <loam_velodyne/geography.hpp>

#include <init/dataIo.h>
#include <init/utility.h>
#include <init/voxelFilter.h>
#include <init/BinaryFeatureExtraction.h>
#include <init/keypointDetection.h>
#include <init/registration.h>
#include <pcl/filters/voxel_grid.h>
//#include <loam_velodyne/pcltools.hpp>

#include <glog/logging.h>
#include <loam_velodyne/GLogHelper.h>

using namespace std;
using namespace pcl;
using namespace keypoint;
using namespace pcRegistration;
using namespace tbb;

CarPara carpara;//小车参数变量
string ALL_MAP;
int init_count_first = 9;
int is_first = 1;
int init_count = 0;
////////////////////////////////////////////////////////////////

double last_stop_x,last_stop_y,last_stop_heading;

vector<GPSPoint> all_key_pc_map;//all map data for init location
double init_x = 0;
double init_y = 0;
int location_init_first = 0;

int is_param_init = 0;

int Search_start = 0;//carpara.Search_start;//初始匹配的搜索起点
int Search_end = 5;//carpara.Search_end;
////////////////////////////////////////////////////////////////

std::ofstream f_o2("/home/chen/Project/catkin_sysu/src/loam_velodyne/output/path_laserLocation_out.csv");
std::ofstream f_o("/home/chen/Project/catkin_sysu/src/loam_velodyne/output/path_laserLocation.csv");
std::ofstream path_o("/home/chen/Project/catkin_sysu/src/loam_velodyne/output/path222.txt");

std::ofstream else_1("/home/chen/Project/catkin_sysu/src/loam_velodyne/output/first_if.txt");
std::ofstream else_2("/home/chen/Project/catkin_sysu/src/loam_velodyne/output/second_if.txt");

std::ofstream turn_log("/home/chen/Project/catkin_sysu/src/loam_velodyne/output/turn_log.txt");

std::ofstream last_pose("/home/chen/Project/catkin_sysu/src/loam_velodyne/output/last_pose.txt");


int keyframe_index = 0;       // 关键帧号
int last_keyframe_index = 0;
int next_keyframe_index = 0;

int keyframe_index_all[3] = {0,0,0}; //last_keyframe_index keyframe_index next_keyframe_index
/****************************/
ros::Publisher send_location;
ros::Publisher init_end_pub;

ros::Subscriber sub_map_data;
ros::Subscriber turn_finish_sub;

ros::Subscriber subLaserCloudCornerLast;
ros::Subscriber subLaserCloudSurfLast;
ros::Subscriber sub_vo;
ros::Subscriber sub_index;
ros::Subscriber down_info;
ros::Subscriber car_stop_sub;

ros::Publisher init_pose_pub;
/****************************/
int current_index = 0;//当前最近地图点index
int turn_index = 0;//最近拐点index
vector<GPSPoint> all_key_pc;//all map data

double radius_search = 10.0;
double delta_distance = 0;//累计行走的里程计长度

/****************************/
double now_x,now_y,now_heading;//根据icp计算得到的当前位置信息
double now_x_1,now_y_1,now_heading_1;//根据icp计算得到的当前位置信息

double last_x = 0;//上次里程计的位置坐标
double last_y = 0;
/****************************/

double o1,o2,o3,o4,a1,a2,a3,a4;//小车底层反馈数据
int car_mode;//当前小车模式

/*************点云相关**********/
pcl::PointCloud<PointType>::Ptr laserCloudCornerLast(new pcl::PointCloud<PointType>());
pcl::PointCloud<PointType>::Ptr laserCloudSurfLast(new pcl::PointCloud<PointType>());

float paramForICP_first[11] = {0,0,0,0,0,0,100,0.15,3.2,2,-0.36};// 用于匹配起始位置的icp配置数据
float paramForICP_normal[11] = {0,0,0,0,0,0,100,0.65,3.2,2,-0.36};// 用于行走中匹配icp的配置数据

float paramForICP_init[11] = {0,0,0,0,0,0,150,2.5,3.2,2,-0.36};// 用于匹配起始位置的icp配置数据

bool newLaserCloudCornerLast = false;
bool newLaserCloudSurfLast = false;
/****************************/

bool is_new_path = false;

double real_time_x,real_time_y,real_time_heading;//实时定位信息

/***********************************************************/

void  send_info(double x,double y,double heading){
    string tmp,r;

    tmp.clear();r.clear();
    tmp = boost::lexical_cast<string>(x);
    r = tmp;

    tmp.clear();
    tmp = boost::lexical_cast<string>(y);
    r.append(" ").append(tmp);

    tmp.clear();
    tmp = boost::lexical_cast<string>(heading);
    r.append(" ").append(tmp);

    std_msgs::String msg;
    msg.data = r;
    send_location.publish(msg);

    LOG(WARNING)<<"icp pose have send..."<<x<<" "<<y<<" "<<heading;
}

void Location_Init_Map(vector<GPSPoint> map,pcl::PointCloud<PointType>::Ptr INPUT,double& ix,double& iy){
    /*第一步：数据的读取*/
    vector<string> fileNames;
    for(int i = 0; i < map.size(); i++)
    {
        //fileNames[i] = map[i].sname;
        fileNames.push_back(map[i].sname);
        //cout<<fileNames[i]<<endl;
    }
    cout<<"frame size: "<<map.size()<<" "<<fileNames.size()<<endl;
    concurrent_vector<pointCloudXYZI> pointClouds(fileNames.size());
    /*第二步:数据预处理--可选项;*/
    float simplified_size = 0.04f;//此变量控制精简大小,单位是米;
    concurrent_vector<pointCloudXYZI> simplifiedPointClouds(fileNames.size());
    pcl::VoxelGrid<pcl::PointXYZI> sor;  //创建滤波对象
    sor.setLeafSize(simplified_size,simplified_size,simplified_size);//设置滤波时创建的体素大小为1cm立方体
    /*第三步关键点检测;*/
    keypointOption kpOption;
    kpOption.radiusFeatureCalculation = 0.4f;
    kpOption.ratioMax = 0.99f;
    kpOption.minPtNum = 20;
    kpOption.radiusNonMax = 0.2f;
    CkeypointDetection kpd (kpOption);
    concurrent_vector<PointIndicesPtr> keyPointIndicePointClouds(fileNames.size());
    /*第四步BSC特征计算*/
    float extract_radius = 0.8;	//特征提取半径;
    unsigned int voxel_side_num = 7;//每一维度的格子个数,建议取值为奇数,可以减少边缘效应对特征计算的影响;
    StereoBinaryFeatureExtractor bsc(extract_radius, voxel_side_num);//创建对象;
    vector<vector<vector<StereoBinaryFeature>>> binaryShapeContextsPointClouds(fileNames.size());

    for(int i = 0 ; i < fileNames.size(); ++i)
    {
        /*第一步:数据读取;*/
        if (pcl::io::loadPCDFile<pcl::PointXYZI>(fileNames[i], pointClouds[i])==-1)
            continue;

        /*第二步:数据预处理--可选项;*/
        sor.setInputCloud(pointClouds[i].makeShared());
        sor.filter(simplifiedPointClouds[i]);

        /*第三步关键点检测;*/
        kpd.keypointDetectionBasedOnCurvature(simplifiedPointClouds[i].makeShared(), keyPointIndicePointClouds[i]);

        if (keyPointIndicePointClouds[i]->indices.empty())
            continue;
        kpd.outputKeypoints(fileNames[i], keyPointIndicePointClouds[i], simplifiedPointClouds[i].makeShared());
        cout <<i<<" FinishKeypointDetection!:" << keyPointIndicePointClouds[i]->indices.size() << endl;

        /*第四步BSC特征计算*/
        bsc.extractBinaryFeatures(simplifiedPointClouds[i].makeShared(), keyPointIndicePointClouds[i],
                                  binaryShapeContextsPointClouds[i]);
        if (binaryShapeContextsPointClouds[i].empty())
            continue;
    }

    /*第五步:利用二进制特征实现点云配准;*/
    CoarseRgOptions coRgopt;
    coRgopt.tolerantHammingDis = 0.2;
    coRgopt.tolerantEuclideanDis = kpOption.radiusNonMax;
    coRgopt.tolerantOverlap = 0.001f;

    RefineRgOptions reRgopt;
    reRgopt.euclideanFitnessEpsilon = 0.0001;
    reRgopt.transformationEpsilon = reRgopt.euclideanFitnessEpsilon;
    reRgopt.maximumIterations = 3;
    reRgopt.maxCorrespondenceDistance = 0.5;
    reRgopt.stepError = 5;
    reRgopt.stepLength = 0.11;

    CRegistration re(coRgopt, reRgopt);

    int index = -1;
    ///////////////////////////////
    PointIndicesPtr keypoint_input;
    kpd.keypointDetectionBasedOnCurvature(INPUT, keypoint_input);
    vector<vector<StereoBinaryFeature>> binaryContext_input;
    bsc.extractBinaryFeatures(INPUT, keypoint_input, binaryContext_input);

    re.One2AllPairRegistration(fileNames,INPUT,binaryContext_input,simplifiedPointClouds,binaryShapeContextsPointClouds,index);

    ix = map[index].x;
    iy = map[index].y;

    cout<<"init location finish and the pose : "<<map[index].x<<" "<<map[index].y<<endl;
}

void Turn_finish_Handler(const std_msgs::Int8::ConstPtr &msg){
    is_first = 1;
    init_count_first = 3;
    init_count = 0;

    is_param_init = 1;

    cout<<"location current_index: "<<current_index<<" "<<turn_index<<endl;

    keyframe_index_all[0] = turn_index+1;
    keyframe_index_all[1] = turn_index+2;
    keyframe_index_all[2] = turn_index+3;

    if(turn_index > 1 && (is_new_path == false) && (current_index < all_key_pc.size()-10)){

        Search_start = turn_index;
        
        if(Search_end < all_key_pc.size()-6){
           Search_end = turn_index + 5; 
        }else{
           Search_end = all_key_pc.size()-1;
        }
    }

    cout<<" restart init by ctrl "<<Search_start<<" "<<Search_end<<endl;
}
/*********ros消息回调*********/
void FinalHandler(const std_msgs::String::ConstPtr &msg)
{
	  real_time_x = real_time_y = real_time_heading = 0;

	  string moves = msg->data;
	  stringstream stringin(moves);
	  stringin>>setprecision(12)>>real_time_x>>real_time_y>>real_time_heading;
}
void laserCloudCornerLastHandler(const sensor_msgs::PointCloud2ConstPtr& laserCloudCornerLast2)
{
  laserCloudCornerLast->clear();
  pcl::fromROSMsg(*laserCloudCornerLast2, *laserCloudCornerLast);

  newLaserCloudCornerLast = true;
}
void laserCloudSurfLastHandler(const sensor_msgs::PointCloud2ConstPtr& laserCloudSurfLast2)
{
  laserCloudSurfLast->clear();
  pcl::fromROSMsg(*laserCloudSurfLast2, *laserCloudSurfLast);

  newLaserCloudSurfLast = true;
}
void InfoHandler(const std_msgs::String::ConstPtr &msg){
  o1 = o2 = o3 = o4 = a1 = a2 = a3 = a4 = 0;
  string moves = msg->data;
  stringstream stringin(moves);
  stringin>>o1>>o2>>o3>>o4>>a1>>a2>>a3>>a4>>car_mode;
}
void IndexHandler(const std_msgs::Int64::ConstPtr &msg){
	current_index = 0;
    current_index = msg->data;
}

void CarStopHandler(const std_msgs::Int8::ConstPtr &msg){

    last_stop_x = 0;
    last_stop_y = 0;
    last_stop_heading = 0;

    last_stop_x = real_time_x;
    last_stop_y = real_time_y;
    last_stop_heading = real_time_heading;

    last_pose<<setprecision(12)<<ros::Time::now()<<" 到达任务点的pose："<<last_stop_x<<" "<<last_stop_y<<" "<<last_stop_heading<<endl;

    LOG(INFO)<<"到达任务点的pose："<<last_stop_x<<" "<<last_stop_y<<" "<<last_stop_heading;
}

void map_Handler(const std_msgs::String::ConstPtr &msg){

  ALL_MAP.clear();
  all_key_pc.clear();

  keyframe_index = 0;
  last_keyframe_index = 0;
  next_keyframe_index = 0;

  last_x = last_y = 0;

  keyframe_index_all[0] = keyframe_index_all[1] = keyframe_index_all[2] = 0;

  current_index = 0;
  turn_index = 0;

  Search_start = 0;
  Search_end = 5;

  is_new_path = true;

  ALL_MAP = msg->data;
  cout<<"path have receive! location"<<endl;

  keyframe_index_all[0] = 0;
  keyframe_index_all[1] = 1;
  keyframe_index_all[2] = 2;//shenrk

  decodePath(ALL_MAP,all_key_pc);//解析规划路径
  cout<<"key map size: "<<all_key_pc.size()<<endl;

  for(int i=0;i<all_key_pc.size();i++){
    //all_key_pc[i].key = 1;
    path_o<<setprecision(12)<<all_key_pc[i].x<<" "<<all_key_pc[i].y<<" "<<all_key_pc[i].sname<<" "<<all_key_pc[i].heading<<" "<<all_key_pc[i].key<<" "<<all_key_pc[i].is_turn<<endl;
  }

  cout<<"当前的pose："<<real_time_x<<" "<<real_time_y<<" "<<real_time_heading<<endl;

  bool stop_pose = fabs(last_stop_x) > 1e-5 && fabs(last_stop_y) > 1e-5 && fabs(last_stop_heading) > 1e-5;

  // if(stop_pose == true){
  //   send_info(last_stop_x,last_stop_y,last_stop_heading);

  //   last_pose<<setprecision(12)<<ros::Time::now()<<" 发送上次的pose："<<last_stop_x<<" "<<last_stop_y<<" "<<last_stop_heading<<endl;

  //   LOG(INFO)<<"发送上次的pose："<<last_stop_x<<" "<<last_stop_y<<" "<<last_stop_heading<<endl;
  // }
}


/****************************/

void location_init(ros::NodeHandle nh){

    cout<<"location init"<<endl;

    subLaserCloudCornerLast = nh.subscribe<sensor_msgs::PointCloud2>
                                            ("/laser_cloud_corner_last", 2, laserCloudCornerLastHandler);
    subLaserCloudSurfLast = nh.subscribe<sensor_msgs::PointCloud2>
                                            ("/laser_cloud_surf_last", 2, laserCloudSurfLastHandler);
    sub_vo = nh.subscribe<std_msgs::String>("/final_data",1000,FinalHandler);
    sub_index = nh.subscribe<std_msgs::Int64>("index_send",5,IndexHandler);
    down_info = nh.subscribe<std_msgs::String>("/odo_send",1000,InfoHandler);

    sub_map_data = nh.subscribe<std_msgs::String>("/map_send",1000,map_Handler);//接收规划的导航路径

    send_location = nh.advertise<std_msgs::String>("location_icp",5);

    init_pose_pub = nh.advertise<std_msgs::String>("global_init_location",5);

    init_end_pub = nh.advertise<std_msgs::Int8>("init_finish",5);

    turn_finish_sub = nh.subscribe<std_msgs::Int8>("turn_finish",5,Turn_finish_Handler);

    car_stop_sub = nh.subscribe<std_msgs::Int8>("car_arrive",5,CarStopHandler);
}

void Calculate_ICP(int map_index, PointCloudT::Ptr cloud, float* para, float* transform){

    PointCloudT::Ptr cloud_target = boost::make_shared<PointCloudT>();
    float RT[6] = {0.0,0.0,0.0,0.0,0.0,0.0};

    for(int i = 0; i < 6; i++){
        transform[i] = 0;
    }

    //cout<<"path: "<<all_key_pc[map_index].sname<<" ";
    pcl::io::loadPCDFile<PointT>(all_key_pc[map_index].sname,*cloud_target);

    if(!cloud_target->points.empty() && cloud_target->points.size() > 1000){
        ICP(cloud_target,cloud,para,RT,0);

        for(int i = 0; i < 6; i++){
            transform[i] = RT[i];
            //cout<<RT[i]<<" ";
        }
        LOG(INFO)<<"icp have complete";
    }else{
        LOG(INFO)<<"error path: "<<all_key_pc[map_index].sname;
        for(int i = 0; i < 6; i++){
            transform[i] = 0;
            //cout<<RT[i]<<" ";
        }
    }
    //cout<<endl;
}

inline float Calculate_ICP_Score(int map_index, PointCloudT::Ptr cloud, float* para, float* transform){

    float score_icp = 0;

    PointCloudT::Ptr cloud_target = boost::make_shared<PointCloudT>();

    pcl::io::loadPCDFile<PointT>(all_key_pc[map_index].sname,*cloud_target);


    if(!cloud_target->points.empty() && cloud_target->points.size() > 1000){

        score_icp = ICP(cloud_target,cloud,para,transform,0);

    }else{
        score_icp = 0;
        cout<<"error path..."<<all_key_pc[map_index].sname<<endl;
        cout<<"icp have not target input for score"<<endl;
    }


    return score_icp;
}


int main(int argc, char** argv)
{
    ros::init(argc, argv, "laserICP");
    ros::NodeHandle nh;
    GLogHelper gh(argv[0]);

    location_init(nh);
    
    DecodePara("/home/chen/Project/catkin_sysu/src/loam_velodyne/carPara.ini",carpara);
    ALL_MAP = "";

    

    double pc_rate = 0;
    double turn_dis = 0;
    vector<int> s_index_v;
    int index_sum;

    // real_time_x = -0.0074;
    // real_time_y = 51.1586;

    ros::Rate rate(150);
    bool status = ros::ok();
    while(status)
    {
        ros::spinOnce();

        double mindis_mk = 1000;
        double mindis_turn = 1000;

        if(false && newLaserCloudSurfLast == true && location_init_first == 0)//全局定位初匹配
        {

            cout<<"start init location"<<endl;
            Location_Init_Map(all_key_pc_map,laserCloudSurfLast,init_x,init_y);

            string init_s = "";
            string tmp = "";

            tmp = boost::lexical_cast<string>(init_x);
            init_s.append(tmp);

            tmp.clear();
            tmp = boost::lexical_cast<string>(init_y);
            init_s.append(" ").append(tmp);
            cout<<"init send to net : "<<init_s<<endl;

            std_msgs::String msg;
            msg.data = init_s;

            init_pose_pub.publish(msg);

            location_init_first = 1;
            newLaserCloudSurfLast = false;
        }

        if(newLaserCloudSurfLast == true && !all_key_pc.empty() && (all_key_pc.size() > 15))//ALL_MAP.compare("") != 0 && all_key_pc.size() > 0
        {
            PointCloudT::Ptr cloud_source = boost::make_shared<PointCloudT>();

            for(int i = current_index ; i < all_key_pc.size() ; i++)
            {
                if(all_key_pc[i].is_turn == 1)
                {
                    turn_index = i;
                    break;
                }
            }
            
            delta_distance += sqrt((last_x-real_time_x)*(last_x-real_time_x) + (last_y - real_time_y)*(last_y - real_time_y));

            bool is_same_direction = fabs(real_time_heading - all_key_pc[turn_index].heading) < 10.0;

            if(is_first == 1 && (current_index < all_key_pc.size()-10)){

                if(is_same_direction == true){
                    double NOWXf[3],NOWYf[3],NOWHf[3],SCOREf[3];
                    float  CUR_RTf[3][6] = {
                        {0.0,0.0,0.0,0.0,0.0,0.0},
                        {0.0,0.0,0.0,0.0,0.0,0.0},
                        {0.0,0.0,0.0,0.0,0.0,0.0}
                    };

                    TransformPC(laserCloudSurfLast,cloud_source);

                    tbb::parallel_for(size_t(0), size_t(3), [&](size_t i)
                    {
                        int index = keyframe_index_all[i];
                        float pos[6] = {0, all_key_pc[index].heading,
                                        0, all_key_pc[index].x,
                                        0, all_key_pc[index].y}; // tanzby

                        /*Initial value for ICP iteration*/
                        float paramForICP_normal[11] = {0,
                                                        real_time_heading - all_key_pc[index].heading,
                                                        0,
                                                        real_time_x - all_key_pc[index].x,
                                                        0,
                                                        real_time_y - all_key_pc[index].y,
                                                        100,0.9,3.2,2,-0.36};

                        SCOREf[i] = Calculate_ICP_Score(index,cloud_source,paramForICP_normal,CUR_RTf[i]);
                        //Calculate_ICP(index,cloud_source,paramForICP_normal,CUR_RT[i]);
                        transform(CUR_RTf[i],pos);
                        NOWXf[i]= pos[3];
                        NOWYf[i]= pos[5];
                        NOWHf[i]= pos[1];
                    });

                    SCOREf[0] = 1/(SCOREf[0]+1E-32);
                    SCOREf[1] = 1/(SCOREf[1]+1E-32);
                    SCOREf[2] = 1/(SCOREf[2]+1E-32);

                    double SCORE_SUM= SCOREf[0]+ SCOREf[1]+ SCOREf[2];

                    SCOREf[0] = SCOREf[0]/SCORE_SUM;
                    SCOREf[1] = SCOREf[1]/SCORE_SUM;
                    SCOREf[2] = SCOREf[2]/SCORE_SUM;

                    double init_point_x = SCOREf[0]*NOWXf[0]+SCOREf[1]*NOWXf[1]+SCOREf[2]*NOWXf[2];//最终的icp计算得到的位置坐标
                    double init_point_y = SCOREf[0]*NOWYf[0]+SCOREf[1]*NOWYf[1]+SCOREf[2]*NOWYf[2];
                    double init_heading = SCOREf[0]*NOWHf[0]+SCOREf[1]*NOWHf[1]+SCOREf[2]*NOWHf[2];

                    double dis_2p_12 = length_two_points(NOWXf[0],NOWYf[0],NOWXf[1],NOWYf[1]);
                    double dis_2p_13 = length_two_points(NOWXf[0],NOWYf[0],NOWXf[2],NOWYf[2]);
                    double dis_2p_23 = length_two_points(NOWXf[1],NOWYf[1],NOWXf[2],NOWYf[2]);

                    bool dis_icp = dis_2p_12 <= 0.2 && dis_2p_13 <= 0.2 && dis_2p_23 <= 0.2;

                    double dis_2h_12 = fabs(NOWHf[0]-NOWHf[1]);
                    double dis_2h_13 = fabs(NOWHf[0]-NOWHf[2]);
                    double dis_2h_23 = fabs(NOWHf[1]-NOWHf[2]);

                    bool dis_icp_heading = dis_2h_12 < 0.1 && dis_2h_13 < 0.1 && dis_2h_23 < 0.1;

                    double dis_send = length_two_points(real_time_x,real_time_y,init_point_x,init_point_y);

                    LOG(ERROR)<<"first match: "<<init_point_x<<" "<<init_point_y<<" "<<init_heading;

                    if(dis_icp_heading == false){
                        LOG(ERROR)<<"init heading..."<<init_heading<<" "<<real_time_heading;

                        init_heading = real_time_heading;

                        
                    }
                    if(dis_send > 0.5){

                        LOG(ERROR)<<"init xy..."<<init_point_x<<" "<<init_point_y<<" "<<real_time_x<<" "<<real_time_y;

                        init_point_x = real_time_x;
                        init_point_y = real_time_y;

                        
                    }
                    
                    send_info(init_point_x,init_point_y,init_heading);

                    std_msgs::Int8 msg;
                    msg.data = 1;
                    init_end_pub.publish(msg);

                    LOG(ERROR)<<"final match result: "<<init_point_x<<" "<<init_point_y<<" "<<init_heading;


                    is_first = 0;
                }

            }else{

                turn_dis = length_two_points(real_time_x,real_time_y,all_key_pc[turn_index].x,all_key_pc[turn_index].y);

                if(real_time_x != 0 && real_time_y != 0 && current_index > 0)
                {
                    for(int i = current_index; i < all_key_pc.size(); i++)
                    {
                        if(all_key_pc[i].key == 1)
                        {
                            keyframe_index = i;
                            break;
                        }
                    }

                    for(int j = current_index-1; j > 0; j--)
                    {
                        if(all_key_pc[j].key == 1)
                        {
                            last_keyframe_index = j;
                            break;
                        }
                    }

                    for(int k = keyframe_index+1; k < all_key_pc.size(); k++){
                    	if(all_key_pc[k].key == 1)
                        {
                            next_keyframe_index = k;
                            break;
                        }
                    }
                    /******************************************/
                    keyframe_index_all[0] = last_keyframe_index;
                    keyframe_index_all[1] = keyframe_index;
                    keyframe_index_all[2] = next_keyframe_index;
                    /******************************************/

                    //cout<<"current_index: "<<current_index<<" last keyframe_index: "<<last_keyframe_index<<" next keyframe_index: "<<next_keyframe_index;

                    mindis_mk = length_two_points(real_time_x,real_time_y,all_key_pc[keyframe_index].x,all_key_pc[keyframe_index].y);

                    //cout<<"keyframe_index: "<<keyframe_index<<endl;
                    //cout<<"pc name: "<<all_key_pc[keyframe_index].sname<<endl;

                    PointCloudT::Ptr cloud_target = boost::make_shared<PointCloudT>();
                    TransformPC(laserCloudSurfLast,cloud_source);//读取和转换点云数据
                    pcl::io::loadPCDFile<PointT>(all_key_pc[keyframe_index].sname,*cloud_target);

                    pc_rate = (double)(cloud_source->points.size()*1.0) / (cloud_target->points.size() * 1.0);
                    //两帧匹配的点云数量要求限制
                    bool is_ok = pc_rate > 0.5 && pc_rate < 2.0 && cloud_source->points.size() > 1000 && cloud_target->points.size() > 1000 ;
                    //两帧点云数量比例限制
                    bool is_angle_ok = fabs(fabs(all_key_pc[keyframe_index].heading) - fabs(all_key_pc[last_keyframe_index].heading)) < 0.174;
                    //当前关键帧和上次关键帧之间的航向角角度差需要小于阈值


                    bool is_heading_ok = fabs(fabs(real_time_heading) - fabs(all_key_pc[keyframe_index].heading)) < 0.785 && fabs(fabs(real_time_heading) - fabs(all_key_pc[last_keyframe_index].heading)) < 0.785;
                    //当前点云帧的航向角与当前关键帧和上次关键帧的航向角之间也需要限制

                    f_o2<<setprecision(12)<<ros::Time::now()<<" current_index: "<<current_index<<" keyframe_index: "<<keyframe_index<<" pc_rate: "<<pc_rate<<" source_size: "
                                          <<cloud_source->points.size()<<" target_size: "<<cloud_target->points.size()<<" delta_map_heading: "
                                          <<fabs(all_key_pc[keyframe_index].heading - all_key_pc[last_keyframe_index].heading)<<" time_delta_heading: "
                                          <<fabs(fabs(real_time_heading) - fabs(all_key_pc[keyframe_index].heading))<<" "
                                          <<fabs(fabs(real_time_heading) - fabs(all_key_pc[last_keyframe_index].heading))<<" turn_dis: "<<turn_dis<<" ";

                    //cout<<current_index<<" "<<last_keyframe_index<<" "<<is_heading_ok<<" "<<is_ok<<" "<<is_angle_ok<<endl;

                    if(mindis_mk < radius_search && is_ok == true && is_angle_ok == true && car_mode == 0)  //LYM
                    {

                        /*********tbb for icp***********/
                       	double NOWX[3],NOWY[3],NOWH[3],SCORE[3];
                        float  CUR_RT[3][6] = {
                            {0.0,0.0,0.0,0.0,0.0,0.0},
                            {0.0,0.0,0.0,0.0,0.0,0.0},
                            {0.0,0.0,0.0,0.0,0.0,0.0}
                        };

                        tbb::parallel_for(size_t(0), size_t(3), [&](size_t i)
                        {
                            int index = keyframe_index_all[i];
                            float pos[6] = {0, all_key_pc[index].heading,
                                            0, all_key_pc[index].x,
                                            0, all_key_pc[index].y}; // tanzby

                            /*Initial value for ICP iteration*/
                            float paramForICP_normal[11] = {0,
                                                            real_time_heading - all_key_pc[index].heading,
                                                            0,
                                                            real_time_x - all_key_pc[index].x,
                                                            0,
                                                            real_time_y - all_key_pc[index].y,
                                                            100,0.9,3.2,2,-0.36};

                            SCORE[i] = Calculate_ICP_Score(index,cloud_source,paramForICP_normal,CUR_RT[i]);
                            //Calculate_ICP(index,cloud_source,paramForICP_normal,CUR_RT[i]);
                            transform(CUR_RT[i],pos);
                            NOWX[i]= pos[3];
                            NOWY[i]= pos[5];
                            NOWH[i]= pos[1];

                        });

                        else_1<<ros::Time::now()<<" cindex "<<current_index<<" "<<keyframe_index<<" "<<last_keyframe_index<<" "<<next_keyframe_index<<" ";
                        else_1<<setprecision(12)<<"rxy "<<real_time_x<<" "<<real_time_y<<" "<<real_time_heading<<" ";
                        for(int i=0;i<3;i++){
                            else_1<<setprecision(12)<<" p"<<i<<" "<<NOWX[i]<<" "<<NOWY[i]<<" "<<NOWH[i]<<" "<<SCORE[i];
                        }

                        SCORE[0] = 1/(SCORE[0]+1E-32);
                        SCORE[1] = 1/(SCORE[1]+1E-32);
                        SCORE[2] = 1/(SCORE[2]+1E-32);

                        double SCORE_SUM= SCORE[0]+ SCORE[1]+ SCORE[2];

                        SCORE[0] = SCORE[0]/SCORE_SUM;
                        SCORE[1] = SCORE[1]/SCORE_SUM;
                        SCORE[2] = SCORE[2]/SCORE_SUM;

                        double mid_point_x = SCORE[0]*NOWX[0]+SCORE[1]*NOWX[1]+SCORE[2]*NOWX[2];//最终的icp计算得到的位置坐标
                        double mid_point_y = SCORE[0]*NOWY[0]+SCORE[1]*NOWY[1]+SCORE[2]*NOWY[2];
                        double mid_heading = SCORE[0]*NOWH[0]+SCORE[1]*NOWH[1]+SCORE[2]*NOWH[2];

                        last_x = real_time_x;//更新上次的定位信息
                        last_y = real_time_y;

                        ///////////////////////////////////////////////////////////////////////
                        double dis_2p_12 = length_two_points(NOWX[0],NOWY[0],NOWX[1],NOWY[1]);
                        double dis_2p_13 = length_two_points(NOWX[0],NOWY[0],NOWX[2],NOWY[2]);
                        double dis_2p_23 = length_two_points(NOWX[1],NOWY[1],NOWX[2],NOWY[2]);

                        bool dis_icp = dis_2p_12 < 0.2 && dis_2p_13 < 0.2 && dis_2p_23 < 0.2;

                        double dis_2h_12 = fabs(NOWH[0]-NOWH[1]);
                        double dis_2h_13 = fabs(NOWH[0]-NOWH[2]);
                        double dis_2h_23 = fabs(NOWH[1]-NOWH[2]);

                        bool dis_icp_heading = dis_2h_12 < 0.2 && dis_2h_13 < 0.2 && dis_2h_23 < 0.2;

                        double dis_send = length_two_points(real_time_x,real_time_y,mid_point_x,mid_point_y);

                        
                        else_1<<setprecision(12)<<" fp "<<mid_point_x<<" "<<mid_point_y<<" "<<mid_heading<<" ";
                        else_1<<setprecision(12)<<"dis_p "<<dis_2p_12<<" "<<dis_2p_13<<" "<<dis_2p_23<<" ";
                        else_1<<setprecision(12)<<"dis_h "<<dis_2h_12<<" "<<dis_2h_13<<" "<<dis_2h_23<<" ";
                        else_1<<setprecision(12)<<"dis_send "<<dis_send<<" delta_distance "<<delta_distance<<" turn_dis "<<turn_dis<<" ";

                        /*******************************/

                        //将满足下列限制的位置坐标发送至里程计中进行误差纠正
                        //cout<<"dis_icp: "<<dis_icp<<" "<<dis_icp_heading<<" "<<dis_send<<" "<<delta_distance<<endl;
                        //&& delta_distance > 0.8 delete      ZQQ

                       
                        if(dis_icp == false)
                            LOG(ERROR) << "dis_icp == false!!" << endl;
                        if(dis_icp_heading == false)
                            LOG(ERROR) << "dis_icp_heading == false!!" << endl;
                        if(dis_send >= 0.8)
                            LOG(ERROR) << "dis_send >= 0.8!!" << endl;


                        if(dis_icp == true && dis_icp_heading == true && car_mode == 0 && dis_send < 1.0  && turn_dis > 0.3 && current_index >= 6 && (current_index <= (all_key_pc.size()-6)))
                        {
                            //cout<<"send"<<endl;
                            send_info(mid_point_x,mid_point_y,mid_heading);
                            delta_distance = 0;

                            else_1<<"send"<<endl;

                            f_o2<<"send"<<endl;
                            cout<<" send to vo"<<endl;
                        }else{
                            //cout<<" "<<endl;
                            else_1<<endl;
                            f_o2<<endl;

                            if(turn_dis <= 0.3){
                                turn_log<<setprecision(12)<<"cindex "<<keyframe_index<<" ";
                                turn_log<<setprecision(12)<<"realxy "<<real_time_x<<" "<<real_time_y<<" "<<real_time_heading<<" ";
                                for(int i=0;i<3;i++){
                                    turn_log<<setprecision(12)<<" p"<<i<<" "<<NOWX[i]<<" "<<NOWY[i]<<" "<<NOWH[i]<<" ";
                                }
                                turn_log<<setprecision(12)<<" fp "<<mid_point_x<<" "<<mid_point_y<<" "<<mid_heading<<" ";
                                turn_log<<setprecision(12)<<"dis_p "<<dis_2p_12<<" "<<dis_2p_13<<" "<<dis_2p_23<<" ";
                                turn_log<<setprecision(12)<<"dis_h "<<dis_2h_12<<" "<<dis_2h_13<<" "<<dis_2h_23<<" ";
                                turn_log<<setprecision(12)<<"dis_send "<<dis_send<<" delta_distance "<<delta_distance<<" ";
                                turn_log<<setprecision(12)<<"turn_dis "<<turn_dis<<endl;
                            }

                            // else_2<<setprecision(12)<<dis_icp<<" "<<dis_icp_heading<<" "<<delta_distance<<" "<<current_index<<" "<<keyframe_index<<" ";
                            // for(int i=0;i<6;i++){//first rt
                            //     else_2<<setprecision(12)<<RT_1[i]<<" ";
                            // }
                            // else_2<<endl;
                        }

                    }else{
                        f_o2<<"no do icp"<<endl;
                            // else_1<<setprecision(12)<<current_index<<" "<<last_keyframe_index<<" "<<is_heading_ok<<" "<<is_ok<<" "<<is_angle_ok<<endl;
                    }

                }
            }

        }

        status = ros::ok();
        rate.sleep();
    }
    return 0;
}
// now_x = now_y = now_x_1 = now_y_1 = now_heading = now_heading_1 = 0;

                        // /****************part 1*********************/
                        // float pos[6] = {0,all_key_pc[keyframe_index].heading,0, all_key_pc[keyframe_index].x,0,all_key_pc[keyframe_index].y};// tanzby
                        // float RT_1[6] = {0.0,0.0,0.0,0.0,0.0,0.0};
                        // /********************/
                        // paramForICP_normal[1] = real_time_heading - all_key_pc[keyframe_index].heading;
                        // // paramForICP_normal[3] = real_time_x - all_key_pc[keyframe_index].x;
                        // // paramForICP_normal[5] = real_time_y - all_key_pc[keyframe_index].y;
                        // /********************/
                        // Calculate_ICP(keyframe_index,cloud_source,paramForICP_normal,RT_1);

                        // transform(RT_1,pos);
                        // now_x = pos[3];
                        // now_y = pos[5];
                        // now_heading = pos[1];
                        // /*****************************************/

                        // /****************part 2*********************/
                        // //memset(paramForICP_normal,0,sizeof(paramForICP_normal));
                        // float pos1[6] = {0,all_key_pc[last_keyframe_index].heading,0, all_key_pc[last_keyframe_index].x,0,all_key_pc[last_keyframe_index].y};
                        // float RT_2[6] = {0.0,0.0,0.0,0.0,0.0,0.0};
                        // /********************/
                        // paramForICP_normal[1] = real_time_heading - all_key_pc[last_keyframe_index].heading;
                        // // paramForICP_normal[3] = real_time_x - all_key_pc[last_keyframe_index].x;
                        // // paramForICP_normal[5] = real_time_y - all_key_pc[last_keyframe_index].y;
                        // /********************/
                        // Calculate_ICP(last_keyframe_index,cloud_source,paramForICP_normal,RT_2);

                        // transform(RT_2,pos1);
                        // now_x_1 = pos1[3];
                        // now_y_1 = pos1[5];
                        // now_heading_1 = pos1[1];
                        // /*****************************************/

                        // double dis_icp = length_two_points(now_x,now_y,now_x_1,now_y_1);//两次icp之间计算得到的坐标的距离

                        // double dis_icp_heading = fabs(now_heading-now_heading_1);//两次icp之间计算得到的航向角的差值

                        // double dis_send = length_two_points(real_time_x,real_time_y,(now_x+now_x_1)/2,(now_y+now_y_1)/2);//icp最终算到的位置坐标和此时定位坐标之间的距离



                        // double mid_point_x = (now_x+now_x_1)/2;//最终的icp计算得到的位置坐标
                        // double mid_point_y = (now_y+now_y_1)/2;

                        // f_o<<setprecision(12)<<"current_index: "<<current_index<<" keyframe_index: "<<keyframe_index<<" last_keyframe_index: "<<last_keyframe_index<<" now_x: "<<now_x<<" now_y: "<<now_y<<" now_heading: "
                        //                      <<now_heading<<" now_x_1: "<<now_x_1<<" now_y_1: "<<now_y_1<<" now_heading_1: "<<now_heading_1<<" mka_f_x: "<<real_time_x<<" mka_f_y: "<<real_time_y<<" mka_f_heading: "<<real_time_heading<<" car_mode: "
                        //                      <<car_mode<<" dis_icp: "<<dis_icp<<" dis_icp_heading: "
                        //                      <<dis_icp_heading<<" delta_distance: "<<delta_distance<<" last: "<<last_x<<" "<<last_y<<endl;



// double mindis = 100000;
                // int s_index = 0;//start location index
                // float RTs[6] = {0.0,0.0,0.0,0.0,0.0,0.0};

                // TransformPC(laserCloudSurfLast,cloud_source);
                // cout<<Search_start<<" "<<Search_end<<endl;
                // /********************************************/
                // for(int i = Search_start; i < Search_end; i++)
                // {
                //     if(is_param_init == 0){
                //         Calculate_ICP(i,cloud_source,paramForICP_first,RTs);
                //     }else{
                //         Calculate_ICP(i,cloud_source,paramForICP_init,RTs);
                //     }
                //     //cout<<" point name: "<<all_key_pc[i].sname<<endl;
                //     // 更新最近帧
                //     float dis = RTs[3]*RTs[3] + RTs[4]*RTs[4] + RTs[5]*RTs[5];
                //     if(mindis > dis)
                //     {
                //         mindis = dis;
                //         s_index = i; 
                //     }
                // }

                // s_index_v.push_back(s_index);
                // cout << "count = " << init_count << endl;
                // if(init_count == init_count_first)
                // {
                //     //cout<<s_index_v.size()<<endl;
                //     sort(s_index_v.begin(),s_index_v.end());
                //     int mid_index = s_index_v.size() / 2 + 1;
                //     s_index = s_index_v[mid_index];//final index is s_index

                //     float RT[6] = {0.0,0.0,0.0,0.0,0.0,0.0};
                //     //Calculate_ICP(s_index,cloud_source,paramForICP_first,RT);
                //     if(is_param_init == 0){
                //         Calculate_ICP(s_index,cloud_source,paramForICP_first,RT);
                //     }else{
                //         Calculate_ICP(s_index,cloud_source,paramForICP_init,RT);
                //     }

                //     float pos[6] = {0,all_key_pc[s_index].heading,0, all_key_pc[s_index].x,0,all_key_pc[s_index].y};// tanzby

                //     transform(RT,pos);
                //     now_x = pos[3];
                //     now_y = pos[5];
                //     now_heading = pos[1];

                //     send_info(now_x,now_y,now_heading);

                //     is_first = 0;

                //     std_msgs::Int8 msg;
                //     msg.data = 1;
                //     init_end_pub.publish(msg);

                //     LOG(ERROR)<<"first match: "<<s_index<<" "<<now_x<<" "<<now_y<<" "<<now_heading;

                //     s_index_v.clear();
                //     is_new_path = false;

                //     // if(dis_set != NULL){
                //     //   delete[] dis_set;
                //     //   LOG(INFO)<<"delete the dis set";
                //     // }
                // }
                // init_count++;