#include <loam_velodyne/geography.hpp>
#include <iostream>

double vertical_direction(const double direction) {
    double v_direction;
    v_direction = direction + 90;

    if (v_direction > 360)
        v_direction -= 360;
    else if (v_direction < 0)
        v_direction += 360;

    return v_direction;
}

double inverse_direction(const double direction) {
    double i_direction;
    i_direction = direction + 180;

    if (i_direction > 360)
        i_direction -= 360;
    else if (i_direction < 0)
        i_direction += 360;

    return i_direction;
}

double ll_heading(double lat0, double lon0, double lat1, double lon1) {
    double x0, y0, x1, y1;
    cs.ll2xy(lat0, lon0, x0, y0);
    cs.ll2xy(lat1, lon1, x1, y1);
    //std::cout<<setprecision(12)<<x0<<" "<<y0<<" "<<x1<<" "<<y1<<std::endl;
    return xy_heading(x0, y0, x1, y1);
}

double xy_heading(double x0, double y0, double x1, double y1) {
    double xxx;
    double xx = (x1 - x0);
    double yy = (y1 - y0);

    double length = sqrt(xx * xx + yy * yy);

    if (length == 0)
        length = 0.000000001;

    double theta = 0.0;
    double theta_d = 0.0;
    xxx = xx;
    xxx = fabs(xx);
    //std::cout <<" x0 = "<< x0  << " y0 = " << y0 << " x1 = " << x1 << " y1 = " << y1 << " xxx = " <<  xxx <<  " length = " << length << " ";
    if (xx > 0 && yy > 0) { // 1
        theta = asin(xxx / length);
        theta_d = to_degrees(theta);
    }
    if (xx < 0 && yy > 0) { //4
        theta = asin(xxx / length);
        theta_d = 360 - to_degrees(theta);
    }
    if (xx > 0 && yy < 0) { //2
        theta = asin(xxx / length);
        theta_d = 180 - to_degrees(theta);
    }
    if (xx < 0 && yy < 0) { //3
        theta = asin(xxx / length);
        theta_d = 180 + to_degrees(theta);
     }
    //theta = asin(xxx / length);
    //theta_d = to_degrees(theta);

    if (xx == 0 && yy > 0)
        theta_d = 0;
    if (xx == 0 && yy < 0)
        theta_d = 180;
    if (xx > 0 && yy == 0)
        theta_d = 90;
    if (xx < 0 && yy == 0)
        theta_d = 270;
    //std::cout << " theta = " << theta_d << std::endl;
    return theta_d;
}
double ll_distance(const double lat0, const double lon0, const double lat1, const double lon1) {
    double x0, y0, x1, y1;
    cs.ll2xy(lat0, lon0, x0, y0);
    cs.ll2xy(lat1, lon1, x1, y1);
    return hypot(x1 - x0, y1 - y0);
}

double ll_mdistance(const double lat0, const double lon0, const double lat1, const double lon1) {
    double x0, y0, x1, y1;
    cs.ll2xy(lat0, lon0, x0, y0);
    cs.ll2xy(lat1, lon1, x1, y1);
    return fabs(x1 - x0) + fabs(y1 - y0);
}

double xy_distance(const double x0, const double y0, const double x1, const double y1) {
    return hypot(x1 - x0, y1 - y0);
}

double xy_mdistance(const double x0, const double y0, const double x1, const double y1) {
    return fabs(x1 - x0) + fabs(y1 - y0);
}
