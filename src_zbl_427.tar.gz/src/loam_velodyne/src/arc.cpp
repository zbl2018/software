
#include <loam_velodyne/arc.h>
#define PI 3.1415926535898

void Arc::GetTargetPoint(const Point & t)
{

	target = t;
	radius = (target.x * target.x + target.y * target.y) / 2.0 / target.x;
	theta = 2.0 * asin(sqrt(target.x*target.x + target.y*target.y) / 2.0 / radius);
	SmallTheta = theta / INTERVAL;
	Compute20Points();

}

void Arc::Compute20Points()
{
	double x_;
	double y_;
	double theta_ = SmallTheta;
	Point tempt;
	TheSetOfPointsOnTheArc.clear();
	for(int i=0;i < INTERVAL; i++)
	{

		y_ = radius * sin(theta_);
		x_ = y_ / tan((PI - theta_) / 2.0);
		theta_ += SmallTheta;
		tempt.x = x_;
		tempt.y = y_;
		TheSetOfPointsOnTheArc.push_back(tempt);

	}

}