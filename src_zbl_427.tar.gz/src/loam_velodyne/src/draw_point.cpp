#include <GL/glut.h>
#include <fstream>
#include <vector>
#include <sstream>
#include <ros/ros.h>
#include <sensor_msgs/Imu.h>
#include <sensor_msgs/PointCloud2.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_broadcaster.h>
#include <iostream>
#include "std_msgs/Int8.h"
#include <loam_velodyne/getAngle.h>
#include <loam_velodyne/common.h>
#include "std_msgs/String.h"

#include <sensor_msgs/Imu.h>
#include <sensor_msgs/NavSatFix.h>
#include <geometry_msgs/PoseStamped.h>

using namespace std;

CarPara carpara;
string ALL_MAP;
string map_file_name;
string draw_map;

vector<GPSPoint> all_key_pc;//all map data
vector<GPSPoint> key_frame;
vector<GPSPoint> turn_frame;

struct coord
{
	double x;
	double y;
};

struct task_point
{
  coord task;
  vector<coord> arrived;
};

double x,y;
vector<coord> v;
vector<coord> v_new;
vector<coord> v_target;
vector<coord> v_location;
vector<coord> v_GPS;

vector<task_point> all_task;

//ros::Subscriber sublocation;
ros::Subscriber sub_task;
ros::Subscriber sub_arrived_pose;

double o1,o2,o3,o4,a1,a2,a3,a4;
double f_lat,f_lon,f_heading;

double init_x,init_y,init_heading;

double lat,lon,heading;
int is_lidar;
double GaussX,GaussY;

/////////////////////////////////
double task_x,task_y,task_speed;
double arrive_x,arrive_y;
bool is_car_arrived = false;
int task_index = 0;

vector<coord> arrive_task_set;
////////////////////////////////

void readDataAll_Local(const char* filename,vector<GPSPoint>& pcs){//read the map data to vector
  ifstream infile_feat(filename);
  GPSPoint gps;
  while(infile_feat>>setprecision(12)>>gps.x>>gps.height>>gps.y>>gps.cname>>gps.sname>>gps.heading>>gps.key>>gps.is_turn)
  {    
      pcs.push_back(gps); 

      if(gps.key == 1){
        key_frame.push_back(gps);
      }

      if(gps.is_turn == 1){
        turn_frame.push_back(gps);
      }
  }
  infile_feat.close();
}

void timerCb(int value) {
  //cout<<"once"<<endl;
  ros::spinOnce();

  glutTimerFunc(1, timerCb, 0);
}

void readfile(const char* file_name)
{
	ifstream getInfo(file_name);
	
	coord temp;
	getInfo >> x >> y; //初始坐标
	while(!getInfo.eof())
	{
		getInfo >> temp.x >> temp.y;
   // temp.x *= -1;
		temp.x -= x;
		temp.y -= y;
		v.push_back(temp);
		
	}
	getInfo.close();
}

void SubTaskHandler(const std_msgs::String::ConstPtr &msg){
  string ss = msg->data;
  stringstream strings(ss);

  task_x = task_y = task_speed = 0;

  strings>>setprecision(12)>>task_x>>task_y>>task_speed;

  task_point now_task;
  now_task.task.x = task_x;
  now_task.task.y = task_y;

  all_task.push_back(now_task);
  cout<<"task xy..."<<task_x<<" "<<task_y<<endl;
  cout<<"all_task size..."<<all_task.size()<<endl;

  is_car_arrived = false;
  task_index = 0;
}

void SubArrivedHandler(const std_msgs::String::ConstPtr &msg){
  string ss = msg->data;
  stringstream strings(ss);

  arrive_x = arrive_y = 0;

  strings>>setprecision(12)>>arrive_x>>arrive_y;
  is_car_arrived = true;
  cout<<"arrived pose..."<<arrive_x<<" "<<arrive_y<<endl;

  for(int i = 0; i < all_task.size(); i++)
  {
    if(fabs(all_task[i].task.x - task_x) < 1E-5 && fabs(all_task[i].task.y - task_y) < 1E-5)
    {
      //all_task[i].arrived
      coord c;
      c.x = arrive_x;
      c.y = arrive_y;
      all_task[i].arrived.push_back(c);
      break;
    }
  }
}



void view()
{

	  glClear(GL_COLOR_BUFFER_BIT);
   	// glLineWidth(2);
    // glColor3d(0,1,0);
    // glBegin(GL_LINE_STRIP);
    // for(vector<coord>::iterator it = v.begin(); it != v.end()-1;it++)
    // {
    // 	glVertex2d(-(it->x), it->y);//绘图坐标系改为右手系   祖冰修改-8-29
    // }
    // glEnd();
    

    if(true)
    {
      glPointSize(6); 
      glColor3d(1,0,3);
      glBegin(GL_POINTS);
      for(vector<coord>::iterator it = arrive_task_set.begin(); it != arrive_task_set.end();it++)
      {
          //cout <<"...draw..."<< it->x << " " << it->y << endl;
          glVertex2d(-(it->x), it->y); //绘图坐标系改为右手系 祖冰修改-8-29
      }
      glEnd();

      glPointSize(5);
      glColor3d(0,0,0);
      glBegin(GL_POINTS);
      glVertex2d(-(task_x-x),(task_y-y));
      glEnd();
    }

    
    glutSwapBuffers(); 
}

void update()
{
     //coord newData;
    // coord tempt_Location;

    // tempt_Location.x = GaussX - x;
    // tempt_Location.y = GaussY - y;
    // v_location.push_back(tempt_Location);

    // newData.x = init_x - x;
    // newData.y = init_y - y;
	  // v_new.push_back(newData); // 更新的坐标

    if(is_car_arrived == true)
    {
      for(int i = 0; i < all_task.size(); i++)
      {
        if(fabs(all_task[i].task.x - task_x) < 1E-5 && fabs(all_task[i].task.y - task_y) < 1E-5)
        {
          task_index = i;
          break;
        }
      }

      for(int i = 0; i < all_task[task_index].arrived.size(); i++)
      {
        coord newData;
        newData.x = all_task[task_index].arrived[i].x - x;
        newData.y = all_task[task_index].arrived[i].y - y;

        arrive_task_set.push_back(newData);
      }
      cout<<"arrive_task_set size..."<<arrive_task_set.size()<<" task index..."<<task_index<<endl;
    }else{
      //arrive_task_set.clear();
    }

    
	  glutPostRedisplay();
}

void Initial()
{
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f);  //清屏颜色
    glMatrixMode(GL_PROJECTION);
    gluOrtho2D(-25, 25, -25.0, 25.0);   //投影到裁剪窗大小：世界
}

int main (int argc,char** argv)
{
	ros::init(argc, argv, "TaskDraw");
  ros::NodeHandle nh;

  DecodePara("/home/meng/catkin_lidar/src/loam_velodyne/carPara.ini",carpara);

  draw_map = carpara.draw_map;
  map_file_name = carpara.map_file_name;
  
  cout<<draw_map<<endl;
  cout<<map_file_name<<endl;

	readfile(draw_map.c_str());

  readDataAll_Local(map_file_name.c_str(),all_key_pc);

  //////////////////////////////////////////////////////////////////////////////////////////
  //ros::Subscriber sub_map_data = nh.subscribe<std_msgs::String>("/map_send",1000,map_Handler);
  //////////////////////////////////////////////////////////////////////////////////////////

  //readfile("/home/shenrk/testdata/819/path_gps_pc_GS.txt");
	cout<<"read end"<<endl;

  sub_task = nh.subscribe<std_msgs::String>("/task_net",1000,SubTaskHandler);
	sub_arrived_pose = nh.subscribe<std_msgs::String>("arrived_pose",1000,SubArrivedHandler);
  coord first;
  
  first.x  =  0;
  first.y  =  0;
  // v_new.push_back(first);
  // v_target.push_back(first);
  // v_location.push_back(first);
  // v_GPS.push_back(first);
 
  glutInit(&argc, argv);
  glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE);
  glutInitWindowPosition(100, 100);
  glutInitWindowSize(700, 700);
  glutCreateWindow("TaskDraw");
  glutIdleFunc(&update);
  glutDisplayFunc(&view);
  Initial();

  glutTimerFunc(1, timerCb, 0);
  glutMainLoop();

	return 0;
}
