#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <pcl/registration/icp.h>
#include <pcl/point_cloud.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/kdtree/kdtree_flann.h>
#include <pcl/visualization/cloud_viewer.h>
#include <cstring>
#include <sensor_msgs/PointCloud2.h>
#include <Eigen/Dense>  
#include <boost/format.hpp>
#include <ros/ros.h>
#include <math.h>
#include <iostream>
#include <loam_velodyne/common.h>
#include <nav_msgs/Odometry.h>
#include <pcl_conversions/pcl_conversions.h>
#include <sensor_msgs/Imu.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_broadcaster.h>
#include <iomanip>
#include <fstream>
#include <loam_velodyne/LocalGeographicCS.hpp>
#include <loam_velodyne/Detect.h>
#include <loam_velodyne/getAngle.h>
#include <sensor_msgs/Imu.h>
#include <sensor_msgs/NavSatFix.h>
#include <geometry_msgs/PoseStamped.h>
#include <loam_velodyne/serial.h>
#include <loam_velodyne/Simulation.hpp>
#include <loam_velodyne/control_car.h>
#include <loam_velodyne/ModifyTargetPoint.hpp>
#include <loam_velodyne/SmTarPoi.hpp>                                                     
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <string> 
#include <pthread.h>
#include "std_msgs/String.h"
#include "std_msgs/Int64.h"
#include "std_msgs/Int8.h"
#include <pthread.h>
#include <boost/lexical_cast.hpp>
#include <boost/thread/thread.hpp>
#include <ctime>
#include <time.h>
#include <unistd.h>
#include <exception> 
#include <loam_velodyne/TurnWhichDirection.h>
#include <loam_velodyne/LORDeterminer.hpp>

#include <loam_velodyne/GLogHelper.h>
#include <loam_velodyne/SpeedSmooth.h>
#include <loam_velodyne/AngleBetweenLocationAndPath.h>
#include <glog/logging.h>
#include <loam_velodyne/AliceController.h>
#include <loam_velodyne/PointsAugment.h>
#include <loam_velodyne/ReverseController.h>

using namespace Eigen; 
using namespace std;

#define IS_AUTO 1

std::ofstream ctrl_log("/home/chen/Project/catkin_sysu/src/loam_velodyne/output/ctrl_log.txt");
std::ofstream save_turn_info("/home/chen/Project/catkin_sysu/src/loam_velodyne/output/turn_info.txt");
std::ofstream save_task_info("/home/chen/Project/catkin_sysu/src/loam_velodyne/output/turn_task_info.txt");

std::ofstream angle_log("/home/chen/Project/catkin_sysu/src/loam_velodyne/output/angle_log.txt");

std::ofstream task_log("/home/chen/Project/catkin_sysu/src/loam_velodyne/output/task_log.txt");

std::ofstream turnctrl_log("/home/chen/Project/catkin_sysu/src/loam_velodyne/output/turnctrl_log.txt");

std::ofstream initctrl_log("/home/chen/Project/catkin_sysu/src/loam_velodyne/output/initctrl_log.txt");

std::ofstream new_path("/home/chen/Project/catkin_sysu/src/loam_velodyne/output/new_path.txt");

std::ofstream obstacle_info("/chen/Project/catkin_sysu/src/loam_velodyne/output/obstacle_info.txt");

std::ofstream initlocation_log("/home/chen/Project/catkin_sysu/src/loam_velodyne/output/initlocation_log.txt");

std::ofstream speed_log("/home/chen/Project/catkin_sysu/src/loam_velodyne/output/speed_log.txt");


CarPara carpara;//小车参数变量
Detect detect; //avoid obstacle
string ALL_MAP("");//动态路径
double to_target_point_dis = 1.5;//距离预瞄点的距离
double to_turn_point_dis = 0.2;//距离拐点的距离
bool is_init_end = false;
float speed = 0.40; //小车直走速度
const float turning_speed = 0.15; // 小车转弯速度

bool flag_direction = false;  //判断小车转弯方向是否已经确定
bool is_turn_over = true;
bool first_heading_flag = true;
double first_heading = 0.0;

int INIT_LOCATION_count = 0;
bool is_init_location_turn = false;

//other ros topic
ros::Publisher down_send;
ros::Publisher mode_send;
ros::Publisher car_info_send;
ros::Publisher current_send;//current index send to location
ros::Publisher turn_end_pub;
ros::Publisher pub_v_a_mode;//send angle to sbg
ros::Publisher pub_car_arrive;
ros::Publisher pub_obstacle_replan;
ros::Publisher ctrl_info;
ros::Publisher send_arrived_pose;
ros::Publisher init_location_pub;

ros::Subscriber subfinal;
ros::Subscriber sub_delay;
ros::Subscriber sub_map_data;
ros::Subscriber task_sub;
ros::Subscriber stop_sub;
ros::Subscriber sub_move;
ros::Subscriber sub_init_end;
ros::Subscriber obstacle_rev;//edit by equal obstacle
ros::Subscriber charge_recv;
ros::Subscriber carto_sub;
ros::Subscriber sub_work_queue_size;

string obstacle_string;
vector<Point> obstacle_point;
int is_obstacle_sent = 1;
bool new_map_have_recieved = false;

int work_queue_size_;

///////////////////////
double end_pos_x = 0;
double end_pos_y = 0;
double end_dis = 0;
///////////////////////
int start_turn = 0;
int end_turn = 0;

bool new_path_race = false;
bool CONTROLLER_ORDER_REV = false;

bool taskpoint_stop = false;
bool taskpoint_task = false;

bool is_arrived = false;
int  is_arrived_sent = 1;
bool init_first = true;    //zqq 0117

int is_finish_location = 1;

bool into_charge = false;
double speed1 = -0.2;

///////task point
double task_x,task_y,task_heading,task_speed;
double task_dis = 1000;
int task_index = 10000;

InfoToSS itss;

///////
int delay_end = 0;//sbg will send the msg to ctrl while the vo was ready
static int is_stop = 0;//后台发送stop指令
bool obstacle_stop = false;//超声波检测到障碍物并停止

//////////////自动充电///////////
static int is_charge = 0;
double charge_x = 7.0892252922100001;
double charge_y = 0;
bool charge_vo_send = true;
bool charge_turn_end = true;
bool charge_vo_sent = true;
///////////////////////////////

GPSPoint real_time_location;
GPSPoint task_point;//shenrk 1 29
double delta_task_angle = 10;
int is_in_xy = 0;

vector<GPSPoint> all_map;//all map data
int MODE = 0; //zqq 0108

double record_time = 0;  //avoid obstacle
bool detect_flag = false;
bool have_new_path = false;

double init_time = 0;

car cc;//车辆控制指令实例
double o1,o2,o3,o4,a1,a2,a3,a4;
double sm1,sm2,sm3,sm4;
int car_mode;

float a_mode = 0;
float a_speed = 0;
float a_angle = 0;

pthread_t id;//read info from the car and open a thread to send to other node
int i,ret;
////////////////////////////////////////////////////////////////////////////////////////
// ofstream T("/home/usi/sysuzyc/catkin_yf_lidar/src/loam_velodyne/output/target.txt");
////////////////////////////////////////////////////////////////////////////////////////
/*******************************原地转弯************************************************/
int first_turn = 1;
int calculat_turn = 1;
int target_index = 0;
int turn_index = 0;
int current_index = 0;
double turn_dis = 0;     //与最近拐点的最近距离
double last_turn_dis = 0;//上一次与拐点的最近距离
int is_can_turn = 0;
bool re_icp_location = 0; 
double delta_turn_angle = 0;

/**************************************************************************************/

void send_mode_vo(double x,double y,double heading,int mode){
  string tmp,r;

  tmp.clear();r.clear();
  tmp = boost::lexical_cast<string>(x);
  r = tmp;

  tmp.clear();
  tmp = boost::lexical_cast<string>(y);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(heading);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(mode);
  r.append(" ").append(tmp);

  std_msgs::String msg;
  msg.data = r;
  mode_send.publish(msg);
}


void FinalHandler(const std_msgs::String::ConstPtr &msg)
{
  double real_time_x = 0,real_time_y = 0,real_time_heading = 0;
  string moves = msg->data;
  stringstream stringin(moves);
  stringin>>setprecision(12)>>real_time_x>>real_time_y>>real_time_heading;
  real_time_heading = real_time_heading * 180.0 / 3.14159265;

  real_time_location.x = real_time_x;              //zqq delete 0115
  real_time_location.y = real_time_y;             
  real_time_location.GaussX = real_time_x;
  real_time_location.GaussY = real_time_y;
  real_time_location.heading = real_time_heading;

  //cout << real_time_location.x << " " << real_time_location.y << " " << real_time_location.heading << endl;
}

void WorkQueueHandler(const std_msgs::String::ConstPtr &msg){
  string wq_size = msg->data;

  work_queue_size_ = boost::lexical_cast<int>(wq_size);
  //cout<<"work queue size..."<<work_queue_size_<<endl;
}

void CartographerHandler(const std_msgs::String::ConstPtr &msg)   //zqq add 0115
{
  
  // double real_time_x = 0,real_time_y = 0,real_time_heading = 0;
  // double tmp_x,tmp_y,tmp_heading;
  // string moves = msg->data;
  // stringstream stringin(moves);
  // stringin>>setprecision(12)>>real_time_x>>real_time_y>>real_time_heading;

  // //real_time_heading = real_time_heading * 180.0 / 3.14159265;

  // /*******zyc 1216*********/
  // //cartographer (x,y,heading) in loam
  // // tmp_x = real_time_x - 12.80; 
  // // tmp_y = real_time_y -1.1;
  // // tmp_heading = 10 * 3.14149265 / 180.0;

  // // real_time_location.x = tmp_y * cos(tmp_heading) - tmp_x * sin(tmp_heading);
  // // real_time_location.y = tmp_y * sin(tmp_heading) + tmp_x * cos(tmp_heading);
  // /*******zyc 1216********/

  // /***********mtx 1226***************/
  // tmp_x = real_time_x; 
  // tmp_y = real_time_y;
  // tmp_heading =  0;
  // real_time_location.x = tmp_y * cos(tmp_heading) - tmp_x * sin(tmp_heading);
  // real_time_location.y = tmp_y * sin(tmp_heading) + tmp_x * cos(tmp_heading);
  // /**************************/

  // // real_time_location.x = real_time_y;
  // // real_time_location.y = real_time_x;
  // // real_time_location.GaussX = real_time_location.x;
  // // real_time_location.GaussY = real_time_location.y;

  // real_time_location.heading = real_time_heading;//+10;
  
}

void delay_Handler(const std_msgs::Int64::ConstPtr &msg){
  delay_end = msg->data;
  cout<<"delay_end: "<<delay_end<<endl;
}


void Init_End_Handler(const std_msgs::Int8::ConstPtr &msg){
	is_init_end = msg->data;
	cout<<"location have init finish!"<<endl;
}


void task_Handler(const std_msgs::String::ConstPtr &msg){

  task_x = 0;
  task_y = 0;
  task_speed = 0.2;

  string moves = msg->data;
  stringstream stringin(moves);
  stringin>>setprecision(12)>>task_x>>task_y>>task_speed;

  cout<<"任务点： "<<task_x<<" "<<task_y<<" "<<task_speed<<endl;
  cout<<"解除stop命令！"<<endl;

  itss.TargetSpeed = task_speed;

  //taskpoint_task = true;      //zqq 0108
}


void stop_Handler(const std_msgs::Int8::ConstPtr &msg){
  is_stop = msg->data;

  cout<<"!!!!!!!!!!!!!!!!!!!!!"<<" "<<is_stop<<endl;
}

void Charge_Handler(const std_msgs::Int8::ConstPtr &msg){
  is_charge = msg->data;
  cout<<"Charge!!!!"<<endl;
}


void map_Handler(const std_msgs::String::ConstPtr &msg){

  ALL_MAP.clear();
  all_map.clear();

  start_turn = 0;
  end_turn = 0;

  is_stop = 0;

  task_index = 10000;
  task_dis = 0;

  turn_dis = 0;
  turn_index = 0;
  last_turn_dis = 0;

  is_arrived = false;
  is_arrived_sent = 1;

  new_map_have_recieved = true;
  taskpoint_task = true;   //zqq 0110
  taskpoint_stop = true;      //zqq  0110
  have_new_path = true;
  //is_obstacle_sent = 1;

  // task_x = 0;
  // task_y = 0;

  ALL_MAP = msg->data;
  cout<<"path have receive! ctrl"<<endl;

  //send_mode_vo(real_time_location.x,real_time_location.y,real_time_location.heading,0);

  decodePath(ALL_MAP,all_map);//解析规划路径

  if(into_charge == true)
  {
  	for(int i=0; i<all_map.size(); i++)
  	{
  		all_map[i].heading = 0;
  	}
  }
  

  if(!all_map.empty()){

    cout<<"map size: "<<all_map.size()<<endl;

    cout<<"init angle: "<<all_map[0].heading<<endl;

    for(int i=0;i<all_map.size();i++)     //dyq  0112
    {
      all_map[i].is_turn = 0;
       all_map[i].heading = all_map[i].heading * 57.29; 
    }
    for(int i=1;i<all_map.size();i++)
    {
      if(fabs(all_map[i].heading - all_map[i-1].heading) > 70 && fabs(all_map[i].heading - all_map[i-1].heading) < 290)
      {
        all_map[i].is_turn = 1;
      }
    }

    all_map[0].is_turn = 1;
    all_map[all_map.size()-1].is_turn = 1;

    smoothMap_tzb(all_map);   //zqq  0124


    for(const GPSPoint& p: all_map)
    {
      char buf[64];
      sprintf(buf,"%f %f %f",p.x,p.y,p.heading);
      new_path << buf << endl;
    }
    new_path << endl<<endl;

    

    ////////////edit by equal//////////////
    cout<<"path first x: "<<all_map[0].x<<" y: "<<all_map[0].y<<endl;
    cout<<"now heading: "<<real_time_location.heading<<" map heading :"<<all_map[0].heading<<endl;

  //  if(fabs(real_time_heading - all_map[0].heading) > 70)
  //  {
  //      cout<<"first point have set turn point"<<endl;
  //      all_map[0].is_turn = 1;
  //  }

    //////////////////////////////////////

    end_pos_x = all_map[all_map.size()-1].x;
    end_pos_y = all_map[all_map.size()-1].y;

    new_path_race = true;
  }
}
///shenrk
int Is_in_xy(GPSPoint pose){
    //1 in_x
    //2 in_y
    if(fabs(fabs(pose.heading) - 90) < delta_task_angle){
        return 1;
    }else if(fabs(180 - fabs(pose.heading)) < delta_task_angle || fabs(pose.heading) < delta_task_angle ){
        return 2;
    }else{
        return 0;
    }
}
int Task_arrived(GPSPoint now,GPSPoint task,int in_xy){
    if(in_xy == 1)//在x轴上
    {
        if(fabs(now.heading - 90) < delta_task_angle){//朝着x正方向
            if(now.x >= task.x){
                return 1;
            }else{
                return 0;
            }
        }else if(fabs(now.heading + 90) < delta_task_angle){//朝着x负方向
            if(now.x <= task.x){
                return 1;
            }else{
                return 0;
            }
        }
    }else if(in_xy == 2){
        if(fabs(now.heading) < delta_task_angle){
            if(now.y >= task.y){
                return 1;
            }else{
                return 0;
            }
        }else if(fabs(now.heading - 180) < delta_task_angle || fabs(now.heading + 180) < delta_task_angle){
            if(now.y <= task.y){
                return 1;
            }else{
                return 0;
            }
        }
    }else{
        return 0;
    }
}
///shenrk
void move_Handler(const std_msgs::String::ConstPtr &msg){

  string moves = msg->data;
  stringstream stringin(moves);
  stringin>>setprecision(12)>>a_mode>>a_angle>>a_speed;
  CONTROLLER_ORDER_REV = true;
}


void obstacle_Handler(const std_msgs::String::ConstPtr &msg){
  obstacle_string = "";
  obstacle_string = msg->data;

  stringstream ss(obstacle_string);
  obstacle_info << obstacle_string << endl;
  string tmp_s;

  obstacle_point.clear();

  while(getline(ss,tmp_s,';')){
    Point newpoint;
    stringstream final_s(tmp_s);

    final_s>>setprecision(12)>>newpoint.x>>newpoint.y;
    obstacle_point.push_back(newpoint);
  }
}


void ctrl_init(ros::NodeHandle nh){
    down_send = nh.advertise<std_msgs::String>("/odo_send",1000);

    car_info_send = nh.advertise<std_msgs::String>("/car_info",100);

    mode_send = nh.advertise<std_msgs::String>("chmod",5);

    subfinal = nh.subscribe<std_msgs::String>("/final_data",1000,FinalHandler);

    current_send = nh.advertise<std_msgs::Int64>("index_send",5);

    sub_delay = nh.subscribe<std_msgs::Int64>("vo_time",50,delay_Handler);

    task_sub = nh.subscribe<std_msgs::String>("/task_net",1000,task_Handler);//get new task point
    
    stop_sub = nh.subscribe<std_msgs::Int8>("stop_net",100,stop_Handler);

    sub_move = nh.subscribe<std_msgs::String>("/move_net",1000,move_Handler);//后台发送遥控指令

    sub_map_data = nh.subscribe<std_msgs::String>("/map_send",1000,map_Handler);

    obstacle_rev = nh.subscribe<std_msgs::String>("/obstacle_out",1000,obstacle_Handler);

    charge_recv = nh.subscribe<std_msgs::Int8>("charge",5,Charge_Handler);

    sub_init_end = nh.subscribe<std_msgs::Int8>("init_finish",5,Init_End_Handler);

    pub_v_a_mode = nh.advertise<std_msgs::String>("car_move_info",5);

    turn_end_pub = nh.advertise<std_msgs::Int8>("turn_finish",5);

    pub_car_arrive = nh.advertise<std_msgs::Int8>("car_arrive",5);

    pub_obstacle_replan = nh.advertise<std_msgs::Int8>("obstacle_plan",5);

    carto_sub = nh.subscribe<std_msgs::String>("trajectory_node_string",10,CartographerHandler);
    ctrl_info = nh.advertise<std_msgs::String>("/Ctrlinfo",1000);

    send_arrived_pose = nh.advertise<std_msgs::String>("arrived_pose",1000);

    sub_work_queue_size = nh.subscribe<std_msgs::String>("work_queue_size", 10,WorkQueueHandler);

    init_location_pub = nh.advertise<std_msgs::Int8>("lab_init_location",10);
}

void send_task_info(int flag, double x, double y, double heading)   //zqq 0125
{
	char buf[128];
  heading = heading*3.141592/180;
  sprintf(buf,"%d %f %f %f",flag,x,y,heading);
  std_msgs::String msg;
	msg.data = buf;
  ctrl_info.publish(msg);
}

void send_info_to(){
  string tmp,r;

  tmp.clear();r.clear();
  tmp = boost::lexical_cast<string>(o1);
  r = tmp;

  tmp.clear();
  tmp = boost::lexical_cast<string>(o2);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(o3);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(o4);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(a1);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(a2);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(a3);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(a4);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(car_mode);
  r.append(" ").append(tmp);

  std_msgs::String msg;
  msg.data = r;
  down_send.publish(msg);
}


void send_CarInfo_to(){
  stringstream ss;
  string tmp,r;
  //////////
  tmp.clear();r.clear();
  tmp = boost::lexical_cast<string>(cmode);
  r = tmp;

  tmp.clear();
  tmp = boost::lexical_cast<string>(cangle);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cspeed);
  r.append(" ").append(tmp);
  //////////
  tmp.clear();
  tmp = boost::lexical_cast<string>(cangle1);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cangle2);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cangle3);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cangle4);
  r.append(" ").append(tmp);
  //////////
  tmp.clear();
  tmp = boost::lexical_cast<string>(ccur_m1);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(ccur_m2);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(ccur_m3);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(ccur_m4);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cspeed_m1);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cspeed_m2);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cspeed_m3);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cspeed_m4);
  r.append(" ").append(tmp);
  //////////
  tmp.clear();
  tmp = boost::lexical_cast<string>(cpul_m1);
  r.append(" ").append(tmp);
  
  tmp.clear();
  tmp = boost::lexical_cast<string>(cpul_m2);
  r.append(" ").append(tmp);
  
  tmp.clear();
  tmp = boost::lexical_cast<string>(cpul_m3);
  r.append(" ").append(tmp);
  
  tmp.clear();
  tmp = boost::lexical_cast<string>(cpul_m4);
  r.append(" ").append(tmp);
  //////////
  tmp.clear();
  tmp = boost::lexical_cast<string>(cus1);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cus2);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cus3);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cus4);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cus5);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cus6);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cus7);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cus8);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cobstacle);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cdis_keep);
  r.append(" ").append(tmp);
  //////////
  for(int i=0;i<12;i++)
  {
    tmp.clear();
    tmp = boost::lexical_cast<string>(ccell[i]);
    r.append(" ").append(tmp);
  }
  //////////
  tmp.clear();
  tmp = boost::lexical_cast<string>(cmaxV);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cminV);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cmaxVP);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cminVP);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cVD);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cAV);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cTV);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cCC);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cDC);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cSOC);
  r.append(" ").append(tmp);
  //////////
  tmp.clear();
  tmp = boost::lexical_cast<string>(cTem1);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cTem2);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cTem3);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cTem4);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cTem5);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cTem6);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cmaxTem);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cminTem);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cavrTem);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cenvirTem);
  r.append(" ").append(tmp);
  ///////////
  tmp.clear();
  tmp = boost::lexical_cast<string>(cRc);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(cWr);
  r.append(" ").append(tmp);
  //////////
  
  std_msgs::String msg;
  msg.data = r;
  //cout<<r<<endl;
  car_info_send.publish(msg);
}


void* getData(void* args)//get data from car and send 
{
    while(true){
      cc.DataReceive();
      o1 = cc.pul1_data;//四个里程计数据
      o2 = cc.pul2_data;
      o3 = cc.pul3_data;
      o4 = cc.pul4_data;

      a1 = cc.sv1_ac_data;
      a2 = cc.sv2_ac_data;
      a3 = cc.sv3_ac_data;
      a4 = cc.sv4_ac_data;

      sm1 = cc.m1_data;
      sm2 = cc.m2_data;
      sm3 = cc.m3_data;
      sm4 = cc.m4_data;

      car_mode = cc.mode_data;

      cmode = cc.mode_data;
      cangle = cc.angle_data;
      cspeed = cc.speed_data;

      cangle1 = cc.sv1_ang_data;
      cangle2 = cc.sv2_ang_data;
      cangle3 = cc.sv3_ang_data;
      cangle4 = cc.sv4_ang_data;

      ccur_m1 = cc.cur1_data;
      ccur_m2 = cc.cur2_data;
      ccur_m3 = cc.cur3_data;
      ccur_m4 = cc.cur4_data;
      cspeed_m1 = cc.m1_data;
      cspeed_m2 = cc.m2_data;
      cspeed_m3 = cc.m3_data;
      cspeed_m4 = cc.m4_data;

      cpul_m1 = cc.dis1_data;
      cpul_m2 = cc.dis2_data;
      cpul_m3 = cc.dis3_data;
      cpul_m4 = cc.dis4_data;

      cus1 = cc.us1_data;
      cus2 = cc.us2_data;
      cus3 = cc.us3_data;
      cus4 = cc.us4_data;
      cus5 = cc.us5_data;
      cus6 = cc.us6_data;
      cus7 = cc.us7_data;
      cus8 = cc.us8_data;
      cobstacle = cc.obstacle_data;
      cdis_keep = cc.dis_keep_data;

      ccell[0] = cc.cell1_data;
      ccell[1] = cc.cell2_data;
      ccell[2] = cc.cell3_data;
      ccell[3] = cc.cell4_data;
      ccell[4] = cc.cell5_data;
      ccell[5] = cc.cell6_data;
      ccell[6] = cc.cell7_data;
      ccell[7] = cc.cell8_data;
      ccell[8] = cc.cell9_data;
      ccell[9] = cc.cell10_data;
      ccell[10] = cc.cell11_data;
      ccell[11] = cc.cell12_data;

      cmaxV = cc.max_voltage_data;
      cminV = cc.min_voltage_data;
      cmaxVP = cc.max_voltage_pos_data;
      cminVP = cc.min_voltage_pos_data;
      cVD = cc.voltage_diff_data;
      cAV = cc.avg_voltage_data;
      cTV = cc.total_voltage_data;
      cCC = cc.charge_cur_data;
      cDC = cc.discharge_cur_data;
      cSOC = cc.soc_data;

      cTem1 = cc.temperature1_data;
      cTem2 = cc.temperature2_data;
      cTem3 = cc.temperature3_data;
      cTem4 = cc.temperature4_data;
      cTem5 = cc.temperature5_data;
      cTem6 = cc.temperature6_data;
      cmaxTem = cc.max_temp_data;
      cminTem = cc.min_temp_data;
      cavrTem = cc.avg_temp_data;
      cenvirTem = cc.envirmnt_temp_data;

      cRc = cc.Rc_data;
      cWr = cc.Wr_data;
      //cout<<"odo:"<<o1<<" "<<o2<<" "<<o3<<" "<<o4<<endl<<endl;
      send_info_to();
      send_CarInfo_to();
    }
}


inline void pub_v_a_modeHandler(int mode,double angle,float speed)
{
  string tmp,r;
  tmp.clear();r.clear();
  tmp = boost::lexical_cast<string>(mode);
  r = tmp;

  tmp.clear();
  tmp = boost::lexical_cast<string>(angle);
  r.append(" ").append(tmp);

  tmp.clear();
  tmp = boost::lexical_cast<string>(speed);
  r.append(" ").append(tmp);

  std_msgs::String msg;
  msg.data = r;
  pub_v_a_mode.publish(msg);
}


#define CONTROLLER_MODE 0   /*遥控模式*/
#define STOP            1   /*停止模式*/
#define INITIAL_NAV     2   /*初始化模式*/
#define FORWARD_MODE    3   /*直走模式*/
#define TASK_EXECUTION  4   /*到达任务点模式*/
#define TURNING_        5   /*到达拐点模式*/
#define AVOIDOBSTACLE   6   /*避障*/
#define CHARGE          7   /*自动充电模式*/
#define INIT_LOCATION   8   /*小车初始定位*/

ofstream log_("/home/chen/Project/catkin_sysu/src/loam_velodyne/log.txt");
ofstream plan_("/home/chen/Project/catkin_sysu/src/loam_velodyne/output/plan_log.txt");

int main(int argc, char** argv)
{
  ros::init(argc, argv, "laserCtrl");
  ros::NodeHandle nh;
  GLogHelper gh(argv[0]);

  DecodePara("/home/chen/Project/catkin_sysu/src/loam_velodyne/carPara.ini",carpara);
  ctrl_init(nh);
  ret = pthread_create(&id,NULL,getData,NULL);  //新开一个线程获取底层数据，发送消息给后台

  /*************cls ********************/
  Point tempt = {100,100};
  Point PointOfTarget;
  Detect Detection;
  int IsCrashed = 0;
  GPSPoint Mic_target;
  Simulation Mic;
  double CanCalculate = 1;
  obstacle_point.push_back(tempt);
  int last_target_index = 0;
  // InfoToSS itss;
  // itss.TargetSpeed = task_speed;
  /***************end*******************/

  double angle = 0;
  int MODE = 0, direction_ = 0;//the dirction of turn

  double delta_dis = 0;          //zqq 0131
  double last_x = 0;
  double last_y = 0;

  log_<<"MODE,x,y,heading\n";

  ros::Rate rate(50);//shenrk 15
  bool status = ros::ok();
  int count_pass_turn_point=0;// used to count how many passed turn  points.
  int count_pass_task_point=0;// used to count how many passed task points. 
  int task_flag = 0;
  while(status)
  {
    ros::spinOnce();

    MODE = is_charge?CHARGE:MODE;
    MODE = CONTROLLER_ORDER_REV?CONTROLLER_MODE:MODE; /*遥控模式/自动模式*/
    MODE = is_stop? STOP:MODE; /*是否停下的检测*/  // comment temperally by DYQ
    if(MODE!=CONTROLLER_MODE)
    {
      if(first_heading_flag)
      {
        first_heading_flag = false;
        first_heading = real_time_location.heading;
      }
    }
    log_<< ros::Time::now()<<","<<MODE<<","<<real_time_location.x<<","<<real_time_location.y<<","<<real_time_location.heading<<",";
    //LOG(ERROR)<<MODE<<","<<real_time_location.x<<","<<real_time_location.y<<","<<real_time_location.heading<<endl;
    //cout<< ros::Time::now() << " MODE: "<<MODE<<endl;

    switch(MODE)
    {
      LOG(INFO)<<ros::Time::now()<<" current MODE is: "<<MODE;
      cout<< ros::Time::now() << " MODE: "<<MODE<<endl;

      case CONTROLLER_MODE:    //can't find the condition, ask for hegong , zqq 0108
      {
        CONTROLLER_ORDER_REV = false; 
        cc.GetInfo(a_mode,a_angle,a_speed);
        a_mode = a_angle = a_speed = 0.0;
        MODE = INITIAL_NAV;
        break;
      }

      case STOP:   //到stop后不用转移状态，等到调用了发布新任务点的回调函数，MODE会转为初始化。 zqq 0106
      {
        #ifdef IS_AUTO
        cc.GetInfo(0,0,0);
        speed_log<<setprecision(12)<<ros::Time::now()<<" "<<0<<endl;
        cout<<"stop stop 0 0 0"<<endl;
        #endif

        into_charge = false;   // jump out of charge ,zqq 0115
        if(taskpoint_stop == true)   //jump out condition ,zqq 0108     have problem 0110
        {
          cout<<"MODE from STOP to INITIAL_NAV"<<endl;
          MODE = INITIAL_NAV; // 跳转导航模块
          taskpoint_stop = false;
        }
        else
        {
            //cout<<"MODE from STOP to STOP,haven't received the new task point"<<endl;
            MODE = STOP;
        }
        break;
      }

      case INITIAL_NAV:
      {
        if(!all_map.empty())  //是否收到了导航信息,15 is ? zyc
        {
          	if(!obstacle_stop)// whether receive the stop command 
          	{
              LOG(INFO)<<ros::Time::now()<<" no obstacle stop command";
              LOG(INFO)<<ros::Time::now()<<" delay_end: "<<delay_end;
              //add queue size by shenrk,2018.2.27
              if(taskpoint_task && work_queue_size_ <= 20)  //zqq 0110 receive new path  && work_queue_size_ <= 50
              {
 
                if(init_first)
                {
                  cout<<"MODE from FORWARD_MODE to INIT_LOCATION!"<<endl;
                  init_first = false;
                  init_time = ros::Time::now().toSec();
                  MODE = INIT_LOCATION;

                  break;
                }

		        cout<<"finish the initial location, prepare to go now"<<endl;
                cout<<"MODE from INITIAL_NAV to FORWARD_MODE"<<endl;
                have_new_path = false;  //zqq 0207
                /*
                end_turn：  计算当前路径(直线)上最近的“拐点”或“任务点”的下标
                task_index：计算当前地图路径上“任务点”的下标
                turn_index：计算当前地图路径上最近的“拐点”的下标
                */
                for(int i = start_turn; i < all_map.size(); i++)
                {
                  if(all_map[i].is_turn == 1 && all_map[i].is_finish_turn == 0)
                  {
                    end_turn = i;
                    // if(end_turn == all_map.size()-1)    //在最后一段路径计算任务点索引 zqq 0105
                    // {
                    //   task_index = Current_index_Return(task_x,task_y,all_map,
                    //                                   start_turn,end_turn);
                    // }
                    task_index = all_map.size()-1;  //zqq 0110

                    task_point.x = all_map[task_index].x;
                    task_point.y = all_map[task_index].y;
                    
                    MODE = FORWARD_MODE;  //跳转到直走模式
                    
                    break;
                  }
                }
              }
              else
              {
                cout<<"haven't receive new path !!"<<endl;
              }        				
          	}
          	else
          	{
          		cout<<"receive the obstacle stop command"<<endl;
          		//MODE=STOP;
              cc.GetInfo(0,0,0);
              speed_log<<setprecision(12)<<ros::Time::now()<<" "<<0<<endl;
          	}
        }
        break;
      }

      case FORWARD_MODE:
      {
        /**************************************************************************************/
        //current_index：计算当前路径(直线)上的 “当前帧”
        current_index = Current_index_Return(real_time_location.x,
                                             real_time_location.y,
                                             all_map,start_turn,
                                             end_turn);
        /* 发送当前帧 */
        std_msgs::Int64 msg;
        msg.data = current_index;
        current_send.publish(msg);
        /**************************************************************************************/
        is_in_xy = Is_in_xy(real_time_location);

        /**************************************************************************************/
        //turn_index：计算最近拐点的下标
        //turn_dis：计算当前位置与最近拐点的距离
        if(end_turn != all_map.size()-1)    //zqq  0108 don't let task point into this condi
        {
          for(int i = current_index; i < all_map.size(); i++)
          {
            if(all_map[i].is_turn == 1 && all_map[i].is_finish_turn == 0)
            {
              turn_index = i; //最近拐点的index
              if(fabs(real_time_location.heading-180) < 40 || fabs(real_time_location.heading) < 40)
              {
                turn_dis = fabs(all_map[turn_index].y - real_time_location.y);
              }
              else if(fabs(real_time_location.heading - 90) < 40 || fabs(real_time_location.heading + 90) < 40){
                turn_dis = fabs(all_map[turn_index].x - real_time_location.x);
              }
              else{
                turn_dis = length_two_points(real_time_location.x,real_time_location.y,all_map[i].x,all_map[i].y);
              }
              break;
            }
          }

          //判断是否到达最近的拐点
          if(IsBeyondTheEndPoint(all_map, real_time_location, turn_index) || turn_dis < 0.15)    //zqq 0110
          {
            count_pass_turn_point++;
            save_turn_info<< real_time_location.x<<' '<<real_time_location.y<<' '
                          << all_map[turn_index].x<<' '<<all_map[turn_index].y<<" "<<turn_index<<
                          ' '<<all_map[start_turn].x<<' '<<all_map[start_turn].y<<' '
                          <<count_pass_turn_point<<endl;
            LOG(ERROR) << "turn_index:" << " " << turn_index << endl; 
            /*
            与拐点的距离小于阈值时开始原地转弯
            current_index < task_index 确保在任务结束时不会转弯
            通知里程计已经切换小车模式并停止航位推算
            切换MODE到转弯模式
            */
            send_mode_vo(real_time_location.x,
                          real_time_location.y,
                          real_time_location.heading,1);
            cout<<"MODE from FORWARD_MODE to TURNING_ we arrive at turn point"<<endl;
            
            MODE = TURNING_;

            continue;
          }
        }
        /**************************************************************************************/

        /**************************************************************************************/
        else{                               //保证在最后一段路才判断任务点条件  zqq  0111
          //task_dis：计算当前位置与任务点的距离
          task_dis = length_two_points(real_time_location.x,
                                       real_time_location.y,
                                       task_x,task_y);
          
          log_<<current_index<<","<<task_dis<<",";
          
          //判断是否到达任务点
          //IsBeyondTheEndPoint(all_map, real_time_location, task_index) ||
          if(into_charge == false){
            if(Task_arrived(real_time_location,task_point,is_in_xy)==1)
            {
              LOG(ERROR)<<IsBeyondTheEndPoint(all_map, real_time_location, task_index)<<"  "<<task_dis;
               cout<<"MODE from FORWARD_MODE to TASK_EXECUTION and we arrived at task point"<<endl;

               MODE = TASK_EXECUTION;

               continue;
            }
          }else{
            if(IsBeyondTheEndPoint(all_map, real_time_location, task_index) || task_dis < 0.15){
                LOG(ERROR)<<IsBeyondTheEndPoint(all_map, real_time_location, task_index)<<"  "<<task_dis;
                cout<<"MODE from FORWARD_MODE to TASK_EXECUTION and we arrived at task point"<<endl;

                MODE = TASK_EXECUTION;

                continue;
            }
          }
        }
        /**************************************************************************************/

        

        plan_ << ros::Time::now() << " " << MODE << " " << is_obstacle_sent << " " << new_map_have_recieved << " " << turn_dis << " " << to_turn_point_dis << " " << real_time_location.x << " " << real_time_location.y << " " << real_time_location.heading << " " << all_map[turn_index].x << " " << all_map[turn_index].y << " " << all_map[turn_index].heading << " " << all_map[current_index].x << " " << all_map[current_index].y << " " << all_map[current_index].heading << " " << turn_index << " " << current_index << endl;
        
        /**************************************************************************************/
        //如果没有到达任务点或者拐点，那么小车继续直走
        // 动态预锚点计算
        SmTarPoi stp;
        stp.GetAllMap(all_map);  //获取当前的地图轨迹
        //根据当前位置计算在地图轨迹上的预瞄点的下标
        target_index = stp.GetDataAndReturn(real_time_location,current_index,end_turn,speed);
        angle_log << ros::Time::now() << " " << current_index << " " << end_turn << " ";

        //如果预瞄点的下标比拐点下标大，那么就直接把拐点下标赋值给它
        if(target_index >= end_turn)
        {
          target_index = end_turn;
        }
        
        double Lx,Ly;
        GPSPoint target;
        target.x = all_map[target_index].x;
        target.y = all_map[target_index].y;
        target.GaussX = all_map[target_index].x;
        target.GaussY = all_map[target_index].y;
        angle_log << target.x << " " << target.y << " " << target_index << " " << last_target_index << " ";
 

        ModifyTargetPoint mtp;
        target = mtp.ModifiedTargetPoint(real_time_location,end_turn,all_map,target, stp.target_length);

        WorldtoMap(real_time_location,target.GaussX,target.GaussY,Lx,Ly);
        target.LX = Lx;
        target.LY = Ly;
        /////////reverse walk
        if(into_charge == false){
          // angle = getAngle(-target.LX,target.LY);        //ensure ,zqq 0115
          AliceController ac;
          angle = ac.sendMapAndLocation(all_map,real_time_location, stp.target_length,current_index);

        }
        else{
          ReverseController RC;
          angle = RC.GiveInfoAndReturnSteer(real_time_location, target);
        }
        /////////
        target.x = all_map[target_index].x;
        target.y = all_map[target_index].y;
        WorldtoMap(real_time_location,target.x,target.y,Lx,Ly);
        PointOfTarget.x = Lx;
        PointOfTarget.y = Ly;
        target.heading = all_map[target_index].heading;

        /**************************************************/
        if(into_charge == false)
        {
          detect.GetData(PointOfTarget,obstacle_point);  //avoid obstacle ,zqq 0130
          if(detect.mode)
          {
            LOG(WARNING)<<"detect.mode :"<<detect.mode;
            if(fabs(cspeed) > 0.01)
            {
              cc.GetInfo(0,0,0);
              break;
            }
            if(fabs(cspeed) == 0.0 && detect_flag)
            {
              cc.GetInfo(0,0,0);
              record_time = ros::Time::now().toSec();
              detect_flag = false;
              break;
            }
            if(ros::Time::now().toSec() >= record_time + 10)
            {
              cout<<"MODE from FORWARD_MODE to AVOIDOBSTACLE "<<endl;
              MODE = AVOIDOBSTACLE;
              break;
            }
            break;
          }
          else{
            //record_time = ros::Time::now().toSec();
            detect_flag = true;
          }
        }
        /**************************************************/

        double disofnow2path = 3;
        for (int i = 0; i < all_map.size(); ++i)
        {
          double temdon2p = length_two_points(all_map[i].x, all_map[i].y, real_time_location.x, real_time_location.y);
          if(temdon2p < disofnow2path)
            disofnow2path = temdon2p;
        }
        angle_log << angle << " " << disofnow2path << " " << " " << target.x << " " << target.y << " " << target.LX << " " << target.LY << " " << real_time_location.x << " " << real_time_location.y << " " << real_time_location.heading << endl;


        #ifdef IS_AUTO
        itss.SendSpeed = speed;
        itss.LeftBackTire = cspeed_m3;
        itss.RightBackTire = cspeed_m4;
        itss.Distance2Stop = length_two_points(all_map[end_turn].x, all_map[end_turn].y, real_time_location.x, real_time_location.y);
        speed = SendInfoAndMakeSpeedSmooth(itss);
      
	if(into_charge == false)
        {
          cc.GetInfo(0,angle,speed);  //speed
          speed_log<<setprecision(12)<<ros::Time::now()<<" "<<speed<<endl;
          pub_v_a_modeHandler(0,angle,speed);          
        } else
        {
          cc.GetInfo(0,angle,speed1); 
          speed_log<<setprecision(12)<<ros::Time::now()<<" "<<speed1<<endl;
          pub_v_a_modeHandler(0,angle,speed1);          
        }
        //cout<<"move order..."<<angle<<" "<<speed<<endl;
        #endif
        /**************************************************************************************/

        break;
      }

      case TASK_EXECUTION:
      {
        log_<<"Stop";

        is_arrived = true;

        if(is_arrived_sent >0)
        {
          std_msgs::Int8 msg;//
          msg.data = 1;
          pub_car_arrive.publish(msg);
          cout<<"publish the stop of car"<<endl;
          is_arrived_sent--;


          string tmp,r;
          tmp.clear();r.clear();
          tmp = boost::lexical_cast<string>(real_time_location.x);
          r = tmp;

          tmp.clear();
          tmp = boost::lexical_cast<string>(real_time_location.y);
          r.append(" ").append(tmp);

          std_msgs::String smsg;
          smsg.data = r;
          send_arrived_pose.publish(smsg);


          task_log<<setprecision(12)<<real_time_location.x<<" "<<real_time_location.y<<" map "<<all_map[task_index].x<<" "<<all_map[task_index].y<<endl;
        }

        //sleep(5);

        task_flag++;

        count_pass_task_point++;
        save_task_info<<real_time_location.x<<' '<<real_time_location.y<<' '
        <<all_map[task_index].x<<' '<<all_map[task_index].y<<" "<<task_index<<" "<<all_map[start_turn].x<<' '
        <<all_map[start_turn].y<<" "<<count_pass_task_point<<endl;
        LOG(ERROR) << "task_index:" << " " << task_index << endl;

	#ifdef IS_AUTO
        cc.GetInfo(0,0,0);
        #endif

        send_task_info(task_flag,real_time_location.x,real_time_location.y,real_time_location.heading);  //zqq 0125

	if(into_charge)        //zqq 0115
        {
          MODE = STOP;
          init_first = true;
	        INIT_LOCATION_count = 0;
          break;
        }

        if(taskpoint_task == true) //zqq 0110
        {
            cout<<"MODE from TASK_EXECUTION to INITIAL_NAV"<<endl;
            MODE = INITIAL_NAV;
            taskpoint_task = false;
        }
        else
        {
            cout<<"MODE from TASK_EXECUTION to TASK_EXECUTION,haven't received new task point"<<endl;
            MODE=TASK_EXECUTION;
        }

        break;
      }

      case TURNING_:
      {
        /**************************************************************************************/
        //flag_direction：判断最优转弯方向是否已经确定
        if(flag_direction == false)
        {
          direction_ = !DetermineTurnDirection(real_time_location.heading, all_map[turn_index].heading);
          
          cout<<"Into the TURNING_ phase: "<<"from real_time_heading "<<real_time_location.heading<<" to map_turning_heading "<<all_map[turn_index].heading<<" "<<direction_<<endl<<endl;
  
          LOG(ERROR)<<"first in turn  "<<" "<<real_time_location.heading<<" "<<all_map[turn_index].heading<<" "<<direction_;
  
          flag_direction = true;
        }
        /**************************************************************************************/


        /**************************************************************************************/
        bool turn_angle_range_po  = all_map[turn_index].heading < 8 && all_map[turn_index].heading >= 0;  //0209
        bool turn_angle_range_na  = all_map[turn_index].heading < 0 && all_map[turn_index].heading > -8;  //0209
        //判断小车转弯是否已经到位，12-07,lym
        if(direction_ > 0) //turning to left
        {
          if(all_map[turn_index].heading - 10 < -180)
          {
            all_map[turn_index].heading = all_map[turn_index].heading + 360;
          } 
          if(real_time_location.heading > all_map[turn_index].heading-10)
          {
            if(turn_angle_range_po && real_time_location.heading < 0){  //0209
              is_turn_over = true;
            }
            else if((real_time_location.heading * all_map[turn_index].heading) >= 0)
              is_turn_over = true;
            else{
              is_turn_over = false;
            }
          }
          else
          {
            is_turn_over = false;
          }
        }
        else  //direction_ < 0,turning to right
        {
          if(all_map[turn_index].heading + 10 > 180)
          {
            all_map[turn_index].heading = all_map[turn_index].heading - 360;
          } 
          if(real_time_location.heading < all_map[turn_index].heading+10)
          {
            if(turn_angle_range_na && real_time_location.heading > 0){  //0209
              is_turn_over = true;
            }
            else if((real_time_location.heading * all_map[turn_index].heading) >= 0)
              is_turn_over = true;
            else{
              is_turn_over = false;
            }
          }
          else
          {
            is_turn_over = false;
          }
        }
        
        turnctrl_log <<"turning from "<<real_time_location.heading<<" to "<<all_map[turn_index].heading << endl;
        
        if (is_turn_over == false)
        {
          /*
          负速度往右 正速度往左
          未达到目标角度前一直发送转弯命令
          转弯速度为 turning_speed 
          否则跳转到转弯结束后续处理模块
          */
          cc.GetInfo(1, 0, direction_? -turning_speed:turning_speed);
        }
        else  //转弯结束，跳转到STOP模式
        {
          // 通知里程计进行位置航推
          send_mode_vo(real_time_location.x,real_time_location.y,real_time_location.heading,0);

          cout<<"final heading: "<<real_time_location.heading<<endl;
          LOG(ERROR)<<"final heading: "<<real_time_location.heading;
          /*
          标记拐点turn_index已使用
          每一段路径由两个拐点组成，当前原地转弯结束之后将当前拐点置为新路段的起点
          */
          while(cmode !=0)
          {
            #ifdef IS_AUTO
            cc.GetInfo(0,0,0);
            speed_log<<setprecision(12)<<ros::Time::now()<<" "<<0<<endl;
            //cout<<"turn over 0 0 0"<<endl;
            #endif
          }

          all_map[turn_index].is_finish_turn = 1; 
          start_turn = end_turn; // 初始状态的时候 ？？
          flag_direction = false;
          int count_new_path=0;//计数经过多少次迭代才能获取到新数据 单云霄

          if(turn_index == all_map.size()-1)       //感觉这里可以删掉  zqq 0105
          {
            //MODE = STOP;
            #ifdef IS_AUTO
            cc.GetInfo(0,0,0);
            #endif
            cout<<"MODE from TURNING_ to INITIAL_NAV"<<endl;
            MODE=INITIAL_NAV;
            bool is_car_stop = (cc.m1_data == 0)&&(cc.m2_data == 0)&&(cc.m3_data == 0)&&(cc.m4_data == 0);
            cout<<"the car have complete the first init "<<is_car_stop<<endl;
            is_finish_location = 1;        	
          }
          else
          {
            cout<<"turn_end_pub sent!!!"<<endl;
            std_msgs::Int8 msg;
            msg.data = 1;
            turn_end_pub.publish(msg);
            //cout<<"MODE from TURNING_ to STOP,"<<endl;
            //MODE = STOP;
            #ifdef IS_AUTO
            cc.GetInfo(0,0,0);
            #endif
            cout<<"MODE from TURNING_ to INITIAL_NAV"<<endl;
            MODE=INITIAL_NAV;

            is_init_end = false;     //zqq changed, it was true before
            delay_end = 0;

            cout<<"turn finish and notify the relocation "<<current_index<<" "<<all_map.size()-10<<endl;        	
          }

          new_map_have_recieved = false;

          //cout<<"MODE from TURNING_ to STOP, we want to finish the turn."<<endl;
          //MODE = STOP;
          #ifdef IS_AUTO
          cc.GetInfo(0,0,0);
          #endif
          cout<<"MODE from TURNING_ to INITIAL_NAV, we want to finish the turn."<<endl;
          MODE=INITIAL_NAV;
        }

        break;
      }

      case AVOIDOBSTACLE:
      {
          std_msgs::Int8 msg;
          msg.data = 1;
          pub_obstacle_replan.publish(msg);        // ZQQ 0129

          detect_flag = true; //zqq 0201
          taskpoint_task = false;
          MODE = INITIAL_NAV;
          send_mode_vo(real_time_location.x,
                       real_time_location.y,
                       real_time_location.heading,0);
          break;
      }
  
      case CHARGE:
      {
        cc.GetInfo(0,0,0);
      	cout<<"MODE into CHARGE!!!!	"<<endl;
        speed_log<<setprecision(12)<<ros::Time::now()<<" "<<0<<endl;
        into_charge = true;
        //taskpoint_task = false;
        if(work_queue_size_ == 0)   //zqq 0208
        {
          MODE = INITIAL_NAV;
          is_charge = 0;
        }
        break;
      }

      case INIT_LOCATION:
      {
        
      	//cc.GetInfo(0,0,0);
        double time_ = 0;//add by shenrk 2018.3.3
        if(is_init_location_turn == false){
          time_ = ros::Time::now().toSec() - init_time;
          cc.GetInfo(0,0,0.1);
          speed_log<<setprecision(12)<<ros::Time::now()<<" "<<0.1<<endl;
          pub_v_a_modeHandler(0,0,0.1); 
        }else{
          time_ = 40;
        }

        double init_dis = length_two_points(real_time_location.x,real_time_location.y,0,time_*0.1);
        initlocation_log<<setprecision(12)<<real_time_location.x<<" "<<real_time_location.y<<endl;
      	if(init_dis <= 1.0 && real_time_location.y >= 2.63 && fabs(real_time_location.heading) <= 10){
          if(INIT_LOCATION_count > 3){
	          cc.GetInfo(0,0,0);
            speed_log<<setprecision(12)<<ros::Time::now()<<" "<<0<<endl;
      	    cout<<"MODE from INIT_LOCATION to INITIAL_NAV!" <<endl;
            cout<<real_time_location.x<<" "<<real_time_location.y<<" "<<"0"<<" "<<time_*0.1<<" "<<init_dis<<endl;
       	    //MODE = FORWARD_MODE;
       	    MODE = INITIAL_NAV;

            std_msgs::Int8 msg;
            msg.data = 1;
            init_location_pub.publish(msg);
            //initlocation_log<<setprecision(12)<<real_time_location.x<<" "<<real_time_location.y<<" "<<"0"<<" "<<time_*0.1<<" "<<init_dis<<endl;
       	    break;
      	  }else{
      	    INIT_LOCATION_count++;
      	  }
      	}else if((ros::Time::now().toSec() - init_time) > 40){
          cc.GetInfo(1,0,0.2);
          is_init_location_turn = true;
        } 
      }

    }
    log_<<endl;
    taskpoint_stop = false;    //zqq 0110  
    status = ros::ok();
    rate.sleep();
  }
  return 0;
}
