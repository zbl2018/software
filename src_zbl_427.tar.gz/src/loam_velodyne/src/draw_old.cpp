#include <GL/glut.h>
#include <fstream>
#include <vector>
#include <sstream>
#include <ros/ros.h>
#include <sensor_msgs/Imu.h>
#include <sensor_msgs/PointCloud2.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_broadcaster.h>
#include <iostream>
#include "std_msgs/Int8.h"
#include <loam_velodyne/LocalGeographicCS.hpp>
//#include <loam_velodyne/getAngle.h>
#include <loam_velodyne/common.h>
#include "std_msgs/String.h"

#include <sensor_msgs/Imu.h>
#include <sensor_msgs/NavSatFix.h>
#include <geometry_msgs/PoseStamped.h>

using namespace std;

CarPara carpara;
string ALL_MAP;
string map_file_name;
string draw_map;

vector<GPSPoint> all_key_pc;//all map data
vector<GPSPoint> key_frame;
vector<GPSPoint> turn_frame;

struct coord
{
	double x;
	double y;
};

LocalGeographicCS ccs;
double x,y;
vector<coord> v;
vector<coord> v_new;
vector<coord> v_target;
vector<coord> v_location;
vector<coord> v_GPS;

ros::Subscriber sublocation;
ros::Subscriber subfinal;
ros::Subscriber subfix;
ros::Subscriber init_sub;

ros::Subscriber car_info_sub;

double o1,o2,o3,o4,a1,a2,a3,a4;
double f_lat,f_lon,f_heading;

double init_x,init_y,init_heading;

double lat,lon,heading;
int is_lidar;
double GaussX,GaussY;
// static double length_two_points(double x, double y, double xx,
//         double yy) {
//     double x_xx = x - xx;
//     double y_yy = y - yy;

//     return sqrt(x_xx * x_xx + y_yy * y_yy);
// }

void readDataAll_Local(const char* filename,vector<GPSPoint>& pcs){//read the map data to vector
  ifstream infile_feat(filename);
  GPSPoint gps;
  while(infile_feat>>setprecision(12)>>gps.x>>gps.height>>gps.y>>gps.cname>>gps.sname>>gps.heading>>gps.key>>gps.is_turn)
  {    
      pcs.push_back(gps); 

      if(gps.key == 1){
        key_frame.push_back(gps);
      }

      if(gps.is_turn == 1){
        turn_frame.push_back(gps);
      }
  }
  infile_feat.close();
}


void timerCb(int value) {
  //cout<<"once"<<endl;
  ros::spinOnce();

  glutTimerFunc(1, timerCb, 0);
}
int GPS_location(double lat,double lon){
  double x_ = lat;
  double y_ = lon;
  double mindis = 1000;//min distance
  int index = -1;

  if(lat != 0 && lon != 0){

    for(int i = 0; i < v.size(); i++)
    {
      double tdis = 0;
      tdis = length_two_points(x_,y_,v[i].x,v[i].y);
      if(tdis < 5) //judge the gps info is out of the map by shenrk
      {
        if(mindis > tdis)
        {
          mindis = tdis;
          index = i; 
        }
      }
    }

    if(mindis > 1.5){
      index = -2;
    }
  }
  
  return index;
}
void readfile(const char* file_name)
{
	ifstream getInfo(file_name);
	
	coord temp;
	getInfo >> x >> y; //初始坐标
	while(!getInfo.eof())
	{
		getInfo >> temp.x >> temp.y;
   // temp.x *= -1;
		temp.x -= x;
		temp.y -= y;
		v.push_back(temp);
		
	}
	getInfo.close();
}
double Gps_Pos[3] = {0};

void GPSLastHandler(const sensor_msgs::NavSatFixConstPtr& gpslast){ //fillter gps by shenrk
  LBtoxy point(gpslast->longitude, gpslast->latitude, 6);
  point.calculateAll();
  Gps_Pos[0] = point.gety() + 500000.0;
  Gps_Pos[1] = point.getx();
  
  Gps_Pos[2] = gpslast->altitude;
  
  //cout<<"latitude: "<<setprecision(12)<<Gps_Pos[0]<<" longitude:"<<Gps_Pos[1]<<" altitude:"<<Gps_Pos[2]<<endl;
}

void LocationHandler(const std_msgs::String::ConstPtr &msg){

  //cout<<msg->data<<endl;
  lat = 0;
  lon = 0;
  heading = 0;
  //coord tempt_Location;
  string moves = msg->data;
  stringstream stringin(moves);
  stringin>>lat>>lon>>heading;

  // double llat,llon;

  // ccs.xy2ll(lat,lon,llat,llon);

  // LBtoxy point(llon, llat, 6);
  // point.calculateAll();
  // GaussX = point.gety() + 500000.0;
  // GaussY = point.getx();

  GaussX = lat;
  GaussY = lon;

}

void InfoHandlers(const std_msgs::String::ConstPtr &msg){

  f_lat = 0;
  f_lon = 0;

  string moves = msg->data;
  stringstream stringin(moves);
  stringin>>f_lat>>f_lon>>f_heading;
}

void map_Handler(const std_msgs::String::ConstPtr &msg){

  key_frame.clear();
  v_new.clear();
  v_location.clear();

  ALL_MAP.clear();
  
  ALL_MAP = msg->data;
  cout<<"path have receive! draw"<<endl;

  decodePath(ALL_MAP,key_frame);//解析规划路径
  cout<<"map size: "<<key_frame.size()<<endl;
  //new_path_rece = true;
}

void InitHandler(const std_msgs::String::ConstPtr &msg){
  init_x =  init_y = init_heading = 0;
  string inits = msg->data;
  stringstream stringin(inits);
  stringin>>setprecision(12)>>init_x>>init_y>>init_heading;
}

void InfoHandler(const std_msgs::String::ConstPtr &msg){
  //cout<<"draw: "<<msg->data<<endl;
}

void Get_Target_Point(coord start,coord& target){

  int start_index = GPS_location(start.x,start.y);
  double distance_  = 0;
  int i = start_index + 1;
  
  while(distance_ < 0.5 && i < v.size()-1){
    double x,y;
    x = v[i].x;
    y = v[i].y;
    distance_ = abs(length_two_points(x,y,v[start_index].x,v[start_index].y));
    //cout << distance_ << endl;
    i++;
  }
  //cout<<setprecision(12)<<distance_<<endl;
  target.x = v[i].x;
  target.y = v[i].y;

}

void view()
{

	glClear(GL_COLOR_BUFFER_BIT);
   	glLineWidth(2);
    glColor3d(0,1,0);
    glBegin(GL_LINE_STRIP);
    for(vector<coord>::iterator it = v.begin(); it != v.end()-1;it++)
    {
    	glVertex2d(-(it->x), it->y);//绘图坐标系改为右手系   祖冰修改-8-29
    }
    glEnd();
    //glFlush();
    //glLineWidth(2);

    glPointSize(3); 
    glColor3d(1,0,3);
    glBegin(GL_POINTS);
    for(vector<coord>::iterator it = v_location.begin(); it != v_location.end();it++)
    {
        //cout << it->x << " " << it->y << endl;
        glVertex2d(-(it->x), it->y); //绘图坐标系改为右手系 祖冰修改-8-29
    }
    glEnd();


    glPointSize(5); 
    glColor3d(0,0,0);
    glBegin(GL_POINTS);
    for(vector<coord>::iterator it = v_new.begin(); it != v_new.end();it++)
    {
        //cout << it->x << " " << it->y << endl;
        glVertex2d(-(it->x - x), it->y - y); //绘图坐标系改为右手系 祖冰修改-8-29
    }
    glEnd();

    glPointSize(2); 
    glColor3d(1,0,0);
    glBegin(GL_POINTS);
    for(vector<GPSPoint>::iterator it = key_frame.begin(); it != key_frame.end();it++)
    {
        //cout << it->x << " " << it->y << endl;
        glVertex2d(-(it->x - x), it->y - y); //绘图坐标系改为右手系 祖冰修改-8-29
    }
    glEnd();
    
    glPointSize(5); 
    glColor3d(0,0,1);
    glBegin(GL_POINTS);
    for(vector<GPSPoint>::iterator it = turn_frame.begin(); it != turn_frame.end();it++)
    {
        //cout << it->x << " " << it->y << endl;
        glVertex2d(-(it->x), it->y); //绘图坐标系改为右手系 祖冰修改-8-29
    }
    glEnd();

    /*glPointSize(4); 
    glColor3d(0,0,0);
    glBegin(GL_POINTS);  
    glVertex2d(Gps_Pos[0]-x, Gps_Pos[1]-y);
    glEnd();*/
    //预瞄点
    glPointSize(8); 
    glColor3f(0.5,1,1);
    glBegin(GL_POINTS);
    //for(vector<coord>::iterator it = v_target.begin(); it != v_target.end();it++)
    //{
        //cout << it->x << " " << it->y << endl;
        vector<coord>::iterator it = v_target.end() - 1;
        glVertex2d(-((it->x) - x), (it->y - y));
    //}
    glEnd();

    /*glPointSize(9); 
    glColor3d(1,0,1);
    glBegin(GL_POINTS);
    glVertex2d((577780.344536 - x), (2523518.91581 - y));
    glVertex2d((577764.11684 - x), (2523550.17417 - y));
    glVertex2d((577746.626983 - x), (2523542.05717 - y));
    glVertex2d((577761.038247 - x), (2523509.58351 - y));
    glEnd();*/
    glutSwapBuffers(); 
}

void update()
{
    coord newData;
    coord tempt_Location;
    coord nowLocation;

    nowLocation.x = GaussX;
    nowLocation.y = GaussY;

    tempt_Location.x = GaussX - x;
    tempt_Location.y = GaussY - y;
    v_location.push_back(tempt_Location);

    newData.x = init_x - x;
    newData.y = init_y - y;
	  v_new.push_back(newData); // 更新的坐标


    /*double gx,gy,lat_,lon_;
    ccs.xy2ll(f_lat,f_lon,lat_,lon_);
    LBtoxy point(lon_, lat_, 6);
    point.calculateAll();
    gx = point.gety() + 500000.0;
    gy = point.getx();

    //cout<<"draw:"<<gx<<" "<<gy<<" "<<f_lat<<" "<<f_lon<<" "<<lat_<<" "<<lon_<<endl;

    tempt_Location.x = gx - x;
    tempt_Location.y = gy - y;
    v_location.push_back(tempt_Location);*/
    coord target;
    
    Get_Target_Point(nowLocation,target);
    v_target.push_back(target);
	  glutPostRedisplay();
}

void Initial()
{
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f);  //清屏颜色
    glMatrixMode(GL_PROJECTION);
    gluOrtho2D(-10, 10, -15.0, 15.0);   //投影到裁剪窗大小：世界
}

int main (int argc,char** argv)
{
	ros::init(argc, argv, "draw");
  ros::NodeHandle nh;

  DecodePara("/home/dky/catkin_lidar/src/loam_velodyne/carPara.ini",carpara);

  draw_map = carpara.draw_map;
  map_file_name = carpara.map_file_name;
  
  cout<<draw_map<<endl;
  cout<<map_file_name<<endl;

	readfile(draw_map.c_str());

  readDataAll_Local(map_file_name.c_str(),all_key_pc);

  //////////////////////////////////////////////////////////////////////////////////////////
  ros::Subscriber sub_map_data = nh.subscribe<std_msgs::String>("/map_send",1000,map_Handler);
  //////////////////////////////////////////////////////////////////////////////////////////

  //readfile("/home/shenrk/testdata/819/path_gps_pc_GS.txt");
	cout<<"read end"<<endl;
	sublocation = nh.subscribe<std_msgs::String>("/final_data",1000,LocationHandler);

  car_info_sub = nh.subscribe<std_msgs::String>("/car_info",100,InfoHandler);//接收底层数据

  init_sub = nh.subscribe<std_msgs::String>("location_icp",5,InitHandler);
  //subfix = nh.subscribe<sensor_msgs::NavSatFix>("fix", 10,GPSLastHandler);

  //subfinal = nh.subscribe<std_msgs::String>("odo_final_data",1000,InfoHandlers);
  coord first;
  
  first.x  =  0;
  first.y  =  0;
  v_new.push_back(first);
  v_target.push_back(first);
  v_location.push_back(first);
  v_GPS.push_back(first);
  //cout<<"loop"<<endl;
  glutInit(&argc, argv);
  glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE);
  glutInitWindowPosition(100, 100);
  glutInitWindowSize(700, 700);
  glutCreateWindow("HelloOpenGL");
  glutIdleFunc(&update);
  glutDisplayFunc(&view);
  Initial();

  glutTimerFunc(1, timerCb, 0);
  glutMainLoop();

	return 0;
}
