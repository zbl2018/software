#include <iostream>
#include <vector>

#include <loam_velodyne/Detect.h>

using namespace std;

void Detect::GetData(const Point & t, const vector<Point> & obstacles)
{

	OD.GetTargetPoint(t);
	mode = IsThisTimeCrashed(obstacles);

}

int Detect::IsThisTimeCrashed(const vector<Point> & obstacles)
{

	for(vector<Point>::const_iterator it=obstacles.begin(); it != obstacles.end(); it++)
	{
		if(OD.GetCrashPoint(*it))
		{
			return 1;
		}
	}

	return 0;

}