
#include <loam_velodyne/ObstacleDetect.h>
#include <iostream>
#include <cmath>

using namespace std;

void ObstacleDetect::GetTargetPoint(const Point & t)
{
	a.GetTargetPoint(t);
}

bool ObstacleDetect::GetCrashPoint(const Point & p)
{
	CrashPoint = p;
	if(IsCrash())
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool ObstacleDetect::IsCrash()
{

	double distance = 0;

	for(vector<Point>::iterator it=a.TheSetOfPointsOnTheArc.begin(); it != a.TheSetOfPointsOnTheArc.end(); it++)
	{
		distance = ComputeDistanceBetween2Points(CrashPoint,*it);

		if(distance < CRASHDISTANCE)
		{
			if(it->y > CrashPoint.y)
			{
				LeftOrRight = 1;
			}
			return true;
		}
	}

	return false;

}

double ObstacleDetect::ComputeDistanceBetween2Points(const Point & p1, const Point & p2)
{

	double DeltaX = (p1.x - p2.x) * (p1.x - p2.x);
	double DeltaY = (p1.y - p2.y) * (p1.y - p2.y);
	double distance = sqrt(DeltaX + DeltaY);
	return distance;
	
}