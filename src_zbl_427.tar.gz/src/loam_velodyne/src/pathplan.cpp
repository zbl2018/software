#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <iomanip>
#include <cstring>
#include <sstream>
#include <stdio.h>   
#include <stdlib.h>  

#include <ros/ros.h>
#include "std_msgs/String.h" 
#include "std_msgs/Int8.h"
#include "std_msgs/Int64.h"
#include <boost/lexical_cast.hpp>

#include <loam_velodyne/pathPlan.hpp>
#include <loam_velodyne/geography.hpp>

using namespace std;

const string taskfile("/home/chen/Project/catkin_sysu/src/loam_velodyne/tasknode.txt");

ros::Publisher Path_send;
ros::Publisher Task_plan;
ros::Publisher Stop_pub;
ros::Subscriber Arrive_task;
ros::Subscriber Location_now;
ros::Subscriber Obstacle_plan;
ros::Subscriber AutoReturn_sub;
ros::Subscriber Charge_sub;
ros::Subscriber AutoTask_sub;


double lat_now = 0;
double lon_now = 0;
// double lat_now = 17.8;
// double lon_now = 2.71815;
// double lat_now = 17.868404;
// double lon_now = 11.018753;
double heading_now = 0;

double taskx;
double tasky;

double chargex = -0.043422000000000002;
double chargey = -2.3526159999999998;

int is_car_arrvie = 1;
int is_obstacle = 0;
int is_charge = 0;
int is_return = 0;
int is_autotask = 1;

vector<PointS> task;

void LocationHandler(const std_msgs::String::ConstPtr &msg){
    
    string moves = msg->data;
    //stringstream stringin(moves);
    stringstream stringin2(moves);
    //stringin>>lat>>lon>>heading;

    stringin2>>setprecision(12)>>lat_now>>lon_now>>heading_now;

    // if(fabs(lat_now)<1.0 && fabs(lon_now)<1.0){
    //     lat_now = 17.868404;
    //     lon_now = 11.018753;
    //     heading_now = -1.57;
    // }

    //heading = heading * 180.0 / 3.14159265;
} 

void Arrive_Car_Handler(const std_msgs::Int8::ConstPtr &msg){
    is_car_arrvie = msg->data;
    cout<<"the car have stop ok!!!!!!!!!!!!"<<endl;
}

void AutoReturnHandler(const std_msgs::Int8::ConstPtr &msg){
    is_return = msg->data;
    cout<<"return!!!!!!!!!!!!"<<endl;
}

void ChargeHandler(const std_msgs::Int8::ConstPtr &msg){
    is_charge = msg->data;
    cout<<"charge!!!!!!!!!!!!"<<endl;
}

void AutoTaskHandler(const std_msgs::Int8::ConstPtr &msg){
    is_autotask = msg->data;
    cout<<"auto!!!!!!!!!!!!"<<endl;
}

void Obstacle_plan_Handle(const std_msgs::Int8::ConstPtr &msg){
    is_obstacle = msg->data;
}

int main(int argc, char **argv){
    ros::init(argc, argv, "pathplan");
    ros::NodeHandle nh;

    Path_send = nh.advertise<std_msgs::String>("/map_send",1000);//map send test
    Task_plan = nh.advertise<std_msgs::String>("/task_net",1000);//任务点数据发布
    Stop_pub = nh.advertise<std_msgs::Int8>("stop_net", 5);
    Location_now = nh.subscribe<std_msgs::String>("/final_data",1000,LocationHandler);
    Arrive_task = nh.subscribe<std_msgs::Int8>("/car_arrive",5,Arrive_Car_Handler);
    Obstacle_plan = nh.subscribe<std_msgs::Int8>("/obstacle_plan",5,Obstacle_plan_Handle);
    AutoReturn_sub = nh.subscribe<std_msgs::Int8>("AutoReturn", 5, AutoReturnHandler);
    Charge_sub = nh.subscribe<std_msgs::Int8>("charge", 5, ChargeHandler);
    AutoTask_sub = nh.subscribe<std_msgs::Int8>("AutoTask", 5, AutoTaskHandler);

    ifstream infile;
    infile.open(taskfile.c_str());
    task.clear();
    stringstream ss;
    string stirng_tmp;

    double task_lat = 0;
    double task_lon = 0;

    ros::Duration(15).sleep();

    while(!infile.eof())
    {
        stirng_tmp.clear();
        ss.clear();
        getline(infile,stirng_tmp);
        if(stirng_tmp.compare("") == 0) continue;
        ss<<stirng_tmp;
        ss>>setprecision(12)>>task_lat>>task_lon;
        PointS newpoint;
        newpoint.lat = task_lat;
        newpoint.lon = task_lon;
        task.push_back(newpoint);
    }

    infile.close();
    cout<<task.size()<<endl;
    for(int i=0;i<task.size();i++)
    {
        cout<<task[i].lat<<" "<<task[i].lon<<endl;
    }

    int task_id_old = 0;
    int task_id = 0;
    int task_size = task.size();

    ros::Rate rate(200);
    bool status = ros::ok();
    while(status)
    {
    	ros::spinOnce();

        if(is_car_arrvie)
    	{
            if(is_autotask)
            {
                /*while(true)
                {
                    //task_id = rand() % task.size();
                    task_id = task_id % task.size();
                    
                    
                    if(task_id_old != task_id)
                    {
                        task_id_old = task_id;

                        break;
                    }
                    task_id++;
                }*/
                cout<<"Plan!!!!!!!!!!!!!!!!!!!!!!!!!!"<<endl;
                cout<<setprecision(12)<<"lat_now: "<<lat_now<<"  lon_now: "<<lon_now<<endl;
                cout<<"task_x: "<<task[task_id].lat<<" task_y: "<<task[task_id].lon<<" task_id:"<<task_id<<endl;
                
                sleep(5);
                cout<<"sleep for 5 sec!!"<<endl;

                vector<PointS> task_node;
                PointS task_now;
                task_now.lat = lat_now;
                task_now.lon = lon_now;
                task_node.push_back(task_now);
                task_node.push_back(task[task_id]);


                // lat_now = task[task_id].lat;
                // lon_now = task[task_id].lon;

                taskx = task[task_id].lat;
                tasky = task[task_id].lon;

                std_msgs::String msg;

                string task_x = boost::lexical_cast<string>(task[task_id].lat);
                string task_y = boost::lexical_cast<string>(task[task_id].lon);
                string task_speed = "0.4";
                string task_string("");
                task_string.append(task_x).append(" ").append(task_y).append(" ").append(task_speed);
                msg.data = task_string;
                Task_plan.publish(msg);


                pathPlan pa;
                vector<PointS> plan_node = pa.calculate(task_node);
                string path_send = pa.pathplan;//规划完成的导航路径

                msg.data = path_send;
                Path_send.publish(msg);
                is_car_arrvie = 0;      

                if(++task_id == task_size)
                {
                    task_id = 0;
                }          
            }

    	}


        if(is_obstacle)
        {
            vector<PointS> task_node;
		    PointS task_now;
		    task_now.lat = lat_now;
		    task_now.lon = lon_now;
		    task_node.push_back(task_now);
            task_now.lat = taskx;
            task_now.lon = tasky;
		    task_node.push_back(task_now);

		    std_msgs::String msg;
		    string task_x = boost::lexical_cast<string>(task[task_id].lat);
		    string task_y = boost::lexical_cast<string>(task[task_id].lon);
		    string task_speed = "0.2";
		    string task_string("");
		    task_string.append(task_x).append(" ").append(task_y).append(" ").append(task_speed);
		    msg.data = task_string;
            Task_plan.publish(msg);

            double heading = heading_now *180/3.14159;
            pathPlan pa;
            vector<PointS> plan_node = pa.obstacles(task_node,heading);
		    string path_send = pa.pathplan;//规划完成的导航路径

		    msg.data = path_send;
            Path_send.publish(msg);

            is_obstacle = 0;
        }

        if(is_charge)
        {
            vector<PointS> task_node;
            PointS task_now;
            task_now.lat = lat_now;
            task_now.lon = lon_now;
            task_node.push_back(task_now);
            task_now.lat = chargex;
            task_now.lon = chargey;
            task_node.push_back(task_now);

            std_msgs::String msg;
            string task_x = boost::lexical_cast<string>(task_now.lat);
            string task_y = boost::lexical_cast<string>(task_now.lon);
            string task_speed = "-0.2";
            string task_string("");
            task_string.append(task_x).append(" ").append(task_y).append(" ").append(task_speed);
            msg.data = task_string;
            Task_plan.publish(msg);

            pathPlan pa;
            vector<PointS> plan_node = pa.calculate(task_node);
            string path_send = pa.pathplan;//规划完成的导航路径

            msg.data = path_send;
            Path_send.publish(msg);

            is_charge = 0;            
        }

        if(is_return)
        {
            std_msgs::Int8 stopmsgs;
            stopmsgs.data = 1;
            Stop_pub.publish(stopmsgs);

            ros::Duration(5).sleep();


            vector<PointS> task_node;
            PointS task_now;
            task_now.lat = lat_now;
            task_now.lon = lon_now;
            task_node.push_back(task_now);
            task_now.lat = 0.0;
            task_now.lon = 0.0;
            task_node.push_back(task_now);

            std_msgs::String msg;
            string task_x = boost::lexical_cast<string>(task_now.lat);
            string task_y = boost::lexical_cast<string>(task_now.lon);
            string task_speed = "0.2";
            string task_string("");
            task_string.append(task_x).append(" ").append(task_y).append(" ").append(task_speed);
            msg.data = task_string;
            Task_plan.publish(msg);

            pathPlan pa;
            vector<PointS> plan_node = pa.calculate(task_node);
            string path_send = pa.pathplan;//规划完成的导航路径

            // stopmsgs.data = 0;
            // Stop_pub.publish(stopmsgs);

            msg.data = path_send;
            Path_send.publish(msg);



            is_autotask = 0;
            is_return = 0;            
        }

        status = ros::ok();
        rate.sleep();
    }
    return 0;  
}
