#ifndef REGISTRATION
#define REGISTRATION

#include <pcl/registration/correspondence_estimation.h>
#include <pcl/registration/transformation_estimation.h>
#include <pcl/registration/transformation_estimation_svd.h>
#include <pcl/registration/registration.h>
#include <pcl/registration/correspondence_rejection_distance.h>
#include <pcl/registration/icp.h>
#include <Eigen/src/Geometry/EulerAngles.h>

#include <limits>
#include <liblas/liblas.hpp>
#include <liblas/version.hpp>
#include <liblas/point.hpp>
#include <pcl/common/transforms.h>
#include <pcl/filters/extract_indices.h>
#include <strstream>
#include <ctime>
#include <tbb/tbb.h>
#include <tbb/compat/ppl.h>
#include <tbb/concurrent_vector.h>
#include "dataIo.h"
#include "utility.h"
#include "BinaryFeatureExtraction.h"
#include "StereoBinaryFeature.h"

using namespace  std;
using namespace utility;



namespace pcRegistration
{

    struct RefineRgOptions
    {
        double euclideanFitnessEpsilon;//前后两次迭代最近点的都是距离变化值，小于该值认为已经收敛;
        double transformationEpsilon;//前后两次迭代旋转矩阵的差异阈值，小于该值认为已经收敛;
        int    maximumIterations;//设置迭代的最大次数
        float  maxCorrespondenceDistance;//对应点的最大距离约束;
        float  stepLength;//maxCorrespondenceDistance 按照该步长逐渐减小
        int    stepError;
    };

    struct CoarseRgOptions
    {
        float tolerantEuclideanDis;//几何一致性的参数;
        float tolerantHammingDis;//允许0.06*size,特征一致性的参数;
        float tolerantOverlap;
    };


    struct Node
    {
        int node_id;
        vector<int> father_node_ids;
        vector<int> children_node_ids;
        Eigen::Matrix4f targetToBase;
        int graph_id;
        bool has_visited;
    };

    struct Edge
    {
        int source_node_id;
        int target_node_id;
        unsigned int weightPtNum;
        float weightOverlap;
        Eigen::Matrix4f targetToSrc;
        bool is_node_id_convert;//新增;
        Edge()
        {
            is_node_id_convert = false;
        }
    };


    struct Graph
    {
        vector<Node, Eigen::aligned_allocator<Node>> nodes;
        vector<Edge, Eigen::aligned_allocator<Edge>> edges;
    };

    struct PathNode
    {
        int node_id;
        bool is_valid;
        bool has_used;
    };

    struct Path
    {
        vector<PathNode> node_ids;
    };

    class CRegistration : public StereoBinaryFeature, DataIo
    {
    public:
        CRegistration(CoarseRgOptions coRgopt, RefineRgOptions reRgopt)
        {
            m_reRgopt = reRgopt;
            m_coRgopt = coRgopt;
        }

        /*基于最小生成树策略的多视角点云数据配准;*/
        bool  MultiviewMatchingBasedOnMST(std::vector<std::string> &fileNames,
                                          tbb::concurrent_vector<pointCloudXYZI> &pointClouds,
                                          std::vector<std::vector<std::vector<StereoBinaryFeature>>> &binaryShapeContextsPointClouds,
                                          tbb::concurrent_vector<pointCloudXYZI> &RegPointClouds);

        /*根据关键点的个数确定种子点云;*/
        size_t calculateSeedPointCloudId(std::vector<std::vector<std::vector<StereoBinaryFeature>>> &binaryShapeContextsPointClouds);

        /*穷尽的两两配准;*/
        bool ExhaustivePairWiseRegistration(std::vector<std::string> &fileNames,
                                            tbb::concurrent_vector<pointCloudXYZI> &pointClouds,
                                            std::vector<std::vector<std::vector<StereoBinaryFeature>>> &binaryShapeContextsPointClouds,
                                            Graph &graph);

        /*一对多的全局配准，寻找与之最接近的帧*/
        bool One2AllPairRegistration(std::vector<std::string> &fileNames,
                                     pointCloudXYZIPtr target,
                                     std::vector<std::vector<StereoBinaryFeature>>&binaryShapeContextsPointClouds_target,
                                     tbb::concurrent_vector<pointCloudXYZI> &pointClouds,
                                     std::vector<std::vector<std::vector<StereoBinaryFeature>>> &binaryShapeContextsPointClouds,
                                     int & most_similar_index);

        /*----------------------------------------------------Pairwise Registration begin------------------------------------------;*/

        /*利用二进制特征实现两两粗配准;*/
        bool PairwiseCoarseRegistrationBasedOnBsc(pointCloudXYZIPtr src_cloud, pointCloudXYZIPtr target_cloud,
                                                  std::vector<std::vector<StereoBinaryFeature>> &binaryShapeContextsPointCloudSrc,
                                                  std::vector<std::vector<StereoBinaryFeature>> &binaryShapeContextsPointCloudTarget,
                                                  unsigned int &CorrespondingPtNum,float &maxOverlap, Eigen::Matrix4f &coarse_transformation);

        /*计算两站之间符合特征一致性的点对集合;*/
        bool CalculateFeatureConsistencyPointPairs(std::vector<StereoBinaryFeature>  &src_sbfs_coor1,
                                                   std::vector<StereoBinaryFeature>  &target_sbfs_coor1,
                                                   std::vector<StereoBinaryFeature>  &target_sbfs_coor2,
                                                   utility::concurrencyVectorRegistrationPair &reg_pairs_f);

        /*从target_sbfs中找到跟src_sbf中最佳匹配的特征;*/
        bool FindOptimalFeaturePairBasedOnOneWayOptimal(size_t srcIndex, std::vector<StereoBinaryFeature>  &src_sbfs_coor1,
                                                        std::vector<StereoBinaryFeature> & target_sbfs_coor1,
                                                        std::vector<StereoBinaryFeature> & target_sbfs_coor2,
                                                        utility::RegistrationPair &feature_pair);

        /*从target_sbfs中找到跟src_sbf中最佳匹配的特征;*/
        bool FindOptimalFeaturePairBasedOnTwoWayOptimal(size_t srcIndex, std::vector<StereoBinaryFeature>  &src_sbfs_coor1,
                                                        std::vector<StereoBinaryFeature> & target_sbfs_coor1,
                                                        std::vector<StereoBinaryFeature> & target_sbfs_coor2,
                                                        utility::RegistrationPair &feature_pair);

        /*计算满足特征一致性的点集中，满足几何约束一致性的点对集合;*/
        bool GeometricConsistencyClusterRandom(std::vector<StereoBinaryFeature> & src_sbfs, std::vector<StereoBinaryFeature> & target_sbfs,
                                               utility::concurrencyVectorRegistrationPair & reg_pairs_f,
                                               utility::concurrencyVectorVectorRegistrationPair & reg_pairs_g);

        /*计算满足特征一致性的点集中，满足几何约束一致性的点对集合;*/
        bool GeometricConsistencyClusterExhaustivity(std::vector<StereoBinaryFeature> & src_sbfs, std::vector<StereoBinaryFeature> & target_sbfs,
                                                     utility::concurrencyVectorRegistrationPair & reg_pairs_f,
                                                     utility::concurrencyVectorVectorRegistrationPair & reg_pairs_g);
        /*判断是否满足几何约束一致性;*/
        bool JudgeTheGeometricConsistency(std::vector<StereoBinaryFeature> & src_sbf, std::vector<StereoBinaryFeature> & target_sbfs,
                                          utility::concurrencyVectorRegistrationPair & reg_pair, int seed_id1, int seed_id2,
                                          int seed_id3, int candidate_id);


        /*判断三角形全等;*/
        bool JudgeTriangleEquivalent(std::vector<StereoBinaryFeature> & src_sbf, std::vector<StereoBinaryFeature> & target_sbfs,
                                     utility::concurrencyVectorRegistrationPair & reg_pairs_r, int id1, int id2, int id3);



        /*根据符合几何一致性的点集中最大的三个点集分别计算两站之间的转换矩阵以及重叠度,把重叠度最大的转换矩阵输出;*/
        float calculateTransformationBasedOnMaxOverlap(pointCloudXYZIPtr pointCloud1, pointCloudXYZIPtr pointCloud2,
                                                       std::vector<std::vector<StereoBinaryFeature>> &binaryShapeContextsPointCloudSrc,
                                                       std::vector<std::vector<StereoBinaryFeature>> &binaryShapeContextsPointCloudTarget,
                                                       utility::concurrencyVectorVectorRegistrationPair & reg_pairs_fg,
                                                       Eigen::Matrix4f &coarse_transformation);

        /*计算两站之间的重叠度;*/
        float calculateOverlapOfTwoPointClouds(pointCloudXYZIPtr pointCloud1, pointCloudXYZIPtr pointCloud2);

        float calculateOverlapOfTwoPointClouds(pointCloudXYZIPtr pointCloud1, pointCloudXYZIPtr pointCloud2,
                                               const Eigen::Matrix4f &transformation, const float distanceT);

        /*根据对应点集计算旋转平移矩阵;*/
        void CalculateTransformationBasedOnCPoints(std::vector<StereoBinaryFeature> &src_sbfs, std::vector<StereoBinaryFeature> &target_sbf,
                                                   utility::concurrencyVectorRegistrationPair & reg_pairs, Eigen::Matrix4f &targetToSrc);


        /*----------------------------------------------------Pairwise Registration end------------------------------------------;*/

        /*计算图的最小生成树;*/
        bool  calculateTheMinSpanningTreeOfGraph(unsigned int nodesNum, Graph &graph, Graph & min_st);

        /*用精配准的转换矩阵更新最小生成树中各边的转换矩阵;*/
        void refineTransformationOfMST(Graph & min_st, tbb::concurrent_vector<pointCloudXYZI> &pointClouds);

        /*根据结点的度确定基准站;*/
        int  calculateTheBaseStationBasedOnNodeDegree(Graph & min_st);

        /*从最小生成树中找到任意节点到Base节点的路径;*/
        bool  findRegistrationPathBetweenBaseAndTarget(Graph& min_st, int base_id, int target_id, Path &target_to_base_path);

        /*根据任意节点到Base节点的路径实现两站之间的配准;*/
        void calculateTransformationBetweenBaseAndTarget(Path target_to_base_path, Graph &min_st, Eigen::Matrix4f & target_to_base);

        /*精配准;*/
        double FineRegistration(pointCloudXYZIPtr cloud_src, pointCloudXYZIPtr cloud_target,
                                Eigen::Matrix4f &coarseTargetToSource, Eigen::Matrix4f &fineTargetToSource);


        //评价描述子的鲁棒性;
        bool evaluateRobust(std::vector<std::vector<StereoBinaryFeature>> &binaryShapeContextsPointCloudSrc,
                            std::vector<std::vector<StereoBinaryFeature>> &binaryShapeContextsPointCloudTarget);

        //评价描述子的描述性;
        bool evaluateDescriptive(std::vector<std::vector<StereoBinaryFeature>>& binaryShapeContextsPointCloudSrc,
                                 std::vector<std::vector<StereoBinaryFeature>> &binaryShapeContextsPointCloudTarget,
                                 unsigned int &featureCorrespondingNum, unsigned int &trueCorrespondingNum);



        /*计算对应点对的hamming距离直方图以及非对应点对的hamming距离直方图;*/
        void CalculateCorrespondingPtsAndHammingDistance(pointCloudXYZIPtr src_cloud, pointCloudXYZIPtr target_cloud,
                                                         pcl::PointIndicesConstPtr &src_indices, pcl::PointIndicesConstPtr &target_indices,
                                                         std::vector<StereoBinaryFeature> & src_sbf, std::vector<StereoBinaryFeature> & target_sbf,
                                                         Eigen::Matrix4f &transformation, utility::concurrencyVectorRegistrationPair & reg_pairs_c);

        /*统计配准两站的 1-precise vs recall曲线*/
        void precisionVSRecallValue(pointCloudXYZIPtr cloud_src, pointCloudXYZIPtr cloud_target,
                                    pcl::PointIndicesConstPtr &src_indices, pcl::PointIndicesConstPtr &target_indices,
                                    std::vector<StereoBinaryFeature>& features1, std::vector<StereoBinaryFeature>& features2,
                                    int bit_num, const string& path);

        /*输出两两配准后的点云;*/
        void outputPairWiseRegistratedPointClouds(float overlap, const string & fileName1, const string & fileName2, pointCloudXYZIPtr pointCloud1, pointCloudXYZIPtr pointCloud2);

        /*输出多站配准后的点云;*/
        void outputMultiviewRegistrationPointClouds(const std::vector<std::string> &fileNames, tbb::concurrent_vector<pointCloudXYZI> &regPointClouds);


        void outputMatrix(float overlap, const string & fileName1, const string & fileName2, const Eigen::Matrix4f &transformation);

        void outputMatrix(const Eigen::Matrix4f &transformation);


    protected:

    private:



        bool calculateCorrespondingKeypointNumber(utility::concurrencyVectorRegistrationPair &reg_pairs_f,
                                                  std::vector<StereoBinaryFeature> &binaryShapeContextsPointCloudSrc,
                                                  std::vector<StereoBinaryFeature> &binaryShapeContextsPointCloudTarget,
                                                  unsigned int &trueCorrespondingNum);

        bool calculateCorrespondingKeypointsNumber(std::vector<StereoBinaryFeature> &binaryShapeContextsPointCloudSrc,
                                                   std::vector<StereoBinaryFeature> &binaryShapeContextsPointCloudTarget,
                                                   utility::concurrencyVectorRegistrationPair &reg_pairs);


        /*计算两个坐标系的对应轴的夹角;*/
        void calculateAnglesBetweenCoordinateSystems(CoordinateSystem &localCoordinateSystem1, CoordinateSystem &localCoordinateSystem2, float &a, float &b, float &c);


        int getNumof1InFeature(StereoBinaryFeature &feature)
        {
            int count(0);
            for (int i = 0; i < feature.size_; i++)
            {
                int bit_num = i % 8;
                int byte_num = i / 8;
                char test_num = 1 << bit_num;
                if (feature.feature_[byte_num] & test_num)
                {
                    count++;
                }

            }
            return count;
        }

        //计算两个点之间的3维空间距离;
        float Comput3DDistanceBetweenPoints(Eigen::Vector3f pt1, Eigen::Vector3f pt2)
        {
            float dertax, dertay, dertaz, dis;
            dertax = pt1.x() - pt2.x();
            dertay = pt1.y() - pt2.y();
            dertaz = pt1.z() - pt2.z();
            dis = (dertax)*(dertax)+(dertay)*(dertay)+(dertaz)*(dertaz);
            dis = sqrt(dis);
            return dis;
        }

        RefineRgOptions m_reRgopt;
        CoarseRgOptions m_coRgopt;
        void outPutTop5SimilarPC(const std::string &fileName, const Eigen::MatrixXf &matrixXf);
    };
}

#endif
