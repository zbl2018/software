#pragma once


#include <pcl/point_types.h>
#include <pcl/point_cloud.h>
#include <pcl/common/common.h>
#include <boost/filesystem.hpp>
//#include <liblas/liblas.hpp>
#include <liblas/header.hpp>
#include <vector>
#include <limits>
#include <iostream>
#include <fstream>


template<typename PointT>
class VoxelFilter
{
public:
	typedef typename pcl::PointCloud<PointT>		PointCloud;
	typedef typename pcl::PointCloud<PointT>::Ptr	PointCloudPtr;

	float _voxel_size;		//格网大小

	VoxelFilter(float voxel_size):_voxel_size(voxel_size) {}

	struct IDPair
	{
		IDPair() :idx(0), voxel_idx(0) {}

		unsigned long long voxel_idx;
		unsigned int idx;

		//重载比较函数
		bool operator<(const IDPair& pair) { return voxel_idx < pair.voxel_idx; }
	};

	//进行抽稀
	PointCloud filter(const PointCloudPtr& cloud_ptr)
	{
		//voxel大小的倒数
		float inverse_voxel_size = 1.0f / _voxel_size;

		//获取最大最小
		Eigen::Vector4f min_p, max_p;
		pcl::getMinMax3D(*cloud_ptr, min_p, max_p);

		//计算总共的格子数量
		Eigen::Vector4f gap_p = max_p - min_p;
		unsigned long long max_vx = ceil(gap_p.coeff(0)*inverse_voxel_size)+1;
		unsigned long long max_vy = ceil(gap_p.coeff(1)*inverse_voxel_size)+1;
		unsigned long long max_vz = ceil(gap_p.coeff(2)*inverse_voxel_size)+1;

		//判定格子数量是否超过给定值
		if (max_vx*max_vy*max_vz >= std::numeric_limits<unsigned long long>::max())
		{
			std::cout << "抽稀失败，最大格子数量过多";
		}

		//计算乘子
		unsigned long long mul_vx = max_vy*max_vz;
		unsigned long long mul_vy = max_vz;
		unsigned long long mul_vz = 1;

		//计算所有点的位置
		std::vector<IDPair> id_pairs(cloud_ptr->size());
		unsigned int idx = 0;
		for (auto it = cloud_ptr->begin(); it != cloud_ptr->end(); it++)
		{
			//计算编号
			unsigned long long vx = floor((it->x - min_p.coeff(0))*inverse_voxel_size);
			unsigned long long vy = floor((it->y - min_p.coeff(1))*inverse_voxel_size);
			unsigned long long vz = floor((it->z - min_p.coeff(2))*inverse_voxel_size);

			//计算格子编号
			unsigned long long voxel_idx = vx*mul_vx + vy*mul_vy + vz*mul_vz;

			IDPair pair;
			pair.idx = idx;
			pair.voxel_idx = voxel_idx;
			id_pairs.push_back(pair);

			idx++;
		}

		//进行排序
		std::sort(id_pairs.begin(), id_pairs.end());

		//保留每个格子中的一个点
		unsigned int begin_id = 0;
		PointCloudPtr result_ptr(new PointCloud);
		while (begin_id < id_pairs.size())
		{
			//保留第一个点
			result_ptr->push_back(cloud_ptr->points[id_pairs[begin_id].idx]);

			//往后相同格子的点都不保留
			unsigned int compare_id = begin_id + 1;
			while (compare_id < id_pairs.size() && id_pairs[begin_id].voxel_idx == id_pairs[compare_id].voxel_idx)
				compare_id++;
			begin_id = compare_id;
		}
		return *result_ptr;
	}


	void outputSimplifiedLas(const std::string &fileName, pcl::PointCloud<pcl::PointXYZI> &pointCloud)
	{
		utility::pointCloudBound bound;
		utility::getCloudBound(pointCloud, bound);


		boost::filesystem::path dir(fileName);
		std::string folderName;
		folderName = "SimplifiedLas";

		//创建文件夹;
		if (!boost::filesystem::exists(folderName))
		{
			boost::filesystem::create_directory(folderName);
		}

		//获取不包含路径和后缀的文件名;
		std::string outputFileName;
		outputFileName = dir.stem().string();
		outputFileName = folderName + "\\" + outputFileName + "_Simplified.las";

		std::ofstream ofs(outputFileName, std::ios::out | std::ios::binary);

		if (ofs.is_open())
		{
			liblas::Header header;
			header.SetDataFormatId(liblas::ePointFormat2);
			header.SetVersionMajor(1);
			header.SetVersionMinor(2);
			header.SetMin(bound.minx, bound.miny, bound.minz);
			header.SetMax(bound.maxx, bound.maxy, bound.maxz);
			header.SetOffset((bound.minx + bound.maxx) / 2.0, (bound.miny + bound.maxy) / 2.0, (bound.minz + bound.maxz) / 2.0);

			header.SetScale(0.01, 0.01, 0.01);
			header.SetPointRecordsCount(pointCloud.points.size());

			liblas::Writer writer(ofs, header);
			liblas::Point pt(&header);

			for (int i = 0; i < pointCloud.points.size(); i++)
			{
				pt.SetCoordinates((double)pointCloud.points[i].x, (double)pointCloud.points[i].y,
								  (double)pointCloud.points[i].z);
				pt.SetIntensity(pointCloud.points[i].intensity);

				writer.WritePoint(pt);
			}
			ofs.flush();
			ofs.close();
		}
	}
};