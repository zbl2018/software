#ifndef UTILITY
#define UTILITY

#include <pcl/point_types.h>
#include <pcl/point_cloud.h>
#include <pcl/PolygonMesh.h>
#include <tbb/compat/ppl.h>
#include <tbb/concurrent_vector.h>
#include <iostream>
#include <limits>
#include <cstdint>

typedef  pcl::PointCloud<pcl::PointXYZI>::Ptr      pointCloudXYZIPtr;
typedef  pcl::PointCloud<pcl::PointXYZI>           pointCloudXYZI;

typedef  pcl::PointCloud<pcl::PointXYZ>::Ptr      pointCloudXYZPtr;
typedef  pcl::PointCloud<pcl::PointXYZ>           pointCloudXYZ;

typedef  pcl::PointCloud<pcl::PointXY>::Ptr      pointCloudXYPtr;
typedef  pcl::PointCloud<pcl::PointXY>           pointCloudXY;

typedef  pcl::PointCloud<pcl::PointXYZRGB>::Ptr      pointCloudXYZRGBPtr;
typedef  pcl::PointCloud<pcl::PointXYZRGB>           pointCloudXYZRGB;

typedef  pcl::PointCloud<pcl::PointXYZRGBA>::Ptr      pointCloudXYZRGBAPtr;
typedef  pcl::PointCloud<pcl::PointXYZRGBA>           pointCloudXYZRGBA;

typedef pcl::PointCloud<pcl::Normal>::Ptr NormalsPtr;
typedef pcl::PointCloud<pcl::Normal> Normals;

namespace utility
{
	struct pointCloudBound
	{
		double minx;
		double maxx;
		double miny;
		double maxy;
		double minz;
		double maxz;
		pointCloudBound()
		{
			minx = maxx = miny = maxy = minz = maxz = 0.0;
		}
	};

	struct pointCloudBound2d
	{
		double minx;
		double maxx;
		double miny;
		double maxy;
		pointCloudBound2d()
		{
			minx = maxx = miny = maxy= 0.0;
		}
	};


	template<typename PointCloudType>
	void getCloudBound(const PointCloudType & cloud, pointCloudBound & bound)
	{
		double min_x = DBL_MAX;
		double min_y = DBL_MAX;
		double min_z = DBL_MAX;
		double max_x = -DBL_MAX;
		double max_y = -DBL_MAX;
		double max_z = -DBL_MAX;

		for (size_t i = 0; i<cloud.size(); ++i)
		{
			//获取边界
			if (min_x>cloud.points[i].x)
				min_x = cloud.points[i].x;
			if (min_y > cloud.points[i].y)
				min_y = cloud.points[i].y;
			if (min_z > cloud.points[i].z)
				min_z = cloud.points[i].z;
			if (max_x < cloud.points[i].x)
				max_x = cloud.points[i].x;
			if (max_y < cloud.points[i].y)
				max_y = cloud.points[i].y;
			if (max_z < cloud.points[i].z)
				max_z = cloud.points[i].z;
		}
		bound.minx = min_x;
		bound.maxx = max_x;
		bound.miny = min_y;
		bound.maxy = max_y;
		bound.minz = min_z;
		bound.maxz = max_z;
	}


	struct IdSimilarity
	{
		size_t pcIndex;
		float similarity;
		IdSimilarity()
		{
			pcIndex = 1;
			similarity = 0.0f;
		}
	};

	/*配准相关变量;*/
	//点对;
	struct RegistrationPair
	{
		size_t src_id;
		size_t target_id;//关键点索引号;
		size_t target_index;//坐标系索引号;
		int hamming_distance;
		RegistrationPair() :src_id(0), target_id(0)
		{

		}

	};

	//存储旋转角度投票的格网*
	struct VoteVoxel
	{
		size_t points_num;
		size_t voto_voxel_index;
		size_t xrotation_index;
		size_t yrotation_index;
		size_t zrotation_index;
		std::vector<RegistrationPair> point_pairs;
		VoteVoxel() :points_num(0), voto_voxel_index(0)
		{

		}
	};


	struct  RotationAngleAndOffset
	{
		float roll;
		float pitch;
		float heading;
		float offset_x;
		float offset_y;
		float offset_z;
	};

	typedef  std::vector<RegistrationPair, Eigen::aligned_allocator<RegistrationPair>> VectorRegistrationPair;

	typedef  tbb::concurrent_vector<RegistrationPair, Eigen::aligned_allocator<RegistrationPair>> concurrencyVectorRegistrationPair;

	typedef  std::vector<VectorRegistrationPair, Eigen::aligned_allocator<VectorRegistrationPair>>  VectorVectorRegistrationPair;

	typedef  std::vector<concurrencyVectorRegistrationPair, Eigen::aligned_allocator<concurrencyVectorRegistrationPair>>  concurrencyVectorVectorRegistrationPair;


}

#endif