#ifndef PCA_H
#define PCA_H


#include <pcl/point_types.h>
#include <pcl/point_cloud.h>
#include <pcl/kdtree/kdtree_flann.h>
#include <pcl/segmentation/extract_clusters.h>
#include <vector>
#include <pcl/features/normal_3d_omp.h>
#include <pcl/point_types.h>
#include <pcl/point_cloud.h>
#include <pcl/kdtree/kdtree_flann.h>
#include <pcl/segmentation/extract_clusters.h>
#include <opencv2/opencv.hpp>
#include <tbb/concurrent_vector.h>
#include <tbb/compat/ppl.h>


using namespace  std;

class PrincipleComponentAnalysis
{

public:
	struct eigenValue
	{
		double lamada1;
		double lamada2;
		double lamada3;
	};

	struct eigenVector
	{
		Eigen::Vector3f principalDirection;
		Eigen::Vector3f middleDirection;
		Eigen::Vector3f normalDirection;
	};

	struct pcaFeature
	{
		eigenValue values;
		eigenVector vectors;
		double curvature;
		pcl::PointXYZI pt;
		size_t ptId;
		size_t ptNum;
	};

	/*计算法向量;*/
	bool  CalculateNormalVectorOpenMP(pcl::PointCloud<pcl::PointXYZI>::Ptr inputPointCloud,float radius,
									  pcl::PointCloud<pcl::Normal>::Ptr &normals);

	/*主成分分析;*/
	bool CalculatePcaFeaturesOfPointCloud(pcl::PointCloud<pcl::PointXYZI>::Ptr inputPointCloud, float radius,
										  std::vector<pcaFeature> &features);

	bool CalculatePcaFeature(pcl::PointCloud<pcl::PointXYZI>::Ptr inputPointCloud,std::vector<int> &search_indices, pcaFeature &feature);

protected:


private:

	void  CheckNormals(pcl::PointCloud<pcl::Normal>::Ptr &normals);//检查是否存在不合法的法向量值;
};

#endif
