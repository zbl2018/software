#ifndef DATAIO 
#define DATAIO

#include <string>
#include <string.h>

#include<pcl/point_cloud.h>
#include<pcl/point_types.h>

#include <vector>
#include <liblas/factory.hpp>

#include <boost/filesystem.hpp>
#include <boost/function.hpp>

#include <pcl/io/pcd_io.h>
class DataIo
{
public:
	//文件夹遍历;
	bool batchReadFileNamesInFolders(const std::string &folderName,//文件夹路径;
		const std::string & extension,//目标文件的扩展名;
		std::vector<std::string> &fileNames);//所有目标文件的路径+文件名+扩展名;

	bool batchReadFileNamesInFoldersAndSubFolders(const std::string &folderName,//文件夹路径;
		const std::string & extension,//目标文件的扩展名;
		std::vector<std::string> &fileNames);//所有目标文件的路径+文件名+扩展名;
	//Las文件读写;
	bool readLasFileHeader(const std::string &fileName, liblas::Header& header);

	bool readLasFile(const std::string &fileName, pcl::PointCloud<pcl::PointXYZI> &pointCloud);

	bool batchReadLasFile(const std::string &folderName,
		std::vector<pcl::PointCloud<pcl::PointXYZI>> &pointClouds,
		std::vector<std::string> &fileNames);

	bool writeLasFile(const std::string &fileName, pcl::PointCloud<pcl::PointXYZI> &pointCloud);

	bool writeLasFile(const std::string &fileName, pcl::PointCloud<pcl::PointXYZI> &pointCloud, liblas::Color lasColor);

	bool writeLasFile(const std::string &fileName, pcl::PointCloud<pcl::PointXYZRGB> &pointCloud);


	bool batchWriteLasFile(const std::string &folderName, const std::vector<std::string> &fileNames,
		                   std::vector<pcl::PointCloud<pcl::PointXYZI>> &pointClouds);

	bool batchWriteLasFile(const std::string &folderName, const std::vector<std::string> &fileNames,
		                   std::vector<pcl::PointCloud<pcl::PointXYZRGB>> &pointClouds);

	bool mergeLasFileHeaders(const std::vector<liblas::Header>& header, liblas::Header& mergeFileHeader);

	bool mergeLasFilesColoredByFile(const std::string &folderName);

	bool mergeLasFilesIntensity(const std::string &folderName);

	//Pcd文件读写;
//	bool readPcdFileHeader(const std::string &fileName, liblas::Header& header);

	bool readPcdFile(const std::string &fileName, pcl::PointCloud<pcl::PointXYZI> &pointCloud);

	bool batchReadPcdFile(const std::string &folderName,
						  std::vector<pcl::PointCloud<pcl::PointXYZI>> &pointClouds,
						  std::vector<std::string> &fileNames);

	bool writePcdFile(const std::string &fileName, pcl::PointCloud<pcl::PointXYZI> &pointCloud);

//	bool writePcdFile(const std::string &fileName, pcl::PointCloud<pcl::PointXYZI> &pointCloud, liblas::Color lasColor);

//	bool writePcdFile(const std::string &fileName, pcl::PointCloud<pcl::PointXYZRGB> &pointCloud);


	bool batchWritePcdFile(const std::string &folderName, const std::vector<std::string> &fileNames,
						   std::vector<pcl::PointCloud<pcl::PointXYZI>> &pointClouds);

//	bool batchWritePcdFile(const std::string &folderName, const std::vector<std::string> &fileNames,
//						   std::vector<pcl::PointCloud<pcl::PointXYZRGB>> &pointClouds);

//	bool mergePcdFileHeaders(const std::vector<liblas::Header>& header, liblas::Header& mergeFileHeader);
//
//	bool mergePcdFilesColoredByFile(const std::string &folderName);
//
//	bool mergePcdFilesIntensity(const std::string &folderName);

protected:

private:



};

#endif