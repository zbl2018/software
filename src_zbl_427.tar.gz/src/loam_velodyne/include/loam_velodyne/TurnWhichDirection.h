#ifndef _TURNWHICHDIRECTION_H
#define _TURNWHICHDIRECTION_H

// left = 1,
// right = 0;(右手系则反)

int SmallerThan90(const double & cur_heading, const double & obj_heading)
{
    if(cur_heading > obj_heading)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

int BiggerThan90(const double & cur_heading, const double & obj_heading)
{
    if(cur_heading > obj_heading)
    {
        return 0;
    }
    else
    {
        return 1;
    }
}

int CurHeadingIsPos(const double & cur_heading, const double & obj_heading)
{
    if(fabs(cur_heading - obj_heading) < 180)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

int CurHeadingIsNeg(const double & cur_heading, const double & obj_heading)
{
    if(fabs(cur_heading - obj_heading) < 180)
    {
        return 0;
    }
    else
    {
        return 1;
    }
}

int TheSameSign(const double & cur_heading, const double & obj_heading)
{
    if(cur_heading > obj_heading)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

int DifferentSign(const double & cur_heading, const double & obj_heading)
{
    if(fabs(cur_heading)<90 && fabs(obj_heading)<=90)
    {
        return SmallerThan90(cur_heading, obj_heading);
    }
    else if(fabs(cur_heading) > 90 && fabs(obj_heading) > 90)
    {
        return BiggerThan90(cur_heading, obj_heading);
    }
    else if(cur_heading > 0 && obj_heading < 0)
    {
        return CurHeadingIsPos(cur_heading, obj_heading);
    }
    else if(cur_heading < 0 && obj_heading > 0)
    {
        return CurHeadingIsNeg(cur_heading, obj_heading);
    }
}

int DetermineTurnDirection(const double & cur_heading, const double & obj_heading)
{
    double is_the_same_sign = cur_heading * obj_heading;
    if(is_the_same_sign >= 0)
    {
        return TheSameSign(cur_heading, obj_heading);
    }
    else
    {
        return DifferentSign(cur_heading, obj_heading);
    }
}

#endif