#ifndef OBSTACLEDETECT_H_
#define OBSTACLEDETECT_H_

#include <iostream>
#include "arc.h"

using namespace std;

#define CRASHDISTANCE 0.6

class ObstacleDetect
{
private:

	
	Point CrashPoint;

public:
	Arc a;
	bool LeftOrRight = 0;

public:
	
	void GetTargetPoint(const Point & t);
	bool GetCrashPoint(const Point & p);
	bool IsCrash();
	double ComputeDistanceBetween2Points(const Point & p1, const Point & p2);
	
};

#endif
