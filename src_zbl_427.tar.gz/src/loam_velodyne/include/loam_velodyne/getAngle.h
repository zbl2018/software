#if !defined(GETANGLE_H)
#define GETANGLE_H

#include <cmath>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include "GaussProjection.h"
#include <vector>
#include <string>
#include "common.h"
#include <ros/ros.h>
#include "std_msgs/String.h"
using namespace std;

#define PI 3.1415926535898

struct GPSPoint{
    double lat;
    double lon;

    double x;
    double y;
    double height;

    double GaussX;
    double GaussY;

    double LX=0;
    double LY=0;

    double heading; 

    int map_index;
    int is_finish_turn;

    int is_turn;
    int key;

    string cname;
    string sname;
};


/*struct GPSPoint{
    double lat;
    double lon;

    double x;
    double y;
    double height;
    double heading;

    int key;

    std::string cname;
    std::string sname;
};*/

double getAngle(double firMidPoint_x, double firMidPoint_y)
{
	static float a_theta = 0;
	static int n = 1;
	static float angle_previous = 0;
	double a;					//a:车辆前轮转角
	double delt_b;				//delt_b:车辆当前方向和预瞄方向的夹角  预瞄方向：车两后轮中心和预瞄点的连线
	const double L = 0.5;		//常量 L:车前后车轮轴距.暂定为2.5米
	double Lf;					//Lforward，后轮中心与预瞄点的距离
	const double delt_y = 0;		//常量 车前杠中点和两后轮中心的距离，y方向上
	double c;					//方向盘转角
	double kp = 1;				//转角增益
	double ki = 0;
	static double integration = 0;

	double error = 0;
	delt_b = atan(firMidPoint_x / (firMidPoint_y));
	Lf = sqrt((firMidPoint_x*firMidPoint_x) + (firMidPoint_y)*(firMidPoint_y));
	
	a = 180.0 / PI * atan(2 * L * sin(delt_b) / Lf);
	integration += ki * delt_b;
	a = a * kp + integration;
	/*a_theta = a*180.0*18.0 / PI;
	short changeangle;
	changeangle = a_theta;*/

	return a;
}


void WorldtoMap(GPSPoint org,double xIn,double yIn,double &xOut,double &yOut)
{
	double dx=0,dy=0,dstX=0,dstY=0;

	dx=xIn-org.GaussX;
	dy=yIn-org.GaussY;

	dstX=dx*cos(PI * org.heading / 180.0)-dy*sin(PI * org.heading / 180.0);
	dstY=dx*sin(PI * org.heading / 180.0)+dy*cos(PI * org.heading / 180.0);
	xOut=dstX;
	yOut=dstY;
}


int GPS_location(double mlat,double mlon,int last_index,vector<GPSPoint> map){//search the closed point
  double x_ = 0;
  double y_ = 0;
  double mindis = 1000;//min distance
  int index = -1;

  if(mlat != 0 && mlon != 0){
    //LocalGeographicCS ls;
    //ls.ll2xy(lat,lon,x_,y_);

    for(int i = last_index; i < map.size()-1; i++)
    {
      double tdis = 0;
      tdis = abs(length_two_points(mlat,mlon,map[i].x,map[i].y));
      if(tdis < 10) //judge the gps info is out of the map by shenrk
      {
        if(mindis > tdis)
        {
          mindis = tdis;
          index = i; 
        }
      }
    }
    
    if(index == -1){
	index = last_index;
	std::cout<<"无法找到最近点!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"<<std::endl;
    }

  }
  return index;
}

int return_Min_data(double x,double y,double& mindis , vector<GPSPoint> data){
    int index_data = 0;
    double mindis_data = 1000;
    for(int i = 0; i < data.size(); i++){
        double dis_d = length_two_points(x,y,data[i].x,data[i].y);
        if(mindis_data > dis_d){
            mindis_data = dis_d;
            index_data = i;
        }
    }
    mindis = mindis_data;
    return index_data;
}


int return_Min_data_2(double x,double y,vector<GPSPoint> data){
    int index_data = 0;
    double mindis_data = 10000000;
    for(int i = 0; i < data.size(); i++){
        double dis_d = length_two_points(x,y,data[i].x,data[i].y);
        if(mindis_data > dis_d){
            mindis_data = dis_d;
            index_data = i;
        }
    }
   // mindis = mindis_data;
    return index_data;
}


int Current_index_Return(double x,double y,vector<GPSPoint> data,int start_turn,int end_turn){
  int index_data = 0;
    double mindis_data = 10000000;
    for(int i = start_turn; i < end_turn; i++){
        double dis_d = length_two_points(x,y,data[i].x,data[i].y);
        if(mindis_data > dis_d){
            mindis_data = dis_d;
            index_data = i;
        }
    }
   // mindis = mindis_data;
    return index_data;
}

double Dynamic_Target(double x,double y,vector<GPSPoint> data){

  double mindis = 1000;
  int index_min = 0;
  double d_target = 0;

  for(int i=0;i<data.size();i++){
    double dis = length_two_points(x,y,data[i].x,data[i].y);
    if(mindis > dis){
      mindis = dis;
      index_min = i;
    }
  }

  if(mindis > 0.5){
    d_target = 1.0;
  }else if(mindis > 0.5 && mindis < 1.0){
    d_target = 0.5;
  }else if(mindis > 1.0){
    d_target = 0.2;
  }

}

void send_dynamic_path(const char* filename,std_msgs::String& datas){
  ifstream infile_feat(filename);
  GPSPoint gps;
  string lines;
  string tmp_s;
  string finals = "";

  while(!infile_feat.eof())
  {
    tmp_s.clear();
    getline(infile_feat,lines);
    
    finals.append(lines).append(";");
  }
  finals.append(" ");
  datas.data = finals;
}

void decode_dynamic_path(string source,vector<GPSPoint>& path){

  stringstream ss(source);
  string tmps;
  while(getline(ss, tmps, ';')){
    stringstream decode_s(tmps);
    GPSPoint gps;

    decode_s>>setprecision(12)>>gps.x>>gps.height>>gps.y>>gps.cname>>gps.sname>>gps.heading>>gps.key>>gps.is_turn;

    path.push_back(gps);
  }
  cout<<"path size: "<<path.size()<<endl;
}

void decodePath(string paths,vector<GPSPoint>& map){
  stringstream ss(paths);
  string tmp_s;

  while(getline(ss,tmp_s,';')){
    GPSPoint gps;
    stringstream final_s(tmp_s);

    final_s>>setprecision(12)>>gps.x>>gps.height>>gps.y>>gps.cname>>gps.sname>>gps.heading>>gps.key>>gps.is_turn;
    gps.GaussX = gps.x;
    gps.GaussY = gps.y;
    //gps.heading = gps.heading * 180.0 / 3.14159265;  
    gps.is_finish_turn = 0;  
    map.push_back(gps);
  }
  cout<<"the path size: "<<map.size()<<endl;
}

void encodePath(string& paths,vector<GPSPoint> map){
  string final_s("");
  string tmp_s("");
  string r("");
  //stringstream ss;
  for(int i = 0; i < map.size(); i++){

    tmp_s.clear();
    tmp_s = boost::lexical_cast<string>(map[i].x);
    r = tmp_s;

    tmp_s.clear();
    tmp_s = boost::lexical_cast<string>(map[i].y);
    r.append(" ").append(tmp_s);

    tmp_s.clear();
    tmp_s = boost::lexical_cast<string>(map[i].height);
    r.append(" ").append(tmp_s);

    tmp_s.clear();
    tmp_s = boost::lexical_cast<string>(map[i].cname);
    r.append(" ").append(tmp_s);

    tmp_s.clear();
    tmp_s = boost::lexical_cast<string>(map[i].sname);
    r.append(" ").append(tmp_s);

    tmp_s.clear();
    tmp_s = boost::lexical_cast<string>(map[i].heading);
    r.append(" ").append(tmp_s);

    tmp_s.clear();
    tmp_s = boost::lexical_cast<string>(map[i].key);
    r.append(" ").append(tmp_s);

    tmp_s.clear();
    tmp_s = boost::lexical_cast<string>(map[i].is_turn);
    r.append(" ").append(tmp_s);

    if(i == map.size()-1)
    {
      final_s.append(r);
    }else{
      final_s.append(r).append(";");
    }
  }
  paths = final_s;
  cout<<"encode path end and map size is "<<map.size()<<endl;
}

void smoothMap(vector<GPSPoint>& map){
  int turn_size = 0;

  vector<int> turns;

  for(int i=0;i<map.size();i++){
    if(map[i].is_turn == 1){
      turn_size++;
      turns.push_back(i);
      cout<<"turn index..."<<i<<" ";
    }
  }
  //turns.push_back(map.size()-1);
  cout<<"turns size: "<<turns.size()<<endl;

  for(int i=0;i<turns.size();i++){
    cout<<map[turns[i]].x<<" "<<map[turns[i]].y<<endl;
  }

  cout<<endl;

  int map_count = 0;

  for(int i=0;i<turns.size()-1;i++)
  {
    double a ,b ;
    double y2 = map[turns[i+1]].y , y1 = map[turns[i]].y;
    double x2 = map[turns[i+1]].x , x1 = map[turns[i]].x; 

    if(x1 == 0) x1 = 0.0001;
    if(y1 == 0) y1 = 0.0001;
    if(x2 == 0) x2 = 0.0001;
    if(y2 == 0) y2 = 0.0001;

    a = (double)(y2 - y1) / (double)(x1 * y2 - x2 * y1);
    b = (double)(x2 - x1) / (double)(y1 * x2 - y2 * x1);
    
    cout<<x1<<" "<<x2<<" "<<y1<<" "<<y2<<endl;
    cout<<(y1 * x2 - y2 * x1)<<" "<<endl;
    cout<<"smoothMap..."<<a<<" "<<b<<endl;

    for(int j=turns[i]; j<turns[i+1]; j++){
      //y = a*x + b;  
      double final_y,final_x;
      if(abs(a/b) > 1) 
      {
          final_y = map[j].y;
          final_x = (1 - b * final_y) / a;
      }
      else
      {
          final_x = map[j].x;
          final_y = (1 - a * final_x) / b;          
      }

      map[j].x = final_x;
      map[j].y = final_y;

      //cout<<setprecision(12)<<map[j].x<<" "<<map[j].y<<endl;
    }
  }
}

void smoothMap_tzb(vector<GPSPoint>& map){
  int turn_size = 0;

  vector<int> turns;

  for(int i=0;i<map.size();i++){
    if(map[i].is_turn == 1){
      turn_size++;
      turns.push_back(i);
      cout<<"turn index..."<<i<<" ";
    }
  }
  //turns.push_back(map.size()-1);
  cout<<"turns size: "<<turns.size()<<endl;

  for(int i=0;i<turns.size();i++){
    cout<<map[turns[i]].x<<" "<<map[turns[i]].y<<endl;
  }

  cout<<endl;

  int map_count = 0;

  for(int i=0;i<turns.size()-1;i++)
  {
    double a ,b ;
    double y2 = map[turns[i+1]].y , y1 = map[turns[i]].y;
    double x2 = map[turns[i+1]].x , x1 = map[turns[i]].x; 
    
    double k = (y2-y1)/(x2-x1+1E-16);
    double m = y2 - k*x2;
    double k_down = k + 1/k;

    for(int j=turns[i]; j<turns[i+1]; j++){
      
      double final_x = (map[j].y + 1/k * map[j].x - m)/k_down;
      double final_y = k * final_x + m;
      
      map[j].x = final_x;
      map[j].y = final_y; 
    }
  }
}

/*void readDataAll_Locals(const char* filename,vector<GPSPoint>& pcs){//read the map data to vector
  ifstream infile_feat(filename);
  string line_s;
  GPSPoint gps;
  LocalGeographicCS cs;

  while(infile_feat>>setprecision(12)>>gps.x>>gps.height>>gps.y>>gps.cname>>gps.sname>>gps.heading>>gps.key>>gps.is_turn)
  {
      gps.GaussX = gps.x;
      gps.GaussY = gps.y;
      gps.heading = gps.heading * 180.0 / 3.14159265;  
      gps.is_finish_turn = 0;  
      pcs.push_back(gps);     
  }
  infile_feat.close();
}*/
#endif
