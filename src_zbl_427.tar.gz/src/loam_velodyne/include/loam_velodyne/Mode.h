#ifndef MODE1_H
#define MODE1_H

#include <cmath>
#include <iostream>
using namespace std;

double Deal_angle(double object_angle,double current_angle)
{
	double speed;
	if(object_angle > 180)
	{
		object_angle = -(360.0 - object_angle);
	}
	if(current_angle > 180)
	{
		current_angle = -(360.0 - current_angle);
	}
	speed = (object_angle - current_angle) * M_PI / 180 * 0.1;
//cout << "speed1:" << speed << endl;
	if(speed > 0.3)
	{
		return 0.3;
	}
	else if(speed < -0.3)
	{
		return -0.3;
	}
	else
	{
		return speed;
	}
}

#endif
