/*
Smoothing Target Point 
Created by Louis Chen
Date: 2017-10-16
modified : 2017-10-27
*/

#ifndef _SMTATPOI_HPP
#define _SMTATPOI_HPP

#include "getAngle.h"
#include <boost/timer.hpp>
#include <fstream>
#include <cmath>
#include <vector>

using namespace std;
using namespace boost;

#define KP 2.5
ofstream rec_info("/home/chen/Project/catkin_sysu/src/loam_velodyne/output/SmoothingTargetPoints.csv");

class SmTarPoi
{
private:

    timer t;
    double DisBetweenLocAndPath = 0;
    double delta_DBLAP = 0;
    // double deltaT = 0;
    double pre_DBLAP = 0;
    double pre_speed = 0;
    int target_index = 0;
    vector<GPSPoint> AllMap;

public:

    double target_length = 1.0;
    void GetAllMap(const vector<GPSPoint> & allmap);
    int GetDataAndReturn(const GPSPoint & NowLoc, const int & cur_idx, int turn_idx, const double & spe);
    void TargetPointDynamic(const GPSPoint & NowLoc, const int & cur_idx, int turn_idx);
    void ComputeDBLAP(const GPSPoint & NowLoc, const int & cur_idx);
    void ComputeTargetLength(const double & spe);

};

void SmTarPoi::GetAllMap(const vector<GPSPoint> & allmap)
{
    AllMap.clear();
    AllMap = allmap;
    // cout << " got map ." << endl;
}

int SmTarPoi::GetDataAndReturn(const GPSPoint & NowLoc, const int & cur_idx, int turn_idx, const double & spe)
{

    ComputeDBLAP(NowLoc,cur_idx);
    ComputeTargetLength(spe);
    TargetPointDynamic(NowLoc, cur_idx, turn_idx);
    rec_info << ros::Time::now() << " " << spe << " " << DisBetweenLocAndPath << " " << delta_DBLAP << " " << target_index << " " << cur_idx << " " << target_length << " " << turn_idx << endl;
    return target_index;
    
}

void SmTarPoi::TargetPointDynamic(const GPSPoint & NowLoc, const int & cur_idx, int turn_idx)
{
    int cnt = 0;
    target_index = cur_idx;
    double t_dis = 0;
    double now2target_dis = 0;
    for(int j = cur_idx + 1; j < AllMap.size(); j++)//计算预瞄点
    {
      t_dis = length_two_points(AllMap[cur_idx].x,AllMap[cur_idx].y,AllMap[j].x,AllMap[j].y);
      now2target_dis = length_two_points(NowLoc.x, NowLoc.y, AllMap[j].x, AllMap[j].y);
      if(t_dis > target_length && now2target_dis > target_length)
      {
        target_index = j;//预描点的index
        break;
      }
      cnt++;
      
      if(length_two_points(AllMap[cur_idx].x, AllMap[cur_idx].y, AllMap[AllMap.size()-1].x, AllMap[AllMap.size()-1].y) <= target_length)
      {
            target_index = AllMap.size() - 1;
            break;
      }
    }
    if(target_index > turn_idx && turn_idx > 5)
    {
        target_index = turn_idx;
    }
    rec_info << cnt << " " << t_dis << " ";
}

void SmTarPoi::ComputeDBLAP(const GPSPoint & NowLoc, const int & cur_idx)
{
    double delta_x = NowLoc.x - AllMap[cur_idx].x;
    double delta_y = NowLoc.y - AllMap[cur_idx].y;
    DisBetweenLocAndPath = sqrt(delta_x * delta_x + delta_y * delta_y);
    delta_DBLAP = pre_DBLAP - DisBetweenLocAndPath;
    pre_DBLAP = DisBetweenLocAndPath;
}

// void SmTarPoi::ComputeTargetLength(const double & spe)
// {
//     if(delta_DBLAP < 0.3)
//     {
//         target_length += KP * (spe - pre_speed);
//         if(target_length < 1.0)
//         {
//             target_length = 1.0;
//         }
//     }
//     else
//     {
//         target_length = 0.8;
//     }
//     if(target_length > 2.8)
//     {
//         target_length = 2.8;
//     }
    
//     pre_speed = spe;
// }

void SmTarPoi::ComputeTargetLength(const double & spe)
{
    if(fabs(spe) <= 0.35)
    {
        target_length = 1.2;
    }
    else if(fabs(spe) <= 0.45)
    {
        target_length = 1.8;
    }
    else if(fabs(spe) <= 0.55)
    {
        target_length = 2.4;
    }
    else if(fabs(spe) <= 0.65)
    {
        target_length = 3.0;
    }
    else
    {
        target_length = 3.6;
    }
    pre_speed = spe;
}
#endif