#ifndef _ANGLEBETWEENLOCATIONANDPATH_H
#define _ANGLEBETWEENLOCATIONANDPATH_H

#include <cmath>
#include <vector>
#include <iostream>
#include <fstream>
#include "getAngle.h"

using namespace std;

ofstream ABLAP("/home/chen/Project/catkin_sysu/src/loam_velodyne/output/ABLAP.csv");

// const int Back2WhichPoint = 9;
const double Angle = 60.0;  // after endpoint 50 49 -- ; in front of endpoint ++ 57 58 59 

inline double Cac2PointsDistance(double x1, double y1, double x2, double y2)
{
    return sqrt((x2-x1)*(x2-x1) + (y2-y1)*(y2-y1));
}

int FindPointBehindTheEndPoint(const vector<GPSPoint> & path, int EndPoint, double len)
{
    int BackPoint = EndPoint;
    while(BackPoint > 0 && Cac2PointsDistance(path[BackPoint].x, path[BackPoint].y, path[EndPoint].x, path[EndPoint].y) < len)
    {
        BackPoint--;
    }
    return BackPoint;
}

int IsBeyondTheEndPoint(const vector<GPSPoint> & path, const GPSPoint & loc, int EndPoint)
{
    if(path.size() <= 1 || EndPoint == 0)
        return 1;
    if(EndPoint > path.size()-1)
        return 0;
    double ln2e = Cac2PointsDistance(path[EndPoint].x, path[EndPoint].y, loc.x, loc.y); // the length of now to end point
    int Back2WhichPoint = FindPointBehindTheEndPoint(path, EndPoint, ln2e);
    double lp = Cac2PointsDistance(path[EndPoint].x, path[EndPoint].y, path[Back2WhichPoint].x, path[Back2WhichPoint].y);
    double ln2eb9 = Cac2PointsDistance(path[Back2WhichPoint].x, path[Back2WhichPoint].y, loc.x, loc.y); // the length of now to end back 9th point;
    double phi = acos((lp*lp + ln2e*ln2e - ln2eb9*ln2eb9) / 2.0 / lp / ln2e) * 180.0 / M_PI;
    ABLAP << ln2e << " " << lp << " " << ln2eb9 << " " << phi << " " << Angle << " " << EndPoint << " " << Back2WhichPoint << endl;
    if(phi > Angle)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}



#endif
