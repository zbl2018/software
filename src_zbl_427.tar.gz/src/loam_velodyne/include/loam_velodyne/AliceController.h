#pragma once

#include <Eigen/Core>
#include <Eigen/QR>
#include <cmath>
#include <iostream>
#include <fstream>
#include <vector>
#include "PointsAugment.h"

std::ofstream AC("/home/chen/Project/catkin_sysu/src/loam_velodyne/output/alice.csv");
std::ofstream WP("/home/chen/Project/catkin_sysu/src/loam_velodyne/output/waypoint.csv");

class AliceController
{
private:
	const double WheelBase = 0.5;
	double LookAheadDistance;
	double steering;
	int ORDER;
	int NumOfFit;
	int NumOfPre;
	int BackIndex;
	int NowIndex;
	int last_end_index;
	int end_index;
	Eigen::VectorXd x_waypoints;
	Eigen::VectorXd y_waypoints;
	Eigen::VectorXd K;

	
	
public:
	AliceController()
	{
		ORDER = 3;
		NumOfFit = 12;
		NumOfPre = 3;
	}
	template<typename POSITIONTYPE>
	double sendMapAndLocation(const std::vector<POSITIONTYPE> & map, const POSITIONTYPE & location, double dis, int current_index);

private:

	template<typename POSITIONTYPE>
	double calcSteering(const std::vector<POSITIONTYPE> & map, const POSITIONTYPE & location);

	double transYaw(double yaw);

	template<typename POSITIONTYPE>
	int findTheNearestPointInMap(const std::vector<POSITIONTYPE> & map, const POSITIONTYPE & location, int start_turn);
	
	template<typename POSITIONTYPE>
	void findEndAndLastEndIndex(const std::vector<POSITIONTYPE> & map);

	void chooseBackPointIndex(int size_of_map, int now_index);
	
	template<typename POSITIONTYPE>
	void getWaypoints(const std::vector<POSITIONTYPE> & map, const POSITIONTYPE & location, double dis);
	
	template<typename POSITIONTYPE>
	void getRelativePoints(const Eigen::VectorXd & x, const Eigen::VectorXd y, const POSITIONTYPE & location);

	void fitPolynomial();

	double getTrackError();

	double getYawError();

	template<typename POSITIONTYPE>
	std::vector<POSITIONTYPE> augmentWaypoints(const std::vector<POSITIONTYPE> & map, const POSITIONTYPE & location, int num);

	template<typename POSITIONTYPE>
	inline double distanceOf2Points(const POSITIONTYPE & p1, const POSITIONTYPE & p2);
};

template<typename POSITIONTYPE>
double AliceController::sendMapAndLocation(const std::vector<POSITIONTYPE> & map, const POSITIONTYPE & location, double dis, int current_index)
{
	LookAheadDistance = dis;
	// NowIndex = findTheNearestPointInMap(map,location, start_turn);
	NowIndex = current_index;
	int size_of_map = map.size();
	AC << NowIndex << " " << size_of_map << " " << BackIndex << " " << " " << location.x << " " << location.y << " " << location.heading << " " << distanceOf2Points(map[NowIndex],location) << " ";
	getWaypoints(map,location,LookAheadDistance);
	fitPolynomial();
	AC << K[0] << " " << getYawError() << " ";
	return calcSteering(map,location);
}

template<typename POSITIONTYPE>
double AliceController::calcSteering(const std::vector<POSITIONTYPE> & map, const POSITIONTYPE & location)
{
	double cte = getTrackError();
	if(cte < 0)
	{
		cte = -distanceOf2Points(map[NowIndex],location);
	}
	else
	{
		cte = distanceOf2Points(map[NowIndex],location);
	}
	double epsi = (location.heading - map[NowIndex].heading) / 180.0 * M_PI;
	steering = atan((-cos(epsi) * -cte - (WheelBase + LookAheadDistance) * sin(epsi)) / (WheelBase - (WheelBase + LookAheadDistance) * cos(epsi) + sin(epsi) * -cte)) * 180.0 / M_PI;
	AC << epsi << " " << steering << std::endl;
	return steering;
}

double AliceController::transYaw(double yaw)
{
	yaw = -yaw;
	if(yaw >= M_PI / 2.0 && yaw <= M_PI)
	{
		yaw = 2.5 * M_PI - yaw;
	}
	else
	{
		yaw = -yaw + 0.5 * M_PI;
	}
	return yaw;
}

template<typename POSITIONTYPE>
int AliceController::findTheNearestPointInMap(const std::vector<POSITIONTYPE> & map, const POSITIONTYPE & location, int start_turn)
{
	//assert(map.size() > 0);
	int l = start_turn;
	int m = map.size() / 2;
	int r = map.size() - 1;

	double ll = distanceOf2Points(map[l], location) - distanceOf2Points(map[m], location);
	double lr = distanceOf2Points(map[r], location) - distanceOf2Points(map[m], location);
	while (l != m && r != m)
	{
		// std::cout << ll << " " << lr << " " << l << " " << m << " " << r << " " << distanceOf2Points(map[l], location) << " " << distanceOf2Points(map[m], location) << " " << distanceOf2Points(map[r], location) << std::endl;
		
		if (fabs(ll - lr) < 1e-2)
		{
			return m;
		}
		else if (ll < lr)
		{
			r = m;
			m = (m + l) / 2;
		}
		else
		{
			l = m;
			m = (m + r) / 2;
		}
		ll = distanceOf2Points(map[l], location) - distanceOf2Points(map[m], location);
		lr = distanceOf2Points(map[r], location) - distanceOf2Points(map[m], location);
	}
	return m;
}

template<typename POSITIONTYPE>
void AliceController::findEndAndLastEndIndex(const std::vector<POSITIONTYPE> & map)
{
	PointsAugment pa;
	pa.findEndIndexAndLastEndIndex(map,NowIndex);

	end_index = pa.end_index;
	last_end_index = pa.last_end_index;
}

void AliceController::chooseBackPointIndex(int size_of_map, int now_index)
{
	if (now_index - NumOfPre > 0 && now_index != last_end_index)
	{
		BackIndex = now_index - NumOfPre;
	}
	else
	{
		BackIndex = now_index;
	}
}

template<typename POSITIONTYPE>
void AliceController::getWaypoints(const std::vector<POSITIONTYPE> & map, const POSITIONTYPE & location, double dis)
{
	//assert(map.size() > NumOfFit);
	Eigen::VectorXd x(NumOfFit);
	Eigen::VectorXd y(NumOfFit);
	
	findEndAndLastEndIndex(map);
	int size_of_map = map.size();
	chooseBackPointIndex(size_of_map, NowIndex);
	int start_index = BackIndex;
	if (end_index - start_index > NumOfFit)
	{
		start_index += 1;
		for (int i = 0; i < NumOfFit; i++)
		{
			x[i] = -map[start_index + i].x;
			y[i] = map[start_index + i].y;
		}
		AC << last_end_index << " " << NowIndex << " " << end_index << " no a ";
	} 
	else
	{
		int RestNum = end_index - start_index;
		//assert(RestNum <= NumOfFit);
		//assert(RestNum >= 0);
		for (int i = 0; i < RestNum; i++)
		{
			
			x[i] = -map[start_index + i].x;
			y[i] = map[start_index + i].y;
			
		}
		std::vector<POSITIONTYPE> restPoints = augmentWaypoints(map, location, NumOfFit - RestNum);		

		for (int i = 0; i < NumOfFit - RestNum; i++)
		{
			x[RestNum+i] = -restPoints[i].x;
			y[RestNum+i] = restPoints[i].y;
		}
		
		AC << last_end_index << " " << NowIndex << " " << end_index << " yes a ";
	}
	
	getRelativePoints(x,y,location);
}

template<typename POSITIONTYPE>
std::vector<POSITIONTYPE> AliceController::augmentWaypoints(const std::vector<POSITIONTYPE> & map, const POSITIONTYPE & location, int num)
{
	
	PointsAugment pa;
	return pa.augmentWaypoints(map,location, NowIndex,num, LookAheadDistance);
}

template<typename POSITIONTYPE>
void AliceController::getRelativePoints(const Eigen::VectorXd & x, const Eigen::VectorXd y, const POSITIONTYPE & location)
{
	Eigen::VectorXd waypoints_xs(NumOfFit);
	Eigen::VectorXd waypoints_ys(NumOfFit);
	for (int i = 0; i < NumOfFit; i++)
	{
		double dx = x[i] - (-location.x);
		double dy = y[i] - location.y;
		double heading = -transYaw(location.heading / 180.0 * M_PI);
		waypoints_xs[i] = dx * cos(heading) - dy * sin(heading);
		waypoints_ys[i] = dy * cos(heading) + dx * sin(heading);
		WP << waypoints_xs[i] << " " << waypoints_ys[i] << " " << location.heading << " " << heading << std::endl;
	}
	WP << std::endl;
	x_waypoints = waypoints_xs;
	y_waypoints = waypoints_ys;
}

void AliceController::fitPolynomial()
{
	Eigen::MatrixXd A(x_waypoints.size(), ORDER + 1);
	for (int i = 0; i < x_waypoints.size(); ++i)
	{
		A(i, 0) = 1.0;
	}

	for (int j = 0; j < x_waypoints.size(); ++j)
	{
		for (int i = 0; i < ORDER; i++)
		{
			A(j, i + 1) = A(j, i) * x_waypoints(j);
		}
	}

	
	K = A.householderQr().solve(y_waypoints);
}

double AliceController::getTrackError()
{
	return K[0];
}

double AliceController::getYawError()
{
	return -atan(K[1]);
}

template<typename POSITIONTYPE>
inline double AliceController::distanceOf2Points(const POSITIONTYPE & p1, const POSITIONTYPE & p2)
{
	return sqrt(pow((p1.x - p2.x), 2) + pow((p1.y - p2.y), 2));
}
