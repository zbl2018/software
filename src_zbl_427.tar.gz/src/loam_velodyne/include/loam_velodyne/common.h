// Copyright 2013, Ji Zhang, Carnegie Mellon University
// Further contributions copyright (c) 2016, Southwest Research Institute
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice,
//    this list of conditions and the following disclaimer.
// 2. Redistributions in binary form must reproduce the above copyright notice,
//    this list of conditions and the following disclaimer in the documentation
//    and/or other materials provided with the distribution.
// 3. Neither the name of the copyright holder nor the names of its
//    contributors may be used to endorse or promote products derived from this
//    software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
// SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.
//
// This is an implementation of the algorithm described in the following paper:
//   J. Zhang and S. Singh. LOAM: Lidar Odometry and Mapping in Real-time.
//     Robotics: Science and Systems Conference (RSS). Berkeley, CA, July 2014.
#if !defined(COMMON_H)
#define COMMON_H

#include <cmath>
#include <stdio.h>
#include <string.h>
#include <iostream>
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <Eigen/Dense> 
#include <Eigen/Eigen> 
#include <Eigen/Core>
#include <boost/property_tree/ptree.hpp>
#include <boost/property_tree/ini_parser.hpp>

#define KP 0.15//控制比例，可修改
#define MAX_DELT_V 0.05//按100hz来算，大约需要3s多可以从1->0
#define MIN_V 0.005

typedef pcl::PointXYZI PointType;

typedef pcl::PointXYZ PointT;
typedef pcl::PointCloud<PointT> PointCloudT;

using namespace Eigen;

struct CarPara{
  int start_turn = 0;//搜索当前index的起始位置
  int end_turn = 0;//搜索当前index的结束位置

  int Search_start = 0; //初始搜索起始点
  int Search_end   = 5; //初始搜索结束点 

  std::string map_file_name = "";
  std::string draw_map = "";

  std::string servInetAddr;//ip

};


////////////////////////////////////////////////////////

double cmode,cangle,cspeed;
double cangle1,cangle2,cangle3,cangle4;
double ccur_m1,ccur_m2,ccur_m3,ccur_m4,cspeed_m1,cspeed_m2,cspeed_m3,cspeed_m4;
double cpul_m1,cpul_m2,cpul_m3,cpul_m4;
double cus1,cus2,cus3,cus4,cus5,cus6,cus7,cus8,cobstacle,cdis_keep;
double ccell[12];
double cmaxV,cminV,cmaxVP,cminVP,cVD,cAV,cTV,cCC,cDC,cSOC;
double cTem1,cTem2,cTem3,cTem4,cTem5,cTem6,cmaxTem,cminTem,cavrTem,cenvirTem;
double cRc,cWr;
//////////////////////////////////////////////////////
inline void DecodePara(const char* filename,CarPara& cp){
  boost::property_tree::ptree m_pt;
  boost::property_tree::ini_parser::read_ini(filename, m_pt);

  cp.start_turn = m_pt.get<int>("START_TURN", 0);
  cp.end_turn = m_pt.get<int>("END_TURN",0);
  cp.Search_start = m_pt.get<int>("SEARCH_START",0);
  cp.Search_end = m_pt.get<int>("SEARCH_END",0);
  cp.map_file_name = m_pt.get<std::string>("MAP_FILE_NAME","");
  cp.draw_map = m_pt.get<std::string>("DRAW_MAP","");
  cp.servInetAddr = m_pt.get<std::string>("IPADDRESS","");
}


inline double rad2deg(double radians)
{
  return radians * 180.0 / M_PI;
}

inline double deg2rad(double degrees)
{
  return degrees * M_PI / 180.0;
}

inline void mpointAssociateToMap(float pi[],float po[], float * transformTobeMapped)
{
  //z-Axie
  float x1 = cos(transformTobeMapped[2]) * pi[0]
           - sin(transformTobeMapped[2]) * pi[1];
  float y1 = sin(transformTobeMapped[2]) * pi[0]
           + cos(transformTobeMapped[2]) * pi[1];
  float z1 = pi[2];
  //x-Axie
  float x2 = x1;
  float y2 = cos(transformTobeMapped[0]) * y1 - sin(transformTobeMapped[0]) * z1;
  float z2 = sin(transformTobeMapped[0]) * y1 + cos(transformTobeMapped[0]) * z1;
  //Y-axie
  po[0] = cos(transformTobeMapped[1]) * x2 + sin(transformTobeMapped[1]) * z2
        + transformTobeMapped[3];

  po[1] = y2 + transformTobeMapped[4];
  po[2] = -sin(transformTobeMapped[1]) * x2 + cos(transformTobeMapped[1]) * z2
        + transformTobeMapped[5];
}

inline float vControl(float vInput,float vTarget,float dis)//vs: ve:dis
{
  
  float deltV;
	if(vInput>vTarget)//降速
	{
	  if(dis<=1.0)//1.0m进入调节模式
	  {
		deltV=KP*dis;
		if(deltV>MAX_DELT_V)
		{
		  deltV=MAX_DELT_V;
		}
		return vInput-deltV;
		if(vInput-deltV<MIN_V)
		{
		  if(dis>0.01)
		 	return MIN_V;		 
		  return 0;//停车		  
		}
	  }
	    return vInput;//没进入调节模式，则返回初始速度
	}
	  
	  
	else if(vInput<vTarget)//升速模式
	{
		if(vInput < 0.00001)
		{
			vInput = 0.1;
		}
	  if(vInput+MIN_V<vTarget)
		return vInput+MIN_V;
	  
	  else
	  	return vTarget;
	}
	return vTarget;
}

//lx ly 底图中的莫卡拓坐标 transformTobeMapped RT矩阵 heading 底图的heading角 wx wy 转换后的莫卡拓坐标
inline void TransLocaltoWorld(double lx,double ly,float* transformTobeMapped,double& heading,double& wx,double& wy){

  float RL_position[3];
  float RW_position[3];
  float final_position[3];
  float mka_pair[6];

  memset(RL_position,0,sizeof(RL_position));
  memset(RW_position,0,sizeof(RW_position));
  memset(final_position,0,sizeof(final_position));
  memset(mka_pair,0,sizeof(mka_pair));

  RL_position[0] = transformTobeMapped[3];//x
  RL_position[1] = transformTobeMapped[4];
  RL_position[2] = transformTobeMapped[5];

  mka_pair[0] = 0;
  mka_pair[1] = heading / 180.0 * 3.14159265;
  //mka_pair[1] = -heading;
  mka_pair[2] = 0;
  mka_pair[3] = 0;
  mka_pair[4] = 0;
  mka_pair[5] = 0;

  mpointAssociateToMap(RL_position,RW_position,mka_pair);
  std::cout <<" cout by zyc " <<  lx << " " << ly << " " << RW_position[0]<<" " << RW_position[2] << std::endl;
  final_position[0] = lx - RW_position[0]; // add by zyc。
  final_position[1] = ly - RW_position[2];

  wx = final_position[0];
  wy = final_position[1];

  heading = heading + transformTobeMapped[1];
}

inline void TransformPC(pcl::PointCloud<PointType>::Ptr origin, PointCloudT::Ptr target){
      target->points.resize(origin->points.size());
      for(int i = 0; i < origin->points.size(); i++){
            target->points[i].x = origin->points[i].x;
            target->points[i].y = origin->points[i].y;
            target->points[i].z = origin->points[i].z;
      }
      //cout<<origin->points.size()<<" "<<target->points.size()<<endl;
}



static inline double length_two_points(double x, double y, double xx,
        double yy) {
    double x_xx = x - xx;
    double y_yy = y - yy;

    return sqrt(x_xx * x_xx + y_yy * y_yy);
}

inline void TransLocaltoLocal(double lx,double ly,Eigen::Matrix4f transformTobeMapped,double& wx,double& wy){
    Eigen::Matrix3d Rm;
    Eigen::Vector3d Tm;

    for(int i=0;i<3;i++)
    {
      for(int j=0;j<3;j++)
      {
        Rm(i,j) = transformTobeMapped(i,j);
      }
    }

    Tm[0] = transformTobeMapped(0,3);
    Tm[1] = transformTobeMapped(1,3);
    Tm[2] = transformTobeMapped(2,3);

    Vector3d position_now(ly,0,lx);
    Vector3d position_next;

    position_next = Tm + position_now;
    
    wx = position_next[2];
    wy = position_next[0];
}

#endif
