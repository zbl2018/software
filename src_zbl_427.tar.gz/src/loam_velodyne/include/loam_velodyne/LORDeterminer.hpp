#ifndef _LORDETERMINER_HPP
#define _LORDETERMINER_HPP

#include <iostream>
#include <vector>
#include <cmath>
#include "arc.h"

using namespace std;

class LORDeterminer
{
private:

    Arc a;
    Point ThePointOfTarget = {0,0};
    Point TheCrashingPointOfArc = {0,0};
    vector<Point> ObstaclePoints;
    double RoadHeading = 0;
    double NowHeading = 0;
    int LeftCounter = 0;
    int RightCounter = 0;
    
public:

    void GetData(const Point & t, const double & rh, const double & nh, const vector<Point> & obstacles, int & LOR);
    void GetCrashingArcPoint();
    void CountTheLastObstacleAtLeftOrRight();
    void TransformAllPointsIntoRoadCoord();
    int PointsDirection(const double & obstacle_x);
    double ComputeDistanceBetween2Points(const Point & p1, const Point & p2);

};


void LORDeterminer::GetData(const Point & t, const double & rh, const double & nh, const vector<Point> & obstacles, int & LOR)
{

    a.GetTargetPoint(t);
    RoadHeading = rh;
    NowHeading = nh;
    ObstaclePoints = obstacles;

    GetCrashingArcPoint();
    CountTheLastObstacleAtLeftOrRight();
    
    if(LeftCounter > RightCounter)
    {
        LOR = 0;
    }
    else
    {
        LOR = 1;
    }

}


void LORDeterminer::CountTheLastObstacleAtLeftOrRight()
{
    double distance= 0;
    TransformAllPointsIntoRoadCoord();
    for(vector<Point>::iterator it=ObstaclePoints.begin(); it != ObstaclePoints.end(); it++)
	{
        distance = ComputeDistanceBetween2Points(*it,TheCrashingPointOfArc);
        if(distance < 1.0)
        {
            PointsDirection(it->x);
        }
	}
}

void LORDeterminer::GetCrashingArcPoint()
{
    double distance= 0;
    for(vector<Point>::iterator i=ObstaclePoints.begin(); i != ObstaclePoints.end(); i++)
	{
        for(vector<Point>::iterator j=a.TheSetOfPointsOnTheArc.begin(); j != a.TheSetOfPointsOnTheArc.end(); j++)
        {
            distance = ComputeDistanceBetween2Points(*i,*j);
            if(distance < 0.42)
            {
                TheCrashingPointOfArc = *j;
                return;
            }
        }
	}
}

void LORDeterminer::TransformAllPointsIntoRoadCoord()
{

    double delta_heading = RoadHeading - NowHeading;
    Point tempt_point = {0,0};

    for(vector<Point>::iterator it=ObstaclePoints.begin(); it != ObstaclePoints.end(); ++it)
    {
        tempt_point.x = it->x*cos(delta_heading) - it->y*sin(delta_heading);
        tempt_point.y = it->x*sin(delta_heading) + it->y*cos(delta_heading);
        it->x = tempt_point.x;
        it->y = tempt_point.y; 
    }

    tempt_point.x = ThePointOfTarget.x*cos(delta_heading) - ThePointOfTarget.y*sin(delta_heading);
    tempt_point.y = ThePointOfTarget.x*sin(delta_heading) + ThePointOfTarget.y*cos(delta_heading);
    ThePointOfTarget = tempt_point;

    tempt_point.x = TheCrashingPointOfArc.x*cos(delta_heading) - TheCrashingPointOfArc.y*sin(delta_heading);
    tempt_point.y = TheCrashingPointOfArc.x*sin(delta_heading) + TheCrashingPointOfArc.y*cos(delta_heading);
    TheCrashingPointOfArc = tempt_point;

}

int LORDeterminer::PointsDirection(const double & obstacle_x)// left==0    && right==1
{
    if(obstacle_x > ThePointOfTarget.x)
    {
        ++LeftCounter;
    }
    else
    {
        ++RightCounter;
    }
}


double LORDeterminer::ComputeDistanceBetween2Points(const Point & p1, const Point & p2)
{
    double DeltaX = (p1.x - p2.x) * (p1.x - p2.x);
	double DeltaY = (p1.y - p2.y) * (p1.y - p2.y);
	double distance = sqrt(DeltaX + DeltaY);
	return distance;
}


#endif