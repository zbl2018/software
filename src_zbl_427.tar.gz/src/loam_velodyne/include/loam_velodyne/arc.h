#ifndef ARC_H_
#define ARC_H_

#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

#define INTERVAL 20

struct Point
{
	double x;
	double y;
};

class Arc
{
private:

	Point target;
	double radius;
	double theta;
	double SmallTheta;

public:

	vector<Point> TheSetOfPointsOnTheArc;
	void GetTargetPoint(const Point & t);
	void Compute20Points();

};

#endif