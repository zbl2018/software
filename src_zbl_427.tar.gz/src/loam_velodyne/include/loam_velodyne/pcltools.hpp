//
// Created by dky on 17-8-23.
//

#ifndef RPC_PCLTOOLS_HPP
#define RPC_PCLTOOLS_HPP


/*
 *  Copyright (c) 2017, Tanzby
 *  All rights reserved.
*/
#include <chrono>
#include <vector>
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <boost/format.hpp>
#include <pcl/registration/icp.h>
#include <pcl/visualization/pcl_plotter.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <boost/thread/thread.hpp>
#include <iostream>
#include "trimmed_icp.hpp"



#define PI 3.14159265
#define timeCount(t2,t1) std::chrono::duration_cast<std::chrono::duration<double>>(t2-t1).count()

typedef std::chrono::steady_clock::time_point tp;

namespace PCLTOOL
{
    bool ShowErr = true;
    float velocity = 0.3;  // 0.3 m/s
    int WINDOW_RANGE = 80;
    float ACCURACY =  1e-10;
    float defaultParamForICP[]    = {0,0,0,0,0,velocity,32,2.8,3.2,2,-0.36f};
    float defaultParamForTRIICP[] = {0,0,0,0,0,velocity,62,0.999999999,3.2,2,-0.36f};
}

std::ofstream print_record( "Record.txt",ios::out );

float calculateRTBuf[6];

/**
 * @param[in] filePath The path of pcd file
 * @return read pcd data
 */
pcl::PointCloud<pcl::PointXYZ>::Ptr readPCDFile(const char * filePath)
{
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud (new pcl::PointCloud<pcl::PointXYZ>);
    if (pcl::io::loadPCDFile<pcl::PointXYZ> (filePath, *cloud) == -1)
    {
        if(PCLTOOL::ShowErr) PCL_ERROR ("Couldn't read file %s\n",filePath);
        throw -1;
    }
#ifdef PCLTOOLPRINTF
    std::cout << "Loaded " << cloud->size () << " data points from "<< filePath << std::endl;
#endif
    return cloud;
}


/**
 * @brief     show cloud image before and after register]
 * @param[in] target_cloud Cloud which is the target object
 * @param[in] input_cloud  Cloud which is needed to be transformed
 * @param[in] output_cloud Cloud which has registered
 * @param[in] savePcdName  The name of pcd file which combines target cloud and registered cloud
 */
void showPCDInfo(pcl::PointCloud<pcl::PointXYZ>::Ptr target_cloud,
                 pcl::PointCloud<pcl::PointXYZ>::Ptr input_cloud,
                 pcl::PointCloud<pcl::PointXYZ>::Ptr output_cloud,
                 const char* savePcdName = "register.pcd"
)
{
    // Saving transformed input cloud.
    pcl::io::savePCDFileASCII (savePcdName, *output_cloud);

    // Initializing point cloud visualizer
    boost::shared_ptr<pcl::visualization::PCLVisualizer>
            viewer_before(new pcl::visualization::PCLVisualizer ("before")),
            viewer_final (new pcl::visualization::PCLVisualizer ("Final"));

    viewer_final->setBackgroundColor (0, 0, 0);
    viewer_before->setBackgroundColor (0, 0, 0);

    // Coloring and visualizing target cloud (red).
    pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> target_color (target_cloud, 255, 0, 0);
    // Coloring and visualizing transformed input cloud (green).
    pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ>  output_color (output_cloud, 0, 255, 0);

    // viewer_before setting
    viewer_before->addPointCloud<pcl::PointXYZ> (target_cloud, target_color, "target cloud");
    viewer_before->addPointCloud<pcl::PointXYZ> (input_cloud, output_color, "input cloud");
    viewer_before->setPointCloudRenderingProperties (pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 1, "target cloud");
    viewer_before->setPointCloudRenderingProperties (pcl::visualization::PCL_VISUALIZER_POINT_SIZE,  1, "input cloud");
    viewer_before->addCoordinateSystem (1.0, "global");
    viewer_before->initCameraParameters ();
    // viewer_final setting
    viewer_final->addPointCloud<pcl::PointXYZ> (target_cloud, target_color, "target cloud");
    viewer_final->addPointCloud<pcl::PointXYZ> (output_cloud, output_color, "output cloud");
    viewer_final->setPointCloudRenderingProperties (pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 1, "target cloud");
    viewer_final->setPointCloudRenderingProperties (pcl::visualization::PCL_VISUALIZER_POINT_SIZE,  1, "output cloud");
    viewer_final->addCoordinateSystem (1.0, "global");
    viewer_final->initCameraParameters ();

    // Wait until visualizer window is closed.
    while (!viewer_final->wasStopped ())
    {
        viewer_final->spinOnce (100);
        viewer_before->spinOnce (100);
        boost::this_thread::sleep (boost::posix_time::microseconds (50));
    }
}

/**
 * @param[in] RTMatrix RT RTMatrix,which included 3*3 Rotation Matrix and 3*1 translation Matrix
 */
void print4x4Matrix (const Eigen::Matrix4d & RTMatrix)
{
    double phi = 0,theta,psi;
    if(fabs(RTMatrix(2,0)-1.0)>1E-9)
    {
        double theta1 = -asin(RTMatrix(2,0));
        double theta2 = PI - theta1;
        double psi1 = atan2(RTMatrix(2,1)/cos(theta1),RTMatrix(2,2)/cos(theta1));
        double psi2 = atan2(RTMatrix(2,1)/cos(theta2),RTMatrix(2,2)/cos(theta2));
        double phi1 = atan2(RTMatrix(1,0)/cos(theta1),RTMatrix(0,0)/cos(theta1));
        double phi2 = atan2(RTMatrix(1,0)/cos(theta2),RTMatrix(0,0)/cos(theta2));
        if(fabs(psi1)<1.74 && fabs(psi1)<1.74 && fabs(psi1)<1.74)
        {
            phi = phi1*180/PI;
            theta = theta1*180/PI;
            psi= psi1*180/PI;
        }
        else
        {
            phi = phi2*180/PI;
            theta = theta2*180/PI;
            psi= psi2*180/PI;
        }
    }
    else
    {
        if (fabs(RTMatrix(2,0)+1.0)<1E-9)
        {
            theta = 90;
            psi = (phi + atan2(RTMatrix(0,1),RTMatrix(0,2)))*180/PI;
        }
        else
        {
            theta = -90;
            psi = (-phi + atan2(-RTMatrix(0,1),-RTMatrix(0,2)))*180/PI;
        }
    }
    calculateRTBuf[0]=psi;
    calculateRTBuf[1]=theta;
    calculateRTBuf[2]=phi;
    calculateRTBuf[3]=RTMatrix (0, 3);
    calculateRTBuf[4]=RTMatrix (1, 3);
    calculateRTBuf[5]=RTMatrix (2, 3); // rx  ry  rz  tx  ty  tz

#ifdef PCLTOOLPRINTF
    printf ("RT Matrix :\n");
        printf (" | %6.3f %6.3f %6.3f %6.3f| \n", RTMatrix (0, 0), RTMatrix (0, 1), RTMatrix (0, 2),RTMatrix (0, 3));
        printf (" | %6.3f %6.3f %6.3f %6.3f| \n", RTMatrix (1, 0), RTMatrix (1, 1), RTMatrix (1, 2),RTMatrix (1, 3));
        printf (" | %6.3f %6.3f %6.3f %6.3f| \n", RTMatrix (2, 0), RTMatrix (2, 1), RTMatrix (2, 2),RTMatrix (2, 3));
        printf (" | %6.3f %6.3f %6.3f %6.3f| \n", RTMatrix (3, 0), RTMatrix (3, 1), RTMatrix (3, 2),RTMatrix (3, 3));
        printf ("RT of Eular:\n");
        printf("%6.4f %6.4f %6.4f %6.4f %6.4f %6.4f\n", psi, theta,phi,RTMatrix (0, 3),RTMatrix (1, 3),RTMatrix (2, 3)); // rx  ry  rz  tx  ty  tz

        printf ("Rotation    : %6.4f d\n",sqrt( psi*psi + theta*theta + phi*phi ));
        printf ("Displacement: %6.4f m\n",sqrt( RTMatrix (0, 3)*RTMatrix (0, 3)+ RTMatrix (1, 3)*RTMatrix (1, 3) + RTMatrix (2, 3)*RTMatrix (2, 3)));
#endif

#ifdef PCLTOOLRECORD

    char buf[64];
        sprintf(buf,"%6.4f %6.4f %6.4f %6.4f %6.4f %6.4f",psi,theta,phi,RTMatrix (0, 3), RTMatrix (1, 3), RTMatrix (2, 3));
        print_record << buf<<endl;
#endif
}

/**
 * For an input cloud data, points which is in the range of distance will be erased
 * @param input_cloud The cloud to be cooped
 * @param distance    the length of erace radius
 * @param eraseGround if ground points will be erased
 *        eraseGround = 1, x will be the condition
 *        eraseGround = 2, y
 *        eraseGround = 3, z
 * @param groundDeep the deep of laser to the ground
 */
void eraseNearPoint(pcl::PointCloud<pcl::PointXYZ>::Ptr input_cloud, const float & distance,int eraseGround = 3,float groundDeep = -0.6)
{
    size_t j = 0;
    for ( size_t i = 0; i < input_cloud->points.size(); ++i )
    {
        float dis2 = input_cloud->points[i].x * input_cloud->points[i].x +
                     input_cloud->points[i].y * input_cloud->points[i].y +
                     input_cloud->points[i].z * input_cloud->points[i].z;
        if ( dis2 < distance*distance + 1e-16
             || (eraseGround == 1 && input_cloud->points[i].x < groundDeep)
             || (eraseGround == 2 && input_cloud->points[i].y < groundDeep)
             || (eraseGround == 3 && input_cloud->points[i].z < groundDeep)
                )
        {
            continue;
        }
        input_cloud->points[j++] = input_cloud->points[i];
    }
    input_cloud->resize(j);
}
/**
 * For an input cloud data, points which is in the range of distance will be erased
 * @param pcdFilePath The path of cloud to be cooped
 * @param distance    the length of erace radius
 * @param eraseGround if ground points will be erased
 *        eraseGround = 1, x will be the condition
 *        eraseGround = 2, y
 *        eraseGround = 3, z
 * @param groundDeep the deep of laser to the ground
 */
void eraseNearPoint(const char *pcdFilePath, const float & distance, int eraseGround = 3,float groundDeep = -0.6)
{
    pcl::PointCloud<pcl::PointXYZ>::Ptr input_cloud(readPCDFile(pcdFilePath));
    eraseNearPoint(input_cloud,distance,eraseGround,groundDeep);
    std::cout << input_cloud->points.size()<<std::endl;
    pcl::io::savePCDFileASCII ("erased.pcd", *input_cloud);
}

/**
 * @brief put corner point cloud and surfur cloud into a cloud
 *        example:
 *                conbineCorSuf("/media/dky/hdd/Data/0.5-1.5/0.5/cor/%d.pcd",
 *                              "/media/dky/hdd/Data/0.5-1.5/0.5/suf/%d.pcd",
 *                              "/media/dky/hdd/Data/0.5-1.5/0.5/cmb/%d.pcd");
 * @param[in] filePathCor the read path of corner cloud
 * @param[in] filePathSur the read path of surfur cloud
 * @param[in] filePathCmb the save path of cloud which is combined
 */
void conbineCorSuf(const char* filePathCor,const char* filePathSur,const char* filePathCmb )
{
    PCLTOOL::ShowErr = false;
    boost::format	fmt  ( filePathCor );
    boost::format	fmt_ ( filePathSur );
    boost::format	fmt__( filePathCmb );

    for(int j = 0; j < 500; j++)
    {
        try
        {
            pcl::io::savePCDFileASCII( (fmt__%j).str(),
                                       ( *(readPCDFile( (fmt_%j).str().c_str()))+*(readPCDFile((fmt%j).str().c_str())))
            );
        }
        catch(...)
        {
            std::cout<<"end !\n";
            break;
        }
    }
}
/**
 * @brief convert [rx,ry,rz,tx,ty,tz] to RT Matrix
 */
Eigen::Matrix4f conver6param2RT(const float& rx,const float& ry,const float& rz,
                                const float& tx,const float& ty,const float& tz)
{
    float transform_pair[] = {rx,ry,rz,tx,ty,tz};
    Eigen::AngleAxisf rollAngle(transform_pair[2], Eigen::Vector3f::UnitZ());
    Eigen::AngleAxisf yawAngle(transform_pair[1], Eigen::Vector3f::UnitY());
    Eigen::AngleAxisf pitchAngle(transform_pair[0], Eigen::Vector3f::UnitX());
    Eigen::Quaternion<float> q = rollAngle * yawAngle * pitchAngle;
    Eigen::Matrix3f rotationMatrix = q.matrix();//rotation of point_cloud
    Eigen::Vector3f T(transform_pair[3],transform_pair[4],transform_pair[5]);
    Eigen::Vector3f x_now(0.5,0,0.5);
    Eigen::Vector3f x_next;
    x_next = rotationMatrix*x_now + T;
    //cout<<"next:"<<x_next[0]<<" "<<x_next[1]<<" "<<x_next[2]<<endl<<endl;
    Eigen::Matrix4f final_RT;
    for(int i=0;i<3;i++)
    {
        for(int j=0;j<3;j++)
        {
            final_RT(i,j) = rotationMatrix(i,j);
            final_RT(i,3) = transform_pair[i+3];
        }
    }
    final_RT(3,0) = 0;
    final_RT(3,1) = 0;
    final_RT(3,2) = 0;
    final_RT(3,3) = 1;
    return final_RT;
}

/**
 *@brief read target Cloud and input cloud,then ICP will be used to register input cloud to target cloud
 *@param[in] targetCloud  the point data which is the registering target
 *@param[in] inputCloud   the point data which is needed to transform and regeiter to targin cloud
 *@param[in] param        some setting od ICP algorithm and PointCloud coops.
 *                        param[0] to param[5] will be the values used for RT estimation
 *                        param[6] will be the number of maximum number of iterations
 *                        param[7] will be the maximum distance between a point and its correspondence
 *                        param[8] is the erasing range around the laser
 *                        param[9] represents the coordinates of the vertical direction, 1 for x, 2 for y, 3 for z
 *                        param[10] represents the length from laser machine to ground, which can erase the points in the ground
 *@param[out] RT          estimate RT result
 *@param[in]  showPcdGraph decide whether to show two images which are the of two point Cloud before and after
 *                        registering.
*/
void ICP(pcl::PointCloud<pcl::PointXYZ>::Ptr targetCloud,
         pcl::PointCloud<pcl::PointXYZ>::Ptr inputCloud,
         float param[],float RT[],bool showPcdGraph = true)
{
    for (int i = 0; i < 11; ++i)
        if (abs(param[i]-0)<1E-10)
            param[i] = PCLTOOL::defaultParamForICP[i];

    eraseNearPoint(targetCloud,param[8],int(param[9]),param[10]);
    eraseNearPoint(inputCloud,param[8],int(param[9]),param[10]);

    pcl::IterativeClosestPoint<pcl::PointXYZ, pcl::PointXYZ> icp;
    icp.setInputSource(inputCloud);
    icp.setInputTarget(targetCloud);
    icp.setMaximumIterations(int(param[6]));
    icp.setMaxCorrespondenceDistance(param[7]);
    icp.setTransformationEpsilon(PCLTOOL::ACCURACY);
    icp.setEuclideanFitnessEpsilon(PCLTOOL::ACCURACY);

    pcl::PointCloud<pcl::PointXYZ>::Ptr Final(new pcl::PointCloud<pcl::PointXYZ>);
#ifdef PCLTOOLPRINTF
    tp t1 = std::chrono::steady_clock::now();
#endif

    Eigen::Matrix4f g = conver6param2RT (param[0],param[1],param[2],param[3],param[4],param[5]);// rx,ry,rz,tx,ty,tz
    icp.align(*Final,g);
#ifdef PCLTOOLPRINTF
    tp t2 = std::chrono::steady_clock::now();
    std::cout <<"align Time :"<<timeCount(t2,t1)<<"s\n";
#endif

    print4x4Matrix(icp.getFinalTransformation ().cast<double>());
    RT[0]=calculateRTBuf[0];
    RT[1]=calculateRTBuf[1];
    RT[2]=calculateRTBuf[2];
    RT[3]=calculateRTBuf[3];
    RT[4]=calculateRTBuf[4];
    RT[5]=calculateRTBuf[5];
    if(showPcdGraph)
    {
        showPCDInfo(targetCloud,inputCloud,Final);
    }
}
/**
 *@brief read target Cloud and input cloud,then
 *       ICP will be used to register input cloud to target cloud
 *@param[in] targetCloudfilePath the path of point file which is the registering target
 *@param[in] inputCloudfilePath  the path of point file which is needed to transform and regeiter to targin cloud
 *@param[in] param               some setting od ICP algorithm and PointCloud coops.
 *                               param[0] to param[5] will be the values used for RT estimation
 *                               param[6] will be the number of maximum number of iterations
 *                               param[7] will be the maximum distance between a point and its correspondence
 *                               param[8] is the erasing range around the laser
 *                               param[9] represents the coordinates of the vertical direction, 1 for x, 2 for y, 3 for z
 *                               param[10] represents the length from laser machine to ground, which can erase the points in the ground
 *@param[out] RT                 estimate RT result
 *@param[in]  showPcdGraph       decide whether to show two images which are the of two point Cloud before and after
 *                               registering.
*/
void ICP(const char* targetCloudfilePath, const char* inputCloudfilePath,
         float param[],float RT[], bool showPcdGraph = true )
{
    // Loading first scan of room.
    pcl::PointCloud<pcl::PointXYZ>::Ptr target_cloud = readPCDFile(targetCloudfilePath),input_cloud = readPCDFile(inputCloudfilePath);
    ICP(target_cloud,input_cloud,param,RT,showPcdGraph);
}
/**
 *\brief  read target PointCloud and input PointCloudcloud data, then TrimmedICP will be used to register input PointCloud to target cloud
 *@param[in] targetCloud     the path of point file which is the registering target
 *@param[in] inputCloud      the path of point file which is needed to transform and regeiter to targin cloud
 *@param[in] param           some setting od ICP algorithm and PointCloud coops.
 *                           param[0] to param[5] will be the values used for RT estimation
 *                           param[6] will be the ratio of number of points which used in calculate RT, if this value = 1.0, auto-set-overlap
 *                                    will be on
 *                           param[7] will be the value for iteration ending condition, the larger param[2]
 *                                        the more accurate
 *                           param[8] is the erasing range around the laser
 *                           param[9] represents the coordinates of the vertical direction, 1 for x, 2 for y, 3 for z
 *                           param[10] represents the length from laser machine to ground, which can erase the points in the ground
 *@param[out] RT             estimate RT result
 *@param[in]  showPcdGraph   decide whether to show two images which are the of two point Cloud before and after
 *                               registering.
*/
void TRIICP(pcl::PointCloud<pcl::PointXYZ>::Ptr targetCloud,
            pcl::PointCloud<pcl::PointXYZ>::Ptr inputCloud,
            float param[],float RT[],bool showPcdGraph = true)
{
    for (int i = 0; i < 11; ++i)
        if (abs(param[i]-0)<1E-10)
            param[i] = PCLTOOL::defaultParamForTRIICP[i];

    eraseNearPoint(targetCloud,param[8],int(param[9]),param[10]);
    eraseNearPoint(inputCloud,param[8],int(param[9]),param[10]);
#ifdef PCLTOOLPRINTF
    tp t1 = std::chrono::steady_clock::now();
#endif

    pcl::recognition::TrimmedICP<pcl::PointXYZ,float>  triICP;
    triICP.init(targetCloud);
    triICP.setNewToOldEnergyRatio(param[7]);
    Eigen::Matrix4f RTMatrix= conver6param2RT (param[0],param[1],param[2],param[3],param[4],param[5]);// rx,ry,rz,tx,ty,tz
    triICP.align(*inputCloud,RTMatrix,param[6]);


#ifdef PCLTOOLPRINTF
    tp t2 = std::chrono::steady_clock::now();
    std::cout <<"align Time :"<<timeCount(t2,t1)<<"s\n";
#endif

    print4x4Matrix(RTMatrix.cast<double>());
    RT[0]=calculateRTBuf[0];
    RT[1]=calculateRTBuf[1];
    RT[2]=calculateRTBuf[2];
    RT[3]=calculateRTBuf[3];
    RT[4]=calculateRTBuf[4];
    RT[5]=calculateRTBuf[5];
    if(showPcdGraph)
    {
        pcl::PointCloud<pcl::PointXYZ>::Ptr Final(new pcl::PointCloud<pcl::PointXYZ>);
        pcl::transformPointCloud (*inputCloud, *Final, RTMatrix);
        showPCDInfo(targetCloud,inputCloud,Final);
    }
}

/**
 *\brief read target PointCloud and input PointCloudcloud data from files, then TrimmedICP will be used to register input PointCloud to target cloud
 *@param[in] targetCloudfilePath the path of point file which is the registering target
 *@param[in] inputCloudfilePath  the path of point file which is needed to transform and regeiter to targin cloud
 *@param[in] param               some setting od ICP algorithm and PointCloud coops.
 *                               param[0] to param[5] will be the values used for RT estimation
 *                               param[6] will be the ratio of number of points which used in calculate RT, if this value = 1.0, auto-set-overlap
 *                                        will be on
 *                               param[7] will be the value for iteration ending condition, the larger param[2]
 *                                        themore accurate
 *                               param[8] is the erasing range around the laser
 *                               param[9] represents the coordinates of the vertical direction, 1 for x, 2 for y, 3 for z
 *                               param[10] represents the length from laser machine to ground, which can erase the points in the ground
 *@param[out] RT                 estimate RT result
 *@param[in]  showPcdGraph       decide whether to show two images which are the of two point Cloud before and after
 *                               registering.
*/
void TRIICP(const char* targetCloudfilePath,
            const char* inputCloudfilePath,
            float param[],float RT[], bool showPcdGraph = true )
{
    // Loading first scan of room.
    pcl::PointCloud<pcl::PointXYZ>::Ptr target_cloud = readPCDFile(targetCloudfilePath),input_cloud = readPCDFile(inputCloudfilePath);
    TRIICP(target_cloud,input_cloud,param,RT,showPcdGraph);
}


/**
 * @brief accept a RT transform vector and a staring point coor, transform coor to a new coor' by RT
 * @param[in] TL        transform vector
 * @param[in] oriPoint  start point coor, also a output of a new point coor
 */
inline void transform(float TL[],float oriPoint[])
{
    TL[0] = TL[0]*PI/180+oriPoint[0];
    TL[1] = TL[1]*PI/180+oriPoint[1];
    TL[2] = TL[2]*PI/180+oriPoint[2];

    float x1 = cos(TL[2]) * TL[3] - sin(TL[2]) * TL[4];
    float y1 = sin(TL[2]) * TL[3] + cos(TL[2]) * TL[4];
    float z1 = TL[5];

    float x2 = x1;
    float y2 = cos(TL[0]) * y1 - sin(TL[0]) * z1;
    float z2 = sin(TL[0]) * y1 + cos(TL[0]) * z1;

    oriPoint[0] = TL[0];
    oriPoint[1] = TL[1];
    oriPoint[2] = TL[2];
    oriPoint[3] = cos(TL[1]) * x2 + sin(TL[1]) * z2 + oriPoint[3];
    oriPoint[4] = y2+oriPoint[4];
    oriPoint[5] = -sin(TL[1]) * x2 + cos(TL[1]) * z2 + oriPoint[5];
}

/**
 * @brief input a path of RT record txt file, including rx,ry,rz,tx,ty,tz and generate a path according to it
 * @param[in] pointCloudSetPath the input RT file path
 */
void drawPathByRecord(const char*pointCloudSetPath)
{
    boost:pcl::visualization::PCLPlotter* plt = new pcl::visualization::PCLPlotter("Path");
    plt->setYRange (-PCLTOOL::WINDOW_RANGE, PCLTOOL::WINDOW_RANGE);
    plt->setXRange (-PCLTOOL::WINDOW_RANGE,PCLTOOL::WINDOW_RANGE);
    plt->setWindowSize(PCLTOOL::WINDOW_RANGE*5,PCLTOOL::WINDOW_RANGE*5);
    plt->setShowLegend(1);


    std::ifstream f(pointCloudSetPath);
    std::vector<double> posX,posZ;
    std::string s;
    float A[6] = {0,0,0,0,0,0},TL[6];
    while(!plt->wasStopped())
    {
        if(getline(f,s))
        {
            std::stringstream ss;
            ss << s;
            for(int i = 0;i < 6; i++)
            {
                ss >> TL[i];
            }

            transform(TL,A);

            posX.push_back(A[3]); // save X values
            posZ.push_back(A[5]); // save Z values
            plt->clearPlots ();
            plt->addPlotData(posZ,posX,"keyPoint",vtkChart::POINTS);
            plt->addPlotData(posZ,posX,"keyPoint Line",vtkChart::LINE);
        }
        boost::this_thread::sleep (boost::posix_time::microseconds (50));
        plt->spinOnce (50);
    }
}

/**
 * @brief accept paths of key-Frames set path and input-Frames set path and read them, then first use key-to-key to
 * form a path of key frame, then register input pcd to key-Frames which is near that frame, also form a path of input-Frame
 * @param[i] keyframeCloudfilePath   path of key-Frame pcds
 * @param[i] inputframeCloudfilePath path of input-Frame pcds
 * @param[i] numOfkeyFrame           number of input pcd frames file
 * @param[i] numOfinputFrame         number of input pcd frames file
 * @param[i] isTriICPforKeytoInput   whether to ues TriICP for registering input-Frames to key-Frames
 * @param[i] isTriICPforKeytoKey     whether to ues TriICP for registering key-Frames to key-Frames
 */
void followDraw(const char *keyframeCloudfilePath,
                const char *inputframeCloudfilePath,
                int numOfkeyFrame = 190,
                int numOfinputFrame = 150,
                bool isTriICPforKeytoInput = true,
                bool isTriICPforKeytoKey = true)
{

    boost:pcl::visualization::PCLPlotter* plt = new pcl::visualization::PCLPlotter("ov and cal pos");
    plt->setYRange (-PCLTOOL::WINDOW_RANGE, PCLTOOL::WINDOW_RANGE);
    plt->setXRange (-PCLTOOL::WINDOW_RANGE,PCLTOOL::WINDOW_RANGE);
    plt->setWindowSize(PCLTOOL::WINDOW_RANGE*5,PCLTOOL::WINDOW_RANGE*5);
    plt->setShowLegend(1);
    boost::format fmtKey( keyframeCloudfilePath );
    boost::format fmtInp( inputframeCloudfilePath );
    std::vector<double> KposX,KposZ,IposX,IposZ;
    float A[6] = {0,0,0,0,0,0};
    float B[6] = {0,0,0,0,0,0};
    float TL_A[6],TL_B[6],HP_Last[6];

    int i = 0,j=0;
    bool noentry = false;
    std::vector<char> color_1(4);
    std::vector<char> color_2(4);
    color_1[0]=(char(255));
    color_1[1]=(char(0));
    color_1[2]=(char(0));
    color_1[3]=(char(255));
    color_2[0]=(char(0));
    color_2[1]=(char(0));
    color_2[2]=(char(255));
    color_2[3]=(char(255));

    int Shift = 0;
    while(!plt->wasStopped ())
    {
        if(!noentry)
        {
            try
            {
                if(i<numOfkeyFrame)
                {
                    if(isTriICPforKeytoKey)
                    {
                        TRIICP(  (fmtKey%i).str().c_str(),(fmtKey%(i+1)).str().c_str(),PCLTOOL::defaultParamForTRIICP,TL_A,0 );
                    }
                    else
                    {
                        ICP( (fmtKey%i).str().c_str(),(fmtKey%(i+1)).str().c_str(),PCLTOOL::defaultParamForICP,TL_A,0);
                    }

                    // backUp heading of postion for keyFrame in last time
                    HP_Last[0] =  A[0];
                    HP_Last[1] =  A[1];
                    HP_Last[2] =  A[2];
                    HP_Last[3] =  A[3];
                    HP_Last[4] =  A[4];
                    HP_Last[5] =  A[5];

                    // upDate heading and pos for keyFrame of now
                    transform(TL_A,A);

                    if(j<numOfinputFrame)
                    {
                        // calculate input ->keyframe
                        if(isTriICPforKeytoInput)
                        {
                            TRIICP( (fmtKey%i).str().c_str(),(fmtInp%(i+Shift)).str().c_str(),PCLTOOL::defaultParamForTRIICP,TL_B,0 );
                        }
                        else
                        {
                            ICP( (fmtKey%i).str().c_str(),(fmtInp%(i+Shift)).str().c_str(),PCLTOOL::defaultParamForICP,TL_B,0 );

                        }
                        printf("%d %d %3.5f %3.5f %3.5f %3.5f %3.5f %3.5f\n",i,i+Shift,TL_B[0],TL_B[1],TL_B[2],TL_B[3],TL_B[4],TL_B[5]);

                        if(TL_B[3]*TL_B[3]+TL_B[4]*TL_B[4]+TL_B[5]*TL_B[5] >2.0 &&  TL_B[0]*TL_B[0]+TL_B[1]*TL_B[1]+TL_B[2]*TL_B[2] < 10.0)
                        {
                            if(IposX.size() > 0)
                            {
                                IposX.pop_back();
                                IposZ.pop_back();
                                Shift-=1;
                            }
                        }


                        transform(TL_B,HP_Last);
                        IposX.push_back(HP_Last[3]); // save X values of input frame
                        IposZ.push_back(HP_Last[5]); // save Z values of input frame

                    }
                    plt->clearPlots ();

                    KposX.push_back(A[3]); // save X values of keyframe
                    KposZ.push_back(A[5]); // save Z values of keyframe
                    plt->addPlotData(KposZ,KposX,"keyPoint A",vtkChart::POINTS,color_1);
                    plt->addPlotData(IposZ,IposX,"keyPoint B",vtkChart::POINTS,color_2);
                    j++;

                }
                plt->spinOnce (50);

                i++;
            }
            catch(...)
            {
                noentry = true;
            }

        }
        else
        {
            plt->spinOnce (50);
            boost::this_thread::sleep (boost::posix_time::microseconds (50));
        }
    }
}

/**
 * @brief read a file incluing pos infos(x and y) and display all of them
 * @param path file path
 * @param posX thr
 * @param posY
 */
void drawPathWithXY(const char* path,int posX = 1, int posY = 2 )
{
    boost:pcl::visualization::PCLPlotter* plt = new pcl::visualization::PCLPlotter("draw pos");
    std::ifstream f(path);
    plt->setYRange (-PCLTOOL::WINDOW_RANGE, PCLTOOL::WINDOW_RANGE);
    plt->setXRange (-PCLTOOL::WINDOW_RANGE,PCLTOOL::WINDOW_RANGE);
    plt->setWindowSize(PCLTOOL::WINDOW_RANGE*5,PCLTOOL::WINDOW_RANGE*5);
    std::string s;
    double ans;
    std::vector<double> x,y;
    while(getline(f,s))
    {
        std::stringstream ss;
        ss << s;
        int i = 0;
        while(!ss.eof())
        {
            i++;
            ss >> ans;
            if(i == posX)
            {
                x.push_back(ans);
            }
            if(i == posY)
            {
                y.push_back(ans);
            }

        }
        plt->addPlotData(x,y,"path",vtkChart::POINTS);
        plt->spinOnce (50);
    }
    while(!plt->wasStopped ())
    {
        plt->spinOnce (50);
        boost::this_thread::sleep (boost::posix_time::microseconds (50));
    }
}
/**
 * @brief multiple paths graph draw and a path considered truly
 * @param filePaths paths of different pcd set
 * @param POSPath position infos recoed by gps or other deviced considered truly
 * @param fileNums  number of files in diifferent pcd set
 * @param isTriICP  set register method with different pcd set
 */
void drawPathsWithPCDGPS( const std::vector<std::string>& filePaths,
                          const char *POSPath,
                          const std::vector<int>  &fileNums,
                          const std::vector<bool> &isTriICPs)
{
    if(filePaths.size()!=fileNums.size())
    {
        std::cout << "number of filePaths is not equal to number of fileNums\n";
    }

    // make a new plotHandler
    boost:pcl::visualization::PCLPlotter* plt = new pcl::visualization::PCLPlotter("Path");
    plt->setYRange (-PCLTOOL::WINDOW_RANGE, PCLTOOL::WINDOW_RANGE);
    plt->setXRange (-PCLTOOL::WINDOW_RANGE,PCLTOOL::WINDOW_RANGE);
    plt->setWindowSize(PCLTOOL::WINDOW_RANGE*5,PCLTOOL::WINDOW_RANGE*5);
    plt->setShowLegend(1);

    // make a list of reading formats
    std::vector<boost::format>  fmt;
    // general color for
    std::vector<std::vector<char>> color;



    int PATHNUM = filePaths.size();

    bool noentry[PATHNUM] ={0};

    int allWork = 0,p = 0;

    for(int i=0;i<PATHNUM; i++)
    {
        allWork += fileNums[i];
        fmt.push_back(boost::format(filePaths[i]));
        std::vector<char> ansColor(4);
        ansColor[3] = char(160);
        ansColor[2] = char(rand()%255);
        ansColor[1] = char(rand()%255);
        ansColor[0] = char(rand()%255);
        color.push_back(ansColor);
    }


    std::vector<std::vector<double>> posX(PATHNUM+(POSPath?1:0)),posZ(PATHNUM+(POSPath?1:0));


    if(POSPath)
    {
        std::vector<char> ansColor(4);
        ansColor[3] = char(160);
        ansColor[2] = char(rand()%255);
        ansColor[1] = char(rand()%255);
        ansColor[0] = char(0);
        color.push_back(ansColor);
        std::ifstream keyPosRT(POSPath);
        float x,z;
        while(keyPosRT>>x>>z)
        {
            posX[PATHNUM].push_back(x);
            posZ[PATHNUM].push_back(z);
            plt->clearPlots();
            plt->addPlotData(posX[PATHNUM],posZ[PATHNUM],"GPS Points",vtkChart::POINTS,color[PATHNUM]);
            plt->spinOnce (10);
        }
        noentry[PATHNUM] = true;

    }



    tp t1 = std::chrono::steady_clock::now();
    const char *lable = "|/-\\";
    char bar[52]={0};
    while(!plt->wasStopped())
    {
        for(int i = 0; i <PATHNUM;  i++ )
        {
            if(noentry[i]) continue;
            int index = -1;
            float A[6] ={0},TL[6]={0};
            try
            {
                while (++index < fileNums[i])
                {
                    p++;
                    if (isTriICPs[i])
                    {
                        TRIICP((fmt[i] % index).str().c_str(), (fmt[i] % (index + 1)).str().c_str(), PCLTOOL::defaultParamForTRIICP, TL, 0);
                    } else {
                        ICP((fmt[i] % index).str().c_str(), (fmt[i] % (index + 1)).str().c_str(), PCLTOOL::defaultParamForICP, TL, 0);
                    }
                    // update heading and pos for keyFrame of now
                    transform(TL, A);
                    plt->clearPlots();
                    posX[i].push_back(A[3]); // save X values
                    posZ[i].push_back(A[5]); // save Z values
                    char buf[16];
                    sprintf(buf,"Path %d",i+1);
                    plt->addPlotData(posZ[i],posX[i],buf,vtkChart::POINTS,color[i]);
                    for(int j = 0; j < i; j++ )
                    {
                        sprintf(buf,"Path %d",j+1);
                        plt->addPlotData(posZ[j],posX[j],buf,vtkChart::POINTS,color[j]);
                    }
                    if(POSPath)plt->addPlotData(posX[PATHNUM],posZ[PATHNUM],"GPS Points",vtkChart::POINTS,color[PATHNUM]);
                    plt->spinOnce (50);

                    if(p <= fileNums[i])
                    {
                        printf(" [%-50s][%.2f%%][%c]\r", bar, p * 100.0/ fileNums[i], lable[p%4]);
                        for(int j = 0; j<= int(p*50/fileNums[i]) ; j++)
                        {
                            bar[j] = '#';
                        }
                        fflush(stdout);
                    }
                    if(p == fileNums[i])
                    {
                        p = 0;
                        memset(bar,0,sizeof(bar));
                        tp t2 = std::chrono::steady_clock::now();
                        printf("\n    done ! time: \n                  %.4lf s\n", timeCount(t2,t1));
                        t1 = std::chrono::steady_clock::now();
                    }

                }
                noentry[i] = true;
            }
            catch(...)
            {
                noentry[i] = true;
            }
        }
        plt->spinOnce (50);
        if(noentry) boost::this_thread::sleep (boost::posix_time::microseconds (50));

    }

}
/**
 * @brief multiple paths graph draw
 * @param filePaths paths of different pcd set
 * @param fileNums  number of files in diifferent pcd set
 * @param isTriICP  set register method with different pcd set
 */
void drawPathsWithPCD( const std::vector<std::string> &filePaths,
                       const std::vector<int>  &fileNums,
                       const std::vector<bool> &isTriICPs)
{
    drawPathsWithPCDGPS(filePaths,NULL,fileNums,isTriICPs);
}

/**
 * @brief  draw one path with pcd file
 * @param filePath  path of set of pcd files
 * @param fileNum   number of files in this pcd file set
 * @param isTriICP  set register method with different pcd set
 */
void drawPathsWithPCD(const std::string filePath,
                      const int fileNum,
                      const bool isTriICP)
{
    std::vector<std::string> filePaths; filePaths.push_back(filePath);
    std::vector<int>  fileNums; fileNums.push_back(fileNum);
    std::vector<bool> isTriICPs; isTriICPs.push_back(isTriICP);
    drawPathsWithPCD(filePaths,fileNums,isTriICPs);
}

int selecteKeyFrame(const char*filePath,
                    int fileNum,
                    const float gap = 0.8,
                    const float angle = 10,
                    bool isTriICP = false )
{
    boost:pcl::visualization::PCLPlotter* plt = new pcl::visualization::PCLPlotter("Selection Proccess");
    plt->setYRange (-PCLTOOL::WINDOW_RANGE, PCLTOOL::WINDOW_RANGE);
    plt->setXRange (-PCLTOOL::WINDOW_RANGE, PCLTOOL::WINDOW_RANGE);
    plt->setWindowSize(PCLTOOL::WINDOW_RANGE*5,PCLTOOL::WINDOW_RANGE*5);
    plt->setShowLegend(1);
    boost::format fmtKey( filePath );
    std::vector<double> Sel_posX,Sel_posZ,All_posX,All_posZ;

    std::ofstream keypointOUT("keypoint.txt");

    float A[6] = {0,0,0,0,0,0},TL[6];
    float dis = 0;
    int i = 0;
    int k = 0;
    bool noentry = false;
    std::vector<char> color_1(4);
    std::vector<char> color_2(4);
    color_1[0]=(char(255));
    color_1[1]=(char(0));
    color_1[2]=(char(0));
    color_1[3]=(char(255));
    color_2[0]=(char(0));
    color_2[1]=(char(0));
    color_2[2]=(char(255));
    color_2[3]=(char(255));

    int allWork = 0,p = 0;
    tp t1 = std::chrono::steady_clock::now();
    const char *lable = "|/-\\";
    char bar[52]={0};

    while(!plt->wasStopped ())
    {
        if(!noentry && i++ <  fileNum)
        {
            try
            {
                if(isTriICP)
                {
                    TRIICP(  (fmtKey%i).str().c_str(),(fmtKey%(i+1)).str().c_str(),PCLTOOL::defaultParamForTRIICP,TL,0 );
                }
                else
                {
                    ICP( (fmtKey%i).str().c_str(),(fmtKey%(i+1)).str().c_str(),PCLTOOL::defaultParamForICP,TL,0);
                }

                transform(TL,A);

                //plt->clearPlots ();
                float diffAngle =sqrt (TL[0]*TL[0]+TL[1]*TL[1]); //global heading accumulate

                dis +=  sqrt(TL[3]*TL[3]+TL[4]*TL[4]+TL[5]*TL[5]); // od accumulate



                if((k+1)*gap > dis && dis > k*gap )
                {
                    k ++; //  how many selected point Cloud
                    Sel_posX.push_back(A[3]);
                    Sel_posZ.push_back(A[5]);


                    //do record for selected key point
                    keypointOUT<<i<<" "<<A[0]<<" "<<A[1]<<" "<<A[2]<<" "<<A[3]<<" "<<A[4]<<" "<<A[5]<<std::endl;

                }
                if(p <= fileNum)
                {
                    printf(" [%-50s][%.2f%%][%c]\r", bar, p * 100.0/ fileNum, lable[p%4]);
                    for(int j = 0; j<= int(p*50/fileNum) ; j++)
                    {
                        bar[j] = '#';
                    }
                    fflush(stdout);
                    p++;
                }
                if(p == fileNum)
                {
                    p = 0;
                    memset(bar,0,sizeof(bar));
                    tp t2 = std::chrono::steady_clock::now();
                    printf("\n    done ! time: \n                  %.4lf s\n", timeCount(t2,t1));
                    t1 = std::chrono::steady_clock::now();
                }


                All_posX.push_back(A[3]); // save X values
                All_posZ.push_back(A[5]); // save Z values
                plt->clearPlots();
                if(All_posX.size() > 1) plt->addPlotData(All_posZ,All_posX,"Path",vtkChart::LINE,color_2);
                plt->addPlotData(Sel_posZ,Sel_posX,"Selected Points",vtkChart::POINTS,color_1);
                plt->spinOnce (50);
            }
            catch(...)
            {
                noentry = true;
            }
        }
        else
        {
            plt->spinOnce (50);
            boost::this_thread::sleep (boost::posix_time::microseconds (50));
        }
    }
}



//void demo(const char *keyPointRTRecord,
//          const char*keyCloudPath,
//          const int keyCloudNum,
//          const char*inputCloudPath,
//          const int inputCloudNum,
//          float gap = 0.8,bool isTriICP =false)
//{
//    boost:pcl::visualization::PCLPlotter* plt = new pcl::visualization::PCLPlotter("Selection Proccess");
//    plt->setYRange (-PCLTOOL::WINDOW_RANGE, PCLTOOL::WINDOW_RANGE);
//    plt->setXRange (-PCLTOOL::WINDOW_RANGE, PCLTOOL::WINDOW_RANGE);
//    plt->setWindowSize(PCLTOOL::WINDOW_RANGE*5,PCLTOOL::WINDOW_RANGE*5);
//    plt->setShowLegend(1);
//
//    boost::format fmtKey( keyCloudPath );
//    boost::format fmtInput(inputCloudPath );
//    std::vector<double> key_posX,key_posZ,input_posX,input_posZ,selCal_posX,selCal_posZ;
//
//
//
//    float A[6] = {0,0,0,0,0,0},B[6]={0,0,0,0,0,0},TL[6],LastPoint[6];
//    float Dis = 0;
//    float param1[11] = {0,0,0,0,0,0,0.98,0.999999};
//    float param2[11] = {0,0,0,0,0,0,100,1.2};
//    int i = 0;
//    int k = 0;
//    bool noentry = false;
//    std::vector<char> color_1(4),color_2(4),color_3(4);
//    color_1[0]=(char(255));
//    color_1[1]=(char(0));
//    color_1[2]=(char(0));
//    color_1[3]=(char(255));
//    color_2[0]=(char(0));
//    color_2[1]=(char(0));
//    color_2[2]=(char(255));
//    color_2[3]=(char(255));
//    color_3[0]=(char(0));
//    color_3[1]=(char(255));
//    color_3[2]=(char(0));
//    color_3[3]=(char(255));
//
//
//    std::ifstream keyPosRT(keyPointRTRecord);
//    std::ifstream keyPosLocation(keyCloudPath);
//    pcl::KdTreeFLANN<pcl::PointXY> kdtreeKeyPos;
//    std::vector<std::vector<float>> keyPointRTInfo;
//    std::vector<int> target_index (1);
//    std::vector<float> sqr_dist_to_target (1);
//    std::vector<float> v(6);
//    float RT[6];
//    int index;
//
//    // read position(x,y) of key frames, and build a kd tree for index
//    pcl::PointXY source_point;
//    pcl::PointCloud<pcl::PointXY>::Ptr keyframeposlist;
//    while(keyPosLocation >> source_point.x >>source_point.y)
//    {
//        keyframeposlist->points.push_back(source_point);
//    }
//    kdtreeKeyPos.setInputCloud (keyframeposlist);
//
//    // read RT of key frames
//    while(keyPosRT>>index>>RT[0]>>RT[1]>>RT[2]>>RT[3]>>RT[4]>>RT[5])
//    {
//        for(int i = 0; i < 6 ;i ++) v[i]=RT[i];
//        keyPointRTInfo.push_back(v);
//    }
//
//    while(!plt->wasStopped())
//    {
//        if(!noentry && i++ <  inputCloudNum)
//        {
//            try
//            {
//                tp t1 = std::chrono::steady_clock::now();
//                // find the nearest point
//                source_point.x = 0;
//                source_point.y = 0;
//                kdtreeKeyPos.nearestKSearch, source_point, 1, target_index, sqr_dist_to_target);
//
//                // draw the keypoint
//                key_posX.push_back(keyPointRTInfo[target_index[0]][3]);
//                key_posZ.push_back(keyPointRTInfo[target_index[0]][5]);
//                plt->addPlotData(key_posZ,key_posX,"Selected Points",vtkChart::POINTS,color_1);
//
//
//                // calculate the RT betwwen key point and input point
//
//
//                if(isTriICP)
//                {
//                    TRIICP( (fmtKey%target_index[0]).str().c_str(),(fmtInput%(i+1)).str().c_str(),PCLTOOL::defaultParamForTRIICP,TL,0 );
//                }
//                else
//                {
//                    ICP( (fmtKey%target_index[0]).str().c_str(),(fmtInput%(i+1)).str().c_str(),PCLTOOL::defaultParamForICP,TL,0);
//                }
//                tp t2 = std::chrono::steady_clock::now();
//
//                // record the time of finding the keypoint and calculating distence between its and input point
//                float calculateTime = timeCount(t2,t1);
//
//                for(int k=0; k < 6; k++)
//                {
//                    LastPoint[k] = A[k];
//                }
//
//                transform(TL,A);
//
//                plt->addPlotData(selCal_posZ,selCal_posX,"keymap vo path",vtkChart::LINE,color_2);
//
//                // calculate the effect of calculating RT
//
//                //calculate the RT with self .pcd
//                if(isTriICP)
//                {
//                    TRIICP( (fmtInput%index).str().c_str(),(fmtInput%(i+1)).str().c_str(),param1,TL,0 );
//                }
//                else
//                {
//                    ICP( (fmtInput%index).str().c_str(),(fmtInput%(i+1)).str().c_str(),param2,TL,0);
//                }
//                transform(TL,B);
//
//                selCal_posX.push_back(B[3]);
//                selCal_posZ.push_back(B[5]);
//                plt->addPlotData(selCal_posZ,selCal_posX,"Sel vo path",vtkChart::LINE,color_3);
//
//                // RT 调整
//
//                // 定位需定位点的位置
//
//
//                plt->spinOnce (50);
//            }
//            catch(...)
//            {
//                noentry = true;
//            }
//        }
//        else
//        {
//            plt->spinOnce (50);
//            boost::this_thread::sleep (boost::posix_time::microseconds (50));
//        }
//
//    }
//
//}



#endif //RPC_PCLTOOLS_HPP
