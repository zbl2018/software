/*
Modify Target Point 
Created by Louis Chen
Date: 2017-10-27
*/

#ifndef _MODIFYTARGETPOINT_HPP
#define _MODIFYTARGETPOINT_HPP

#include "getAngle.h"
#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
using namespace std;

ofstream MTP("/home/chen/Project/catkin_sysu/src/loam_velodyne/output/MTP.csv");

class ModifyTargetPoint
{
private:

    double k=0;
    double b=0;
    bool plus_or_minus=0;
    double DIStance = 1.0;

public:

    GPSPoint ModifiedTargetPoint(const GPSPoint & NowLoc, int EndPoint, const vector<GPSPoint> & allmap, const GPSPoint & targetPoint, double dis);
    GPSPoint GetPointFrom2mOutside(const GPSPoint & p1, const GPSPoint & p2, const GPSPoint & now);
    void x_axis(double & x, double & y, const GPSPoint & p, const GPSPoint & now);
    void have_slope_neg(double & x, double & y, const GPSPoint & p2, const GPSPoint & now);
    void have_slope_pos_90(double & x, double & y, const GPSPoint & p2, const GPSPoint & now);
    void have_slope_pos_180(double & x, double & y, const GPSPoint & p2, const GPSPoint & now);
    bool compute_plus_or_minus(const vector<GPSPoint> & allmap, int end);
    int find_last_EndPoint(const vector<GPSPoint> & allmap, int EndPoint);
    inline double compute_and_get_x(const GPSPoint & p2, double D);
    inline double Compute2PointDistance(const double & x1,const double & y1, const double & x2, const double & y2);
};

GPSPoint ModifyTargetPoint::ModifiedTargetPoint(const GPSPoint & NowLoc, int EndPoint, const vector<GPSPoint> & allmap, const GPSPoint & targetPoint, double dis)
{
    MTP << ros::Time::now() << " ";
    int last_end_point = find_last_EndPoint(allmap, EndPoint);
    DIStance = dis;
    if(Compute2PointDistance(NowLoc.x,NowLoc.y, allmap[EndPoint].x, allmap[EndPoint].y) < DIStance && EndPoint != 0)
    {
        plus_or_minus = compute_plus_or_minus(allmap, EndPoint);
        GPSPoint p = allmap[EndPoint];
        p.heading = allmap[last_end_point].heading;
        MTP << last_end_point << " " << EndPoint << " " << DIStance << " " << p.heading << " " << allmap[EndPoint].heading << " " << NowLoc.heading << " ";
        return GetPointFrom2mOutside(allmap[last_end_point], p, NowLoc);
    }
    else
    {
    	MTP << endl;
        return targetPoint;
    }
}

GPSPoint ModifyTargetPoint::GetPointFrom2mOutside(const GPSPoint & p1, const GPSPoint & p2, const GPSPoint & now)
{
    double x = 0;
    double y = 0;
    if(fabs(p2.heading) < 1e-1 || fabs(fabs(p2.heading)-180) < 1e-1)
    {
        if(p2.y < p1.y)
        {
            plus_or_minus = 1;
        }
        x_axis(x, y, p2, now);
        MTP << 1 << " ";
    }
    else if(p2.heading < 0 && p2.heading > -180)
    {
        have_slope_neg(x, y, p2, now);
        MTP << 2 << " ";
    }
    else if(p2.heading > 0 && p2.heading <= 90)
    {
        have_slope_pos_90(x, y, p2, now);
        MTP << 3 << " ";
    }
    else if(p2.heading > 90 && p2.heading < 180)
    {
        have_slope_pos_180(x, y, p2, now);
        MTP << 4 << " ";
    }
    MTP << x << " " << y << " " << now.x << " " << now.y << endl;
    plus_or_minus = 0;
    GPSPoint t;
    t.x = x;
    t.y = y;
    t.GaussX = x;
    t.GaussY = y;
    return t;
}

void ModifyTargetPoint::x_axis(double & x, double & y, const GPSPoint & p, const GPSPoint & now)
{
    x = p.x;
    y = p.y;
    while(Compute2PointDistance(now.x,now.y,x,y) < DIStance)
    {
        if(plus_or_minus == 0)
        {
            y += 1;
        }
        else
        {
            y -= 1;
        }
    }
}

void ModifyTargetPoint::have_slope_neg(double & x, double & y, const GPSPoint & p2, const GPSPoint & now)
{
    k = tan((fabs(p2.heading)+90) * M_PI / 180.0);
    b = p2.y - k * p2.x;
    x = compute_and_get_x(now, DIStance);
    y = k * x + b;
}

void ModifyTargetPoint::have_slope_pos_90(double & x, double & y, const GPSPoint & p2, const GPSPoint & now)
{
    k = tan((90 - p2.heading) * M_PI / 180.0);
    b = p2.y - k * p2.x;
    x = compute_and_get_x(now, DIStance);
    y = k * x + b; 
}

void ModifyTargetPoint::have_slope_pos_180(double & x, double & y, const GPSPoint & p2, const GPSPoint & now)
{
    k = tan((450 - p2.heading) * M_PI / 180.0);
    b = p2.y - k * p2.x;
    x = compute_and_get_x(now, DIStance);
    y = k * x + b;
}

int ModifyTargetPoint::find_last_EndPoint(const vector<GPSPoint> & allmap, int EndPoint)
{
    if(EndPoint == 0)
    {
        return EndPoint;
    }
    else
    {
        int last = EndPoint - 1;
        while(last > 0 && allmap[last].is_turn != 0)
        {
            last--;
        }
        return last;
    }
}

bool ModifyTargetPoint::compute_plus_or_minus(const vector<GPSPoint> & allmap, int end)
{
    if(allmap[end].heading >= 0 && allmap[end].heading <= 180)
    {
        return false;
    }
    else if(allmap[end].heading < 0 && allmap[end].heading >= -180)
    {
        return true;
    }
}

inline double ModifyTargetPoint::Compute2PointDistance(const double & x1,const double & y1, const double & x2, const double & y2)
{
    return sqrt((x2-x1)*(x2-x1) + (y2-y1)*(y2-y1));
}

inline double ModifyTargetPoint::compute_and_get_x(const GPSPoint & n, double D)
{
    double A = 1 + k * k;
    double B = 2 * ((b - n.y) * k - n.x);
    double C = n.x * n.x + (b - n.y) * (b - n.y) - (D + 1e-1) * (D + 1e-1);
    double x1 = (-B + sqrt(B * B - 4 * A * C)) / 2.0 / A;
    double x2 = (-B - sqrt(B * B - 4 * A * C)) / 2.0 / A;
    return !plus_or_minus? x1: x2;
}

#endif