#pragma once

#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>

std::ofstream PA("/home/chen/Project/catkin_sysu/src/loam_velodyne/output/points.csv");

class PointsAugment
{
private:

	double k;
	double b;
	double now_loc_x;
	double now_loc_y;
	double DISTANCE;
	int NUMOFPOINTS;
	bool plus_or_minus = false;

public:

	int end_index;
	int last_end_index;

public:

	template<typename POSITIONTYPE>
	std::vector<POSITIONTYPE> augmentWaypoints(const std::vector<POSITIONTYPE> & map, const POSITIONTYPE & location, int now_index, int num, double dis);

	template<typename POSITIONTYPE>
	void findEndIndexAndLastEndIndex(const std::vector<POSITIONTYPE> & map, int now_index);

	template<typename POSITIONTYPE>
	std::vector<POSITIONTYPE> calcPoints(const POSITIONTYPE & last_end, const POSITIONTYPE & end);

	template<typename POSITIONTYPE>
	POSITIONTYPE calcOnePoint(const POSITIONTYPE & last_end, const POSITIONTYPE & end, double D);

	template<typename POSITIONTYPE>
	void xAxis(const POSITIONTYPE & p, POSITIONTYPE & a, double D);

	template<typename POSITIONTYPE>
	void hasSlopeNegtive(const POSITIONTYPE & p, POSITIONTYPE & a, double D);

	template<typename POSITIONTYPE>
	void hasSlopePos90(const POSITIONTYPE & p, POSITIONTYPE & a, double D);

	template<typename POSITIONTYPE>
	void hasSlopePos180(const POSITIONTYPE & p, POSITIONTYPE & a, double D);

	inline double calcAndGetX(double D, double x);

	template<typename POSITIONTYPE>
	inline double calc2PointsDistance(const POSITIONTYPE & p1, const POSITIONTYPE & p2);

	inline double keepInAbsPI(double heading);

	template<typename POSITIONTYPE>
	inline double computePlusOrMinus(const POSITIONTYPE & EndPoint);

	inline double toRad(double heading);

};

template<typename POSITIONTYPE>
std::vector<POSITIONTYPE> PointsAugment::augmentWaypoints(const std::vector<POSITIONTYPE> & map, const POSITIONTYPE & location, int now_index, int num, double dis)
{
	NUMOFPOINTS = num;
	DISTANCE = dis;
	now_loc_x = location.x;
	now_loc_y = location.y;
	findEndIndexAndLastEndIndex(map, now_index);
	POSITIONTYPE last_point = map[end_index];
	last_point.heading = keepInAbsPI(toRad(map[last_end_index].heading));
	PA << last_point.heading << " " << map[last_end_index].heading << " " << toRad(map[last_end_index].heading) << std::endl;
	plus_or_minus = computePlusOrMinus(last_point);
	PA << NUMOFPOINTS << " " << DISTANCE << " " << end_index << " " << last_end_index << " " << now_index << std::endl;
	return calcPoints(map[last_end_index], last_point);
}

template<typename POSITIONTYPE>
void PointsAugment::findEndIndexAndLastEndIndex(const std::vector<POSITIONTYPE> & map, int now_index)
{
	if (now_index == 0)
	{
		last_end_index = now_index;
	}
	else
	{
		last_end_index = now_index;
		while (last_end_index > 0 && map[last_end_index].is_turn == 0)
		{
			last_end_index--;
		}
	}
	if (now_index == map.size() - 1)
	{
		end_index = now_index;
	}
	else
	{
		end_index = now_index + 1;
		while (end_index < map.size() - 1 && map[end_index].is_turn == 0)
		{
			end_index++;
		}
	}
}

template<typename POSITIONTYPE>
std::vector<POSITIONTYPE> PointsAugment::calcPoints(const POSITIONTYPE & last_end, const POSITIONTYPE & end)
{
	std::vector<POSITIONTYPE> am_waypoints;
	double dd = DISTANCE / (double)NUMOFPOINTS;
	for (int i = 0; i < NUMOFPOINTS; i++)
	{
		PA << i << " " << dd * i << " ";
		am_waypoints.push_back(calcOnePoint(last_end, end, dd*(i+1)));
	}
	return am_waypoints;
}

template<typename POSITIONTYPE>
POSITIONTYPE PointsAugment::calcOnePoint(const POSITIONTYPE & last_end, const POSITIONTYPE & end, double D)
{
	POSITIONTYPE a_point;
	double h = end.heading;
	PA << end.heading << " ";
	if (fabs(h) < 1e-2 || fabs(fabs(h) - M_PI) < 1e-2)
	{
		if (end.y < last_end.y)
		{
			plus_or_minus = true;
		}
		PA << 1 << " ";
		xAxis(end, a_point, D);
	}
	else if(h < 0 && h > -M_PI)
	{
		PA << 2 << " ";
		hasSlopeNegtive(end, a_point, D);
	}
	else if (h > 0 && h <= M_PI/2.0)
	{
		PA << 3 << " ";
		hasSlopePos90(end, a_point, D);
	}
	else if (h > M_PI/2.0 && h < M_PI)
	{
		PA << 4 << " ";
		hasSlopePos180(end, a_point, D);
	}
	PA << a_point.x << " " << a_point.y << std::endl;
	return a_point;
}

template<typename POSITIONTYPE>
void PointsAugment::xAxis(const POSITIONTYPE & p, POSITIONTYPE & a, double D)
{
	a.x = p.x;
	a.y = p.y;
	while (calc2PointsDistance(a, p) < D)
	{
		if (plus_or_minus == false)
		{
			a.y += 0.1 * D;
		}
		else
		{
			a.y -= 0.1 * D;
		}
	}
}

template<typename POSITIONTYPE>
void PointsAugment::hasSlopeNegtive(const POSITIONTYPE & p, POSITIONTYPE & a, double D)
{
	k = tan(fabs(p.heading) + M_PI / 2.0);
	b = p.y - k * p.x;

	a.x = calcAndGetX(D,p.x);
	a.y = k * a.x + b;
}

template<typename POSITIONTYPE>
void PointsAugment::hasSlopePos90(const POSITIONTYPE & p, POSITIONTYPE & a, double D)
{
	k = tan(M_PI / 2.0 - p.heading);
	b = p.y - k * p.x;
	a.x = calcAndGetX(D,p.x);
	a.y = k * a.x + b;
}

template<typename POSITIONTYPE>
void PointsAugment::hasSlopePos180(const POSITIONTYPE & p, POSITIONTYPE & a, double D)
{
	k = tan(M_PI * 2.5 - p.heading);
	b = p.y - k * p.x;
	a.x = calcAndGetX(D,p.x);
	a.y = k * a.x + b;
}

inline double PointsAugment::calcAndGetX(double D, double x)
{
	double A = 1 + k * k;
	double B = 2 * ((b - now_loc_y) * k - now_loc_x);
	double C = now_loc_x * now_loc_x + (b - now_loc_y) * (b - now_loc_y) - (D + 1e-1) * (D + 1e-1);
	double delta = B * B - 4 * A * C;
	if(delta >= 0)
	{
		double x1 = (-B + sqrt(delta)) / 2.0 / A;
		double x2 = (-B - sqrt(delta)) / 2.0 / A;
		PA << x1 << " " << x2 << " " << plus_or_minus << " " << A << " " << B << " " << C << " " << D << " " << delta << " ";
		return !plus_or_minus ? x1 : x2;
	}
	else
	{
		return x;
	}
	
}

template<typename POSITIONTYPE>
inline double PointsAugment::calc2PointsDistance(const POSITIONTYPE & p1, const POSITIONTYPE & p2)
{
	return sqrt(pow((p1.x - p2.x), 2) + pow((p1.y - p2.y), 2));
}

inline double PointsAugment::keepInAbsPI(double heading)
{
	if (heading > M_PI)
	{
		return (heading - 2 * M_PI);
	}
	if (heading < -M_PI)
	{
		return (heading + 2 * M_PI);
	}
	return heading;
}

template<typename POSITIONTYPE>
inline double PointsAugment::computePlusOrMinus(const POSITIONTYPE & EndPoint)
{
	double yaw = EndPoint.heading;
	if (yaw >= 0 && yaw <= M_PI)
	{
		return false;
	}
	else if (yaw < 0 && yaw >= -M_PI)
	{
		return true;
	}
}

inline double PointsAugment::toRad(double heading)
{
	return heading * M_PI / 180.0;
}
