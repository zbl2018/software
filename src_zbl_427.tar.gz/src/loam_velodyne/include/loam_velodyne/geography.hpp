#ifndef GEOGRAPHY_HPP_
#define GEOGRAPHY_HPP_

#include <cmath>
#include "LocalGeographicCS.hpp"


#define to_radians(x) ( (x) * (M_PI / 180.0 ) )
#define to_degrees(x) ( (x) * (180.0 / M_PI ) )

static LocalGeographicCS cs;

double vertical_direction(const double direction);
double inverse_direction(const double direction);

double ll_heading(double lat0, double lon0, double lat1, double lon1);
double xy_heading(double x0, double y0, double x1, double y1) ;

double ll_distance(const double lat0, const double lon0, const double lat1, const double lon1);
double ll_mdistance(const double lat0, const double lon0, const double lat1, const double lon1);
double xy_distance(const double x0, const double y0, const double x1, const double y1);
double xy_mdistance(const double x0, const double y0, const double x1, const double y1);




#endif /*GEOGRAPHY_HPP_*/
