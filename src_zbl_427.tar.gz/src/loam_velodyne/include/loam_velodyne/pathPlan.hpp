#ifndef PATHPLAN_HPP
#define PATHPLAN_HPP

#include <iostream>
#include <fstream>
#include <stdio.h>   
#include <stdlib.h> 
#include <string>
#include <vector>  
#include <set> 
#include <list>
#include <math.h>
#include <iomanip>
#include <time.h>

#include <jsoncpp/json/json.h>
#include <boost/lexical_cast.hpp>

#include "geography.hpp"


#define max 99999999

using namespace std;

struct GPSPoints{
    double lat;
    double lon;

    double x;
    double y;
    double height;

    double GaussX;
    double GaussY;

    double LX=0;
    double LY=0;

    double heading; 

    int map_index;
    int is_finish_turn;

    int is_turn;
    int key;

    string cname;
    string sname;
};//test

struct PointS
{
	double lat;
	double lon;
	int id;//start in 1
};
struct Lines
{
	int begin;
	int end;
	double length;
	int id;//start in 1
};

string getTime()
{
    time_t timep;
    time (&timep);
    char tmp[64];
    strftime(tmp, sizeof(tmp), "%Y-%m-%d--%H:%M:%S",localtime(&timep) );
    return tmp;
}

class pathPlan
{
public:
	pathPlan();
	~pathPlan();
	
	void readAlldata();
	vector<PointS> calculate(vector<PointS> taskNode);
	vector<PointS> obstacles(vector<PointS> taskNode, double heading);
	vector<PointS> plan(vector<int> task);
	vector<int> rebuildTopo(vector<PointS> node_in);//重建拓扑
	vector<int> paths(int start, int end);
	void outRoad(vector<int> way);
	void encodePath(string& paths,vector<GPSPoints> map);
	bool frontorback(double front_heading, double back_heading,double heading);
	void find_id(double lat,double lon,int &line_id, int &point_id,int &point_id_back);

	const string jsonfile = "/home/chen/Project/catkin_sysu/src/loam_velodyne/ck_map/office_0306/map_full.json";
	///home/chen/Project/catkin_sysu/src/loam_velodyne/ck_map/office_0306/map_full.json";
	///home/chen/Project/catkin_sysu/src/loam_velodyne/ck_map/1_29/map_full.json";
	//
	////home/shenrk/lym/ck_map/20180118_ck_map_v2/map_json/map_full_0118_v3.json";
	///home/dky/testdata/srk_10_30/map/map_full11_2.json
	//map_full_ck_1212.json //ck
	//map_full11_2 //ck
	///home/chen/testdata/srk_1018/map_full.json
    //const string outpath = "map/pathtestout.txt";
    const string outpath = "";
    boost::format pathtxt = boost::format("/home/chen/Project/catkin_sysu/src/loam_velodyne/pathtxt/%s");

	string pathplan;
	Json::Value mapdata;
	vector<vector<double> > graph;
	vector<vector<int> > nextnode;
	vector<PointS> all_points;
	vector<Lines> all_lines;
	vector<PointS> Tasknode;

};


pathPlan::pathPlan(){}
pathPlan::~pathPlan(){}

/*read all points and lines from json file*/
void pathPlan::readAlldata(){
	graph.clear();
	nextnode.clear();
	all_points.clear();
	all_lines.clear();
	
	int point_num = mapdata["points"]["number"].asInt();
	int line_num = mapdata["features"].size();

	all_points.resize(point_num);
	all_lines.resize(line_num);
	graph.resize(point_num);
	nextnode.resize(point_num);
	for(int i=0;i<point_num;i++){
		graph[i].resize(point_num);
		nextnode[i].resize(point_num);
	}

	for(int i=0;i<point_num;i++){
        for(int j=0;j<point_num;j++){
            graph[i][j]=max;
            nextnode[i][j]=-1;
        }
    }

    for(int i=0;i<point_num;i++){
        for(int j=0;j<point_num;j++){
            if(i == j)
            {
            	graph[i][j] = 0;
            }
        }
    }

	for(int i=0;i<point_num;i++){
		PointS newpoint;
		newpoint.lat = mapdata["points"]["point"][i]["coordinate"][0].asDouble();
		newpoint.lon = mapdata["points"]["point"][i]["coordinate"][2].asDouble();
		newpoint.id = mapdata["points"]["point"][i]["id"].asInt();
		all_points[i] = newpoint;
	}

	for(int i=0;i<line_num;i++){
		Lines newline;
		newline.begin = mapdata["features"][i]["attributes"]["FNODE_"].asInt();
		newline.end = mapdata["features"][i]["attributes"]["TNODE_"].asInt();
		newline.length = mapdata["features"][i]["attributes"]["LENGTH"].asDouble();
		newline.id = mapdata["features"][i]["attributes"]["CONVERAGE_"].asInt();
		all_lines[i] = newline;
	}

	for(int i=0;i<all_lines.size();i++)
    {
    	graph[all_lines[i].begin-1][all_lines[i].end-1] = all_lines[i].length;
    	graph[all_lines[i].end-1][all_lines[i].begin-1] = all_lines[i].length;
    	nextnode[all_lines[i].begin-1][all_lines[i].end-1] = all_lines[i].end-1;
    	nextnode[all_lines[i].end-1][all_lines[i].begin-1] = all_lines[i].begin-1;
    }

    for(int k=0;k<point_num;k++){
    	for(int i=0;i<point_num;i++){
    		for(int j=0;j<point_num;j++){
    			if (graph[i][j]>graph[k][j] + graph[i][k]){
                    graph[i][j] = graph[k][j] + graph[i][k];
                    nextnode[i][j] = nextnode[i][k];
                }
    		}
    	}
    }
}

vector<PointS> pathPlan::calculate(vector<PointS> taskNode){
	
	Json::Reader reader;
	ifstream infile;
	infile.open(jsonfile.c_str());
	mapdata.clear();

	if(!reader.parse(infile,mapdata))
	{
		cout<<"mapfile error"<<endl;
		exit(-1);
	}
	infile.close();

	Tasknode.clear();
	Tasknode.resize(taskNode.size());
	for(int i=0;i<taskNode.size();i++)
	{
		Tasknode[i] = taskNode[i];
	}

	readAlldata();
	vector<int > task_tmp = rebuildTopo(taskNode);
	
	////////////////////////////////////////////10-24
	vector<int> task;
	task.push_back(task_tmp[0]);
	for(int i=1;i<task_tmp.size();i++)
	{
		if(task_tmp[i] == task[task.size()-1])
		{
			continue;
		}
		else
		{
			task.push_back(task_tmp[i]);
		}
	}
	/////////////////////////////////////////////
	vector<PointS> output;
	output.clear();
	output = plan(task);
	return output;

}

vector<PointS> pathPlan::obstacles(vector<PointS> taskNode, double heading){
	
	Json::Reader reader;
	Json::Value newpoint;
	Json::Value deleted;
	ifstream infile;
	infile.open(jsonfile.c_str());
	mapdata.clear();

	if(!reader.parse(infile,mapdata))
	{
		cout<<"mapfile error"<<endl;
		exit(-1);
	}
	infile.close();
	
	readAlldata();

	Tasknode.clear();
	Tasknode.resize(taskNode.size());
	for(int i=0;i<taskNode.size();i++)
	{
		Tasknode[i] = taskNode[i];
	}

	PointS coor_now = taskNode[0];
	PointS task_node = taskNode[1];
	int line_id = 0;
	int line_point1 = 0;
	int line_point2 = 0;
	int path_size = 0 ;
	int path_back_size = 0;
	int point_id = 0;
	int point_id_back = 0;
	int line_size = 0;

	double lat = coor_now.lat;
	double lon = coor_now.lon;

	////////calculate the road id and the point id////////
	// line_size =mapdata["features"].size();
	// double p2ldistance = max;
	// for(int j=0;j<line_size;j++)
	// {
	// 	path_size = mapdata["features"][j]["geometry"]["paths"]["front"].size();
	// 	double line_lat1 = mapdata["features"][j]["geometry"]["paths"]["front"][0]["coordinate"][0].asDouble();
	// 	double line_lon1 = mapdata["features"][j]["geometry"]["paths"]["front"][0]["coordinate"][2].asDouble();
	// 	double line_lat2 = mapdata["features"][j]["geometry"]["paths"]["front"][path_size-1]["coordinate"][0].asDouble();
	// 	double line_lon2 = mapdata["features"][j]["geometry"]["paths"]["front"][path_size-1]["coordinate"][2].asDouble();

	// 	double cross = (line_lat2 - line_lat1) * (lat - line_lat1) + (line_lon2 - line_lon1) * (lon - line_lon1);
	// 	if(cross <= 0 ) continue;

	// 	double dis2 = (line_lat2 - line_lat1) * (line_lat2 - line_lat1) + (line_lon2 - line_lon1) * (line_lon2 - line_lon1);
	// 	if(cross >= dis2) continue;


	// 	double r = cross/dis2;
	// 	double px = line_lat1 + (line_lat2 - line_lat1) * r;
	// 	double py = line_lon1 + (line_lon2 - line_lon1) * r;
	// 	double line_distance = sqrt((lat - px)*(lat - px) + (lon - py)*(lon - py));

	// 	if(line_distance <p2ldistance)
	// 	{
	// 		p2ldistance = line_distance;
	// 		line_id = mapdata["features"][j]["attributes"]["CONVERAGE_"].asInt();
	// 		line_point1 = mapdata["features"][j]["attributes"]["FNODE_"].asInt();
	// 		line_point2 = mapdata["features"][j]["attributes"]["TNODE_"].asInt();
	// 	}
	// }

	// if(p2ldistance <= 0.5)//line_id point_id point_id_back
	// {
	// 	path_size = mapdata["features"][line_id-1]["geometry"]["paths"]["front"].size();
	// 	double point_distance = max;
	// 	for(int j=0;j<path_size;j++)//front
	// 	{
	// 		double pp[2] = {mapdata["features"][line_id-1]["geometry"]["paths"]["front"][j]["coordinate"][0].asDouble(),
	// 						mapdata["features"][line_id-1]["geometry"]["paths"]["front"][j]["coordinate"][2].asDouble()};

	// 		double point_dis = sqrt((lat-pp[0])*(lat-pp[0])+(lon-pp[1])*(lon-pp[1]));
	// 		if(point_dis<point_distance)
	// 		{
	// 			point_distance = point_dis;
	// 			point_id = j;
	// 		}
	// 	}

	// 	path_back_size = mapdata["features"][line_id-1]["geometry"]["paths"]["back"].size();
	// 	double point_back_distance = max;
	// 	for(int j=0;j<path_back_size;j++)//back
	// 	{
	// 		double pp_back[2] = {mapdata["features"][line_id-1]["geometry"]["paths"]["back"][j]["coordinate"][0].asDouble(),
	// 							 mapdata["features"][line_id-1]["geometry"]["paths"]["back"][j]["coordinate"][2].asDouble()};

	// 		double point_back_dis = sqrt((lat-pp_back[0])*(lat-pp_back[0])+(lon-pp_back[1])*(lon-pp_back[1]));
	// 		if(point_back_dis<point_back_distance)
	// 		{
	// 			point_back_distance = point_back_dis;
	// 			point_id_back = j;
	// 		}
	// 	}		
	// }
	// else
	// {
	// 	cout<<"cannot plan the road!!!!! "<<endl;
	// }
	//////////////////////////////////////////////////////

	/////////////////////////////////////////////////////
	find_id(lat,lon,line_id,point_id,point_id_back);
	//cout<<"line_id: "<<line_id<<"  point_id: "<<point_id<<"  point_id_back: "<<point_id_back<<endl;
	line_point1 = mapdata["features"][line_id-1]["attributes"]["FNODE_"].asInt();
	line_point2 = mapdata["features"][line_id-1]["attributes"]["TNODE_"].asInt();
	line_size =mapdata["features"].size();
	path_size = mapdata["features"][line_id-1]["geometry"]["paths"]["front"].size();
	path_back_size = mapdata["features"][line_id-1]["geometry"]["paths"]["back"].size();

	double front_heading = mapdata["features"][line_id-1]["geometry"]["paths"]["front"][point_id]["heading"].asDouble();
	double back_heading = mapdata["features"][line_id-1]["geometry"]["paths"]["back"][point_id_back]["heading"].asDouble();
	front_heading = front_heading *180/3.1415;
	back_heading = back_heading *180/3.1415;
	/////////////////////////////////////////////////////


	/*Add new point into point data*/
	int point_num = mapdata["points"]["number"].asInt(); 
	point_num++;
	newpoint.clear();
	// lat = mapdata["features"][line_id-1]["geometry"]["paths"]["front"][point_id]["coordinate"][0].asDouble();
	// lon = mapdata["features"][line_id-1]["geometry"]["paths"]["front"][point_id]["coordinate"][2].asDouble();
	newpoint["id"] = point_num;
	newpoint["coordinate"][0] = lat;
	newpoint["coordinate"][1] = mapdata["features"][line_id-1]["geometry"]["paths"]["front"][point_id]["coordinate"][1].asDouble();
	newpoint["coordinate"][2] = lon;
	newpoint["pointcloud1"] = mapdata["features"][line_id-1]["geometry"]["paths"]["front"][point_id]["pointcloud1"].asString();
	newpoint["pointcloud2"] = mapdata["features"][line_id-1]["geometry"]["paths"]["front"][point_id]["pointcloud2"].asString();
	newpoint["heading"] = mapdata["features"][line_id-1]["geometry"]["paths"]["front"][point_id]["heading"].asDouble();
	mapdata["points"]["point"].append(newpoint);
	mapdata["points"]["number"] = point_num;

	double line_point1_lat = mapdata["features"][line_id-1]["geometry"]["paths"]["front"][0]["coordinate"][0].asDouble();
	double line_point1_lon = mapdata["features"][line_id-1]["geometry"]["paths"]["front"][0]["coordinate"][2].asDouble();
	double distance = sqrt((lat-line_point1_lat)*(lat-line_point1_lat)+(lon-line_point1_lon)*(lon-line_point1_lon));
	double Length = mapdata["features"][line_id-1]["attributes"]["LENGTH"].asDouble();
	mapdata["features"][line_id-1]["attributes"]["TNODE_"] = point_num;
	mapdata["features"][line_id-1]["attributes"]["LENGTH"] = distance;

	//Add new point2 into point data///
	newpoint.clear();
	int size_tmp = mapdata["features"][line_id-1]["geometry"]["paths"]["front"].size();
	int point_id_count = 0;
	if(size_tmp - point_id >2)
	{
		point_id_count = point_id+2;
	}
	else
	{
		point_id_count = size_tmp-1;
	}
	
	lat = mapdata["features"][line_id-1]["geometry"]["paths"]["front"][point_id_count]["coordinate"][0].asDouble();
	lon = mapdata["features"][line_id-1]["geometry"]["paths"]["front"][point_id_count]["coordinate"][2].asDouble();
	newpoint["id"] = point_num+1;
	newpoint["coordinate"][0] = lat;
	newpoint["coordinate"][1] = mapdata["features"][line_id-1]["geometry"]["paths"]["front"][point_id_count]["coordinate"][1].asDouble();
	newpoint["coordinate"][2] = lon;
	newpoint["pointcloud1"] = mapdata["features"][line_id-1]["geometry"]["paths"]["front"][point_id_count]["pointcloud1"].asString();
	newpoint["pointcloud2"] = mapdata["features"][line_id-1]["geometry"]["paths"]["front"][point_id_count]["pointcloud2"].asString();
	newpoint["heading"] = mapdata["features"][line_id-1]["geometry"]["paths"]["front"][point_id_count]["heading"].asDouble();
	mapdata["points"]["point"].append(newpoint);
	mapdata["points"]["number"] = point_num+1;



	//Add new line into mapdata//
	newpoint.clear();
	line_size++;
	newpoint["attributes"]["FNODE_"] = point_num+1;
	newpoint["attributes"]["TNODE_"] = line_point2;
	newpoint["attributes"]["CONVERAGE_"] = line_size;
	newpoint["attributes"]["LENGTH"] = Length - distance;
	newpoint["geometry"]["paths"]["front"][0]["coordinate"][0] = lat;
	newpoint["geometry"]["paths"]["front"][0]["coordinate"][1] = 0;
	newpoint["geometry"]["paths"]["front"][0]["coordinate"][2] = lon;
	newpoint["geometry"]["paths"]["front"][0]["pointcloud1"] = mapdata["features"][line_id-1]["geometry"]["paths"]["front"][point_id_count]["pointcloud1"].asString();
	newpoint["geometry"]["paths"]["front"][0]["pointcloud2"] = mapdata["features"][line_id-1]["geometry"]["paths"]["front"][point_id_count]["pointcloud2"].asString();
	newpoint["geometry"]["paths"]["front"][0]["heading"] = mapdata["features"][line_id-1]["geometry"]["paths"]["front"][point_id_count+1]["heading"].asDouble();
	mapdata["features"].append(newpoint);

	int point_count = path_size -point_id -1;
	for(int j=0;j<point_count;j++)
	{
		deleted.clear();
		mapdata["features"][line_id-1]["geometry"]["paths"]["front"].removeIndex(point_id+1 , &deleted);
		mapdata["features"][line_size-1]["geometry"]["paths"]["front"].append(deleted);

	}

	//int point_back_count = path_back_size -point_id_back -1;
	for(int j=0;j<point_id_back;j++)
	{
		deleted.clear();
		mapdata["features"][line_id-1]["geometry"]["paths"]["back"].removeIndex(0, &deleted);
		mapdata["features"][line_size-1]["geometry"]["paths"]["back"].append(deleted);

	}

	newpoint.clear();
	newpoint["geometry"]["paths"]["back"][0]["coordinate"][0] = lat;
	newpoint["geometry"]["paths"]["back"][0]["coordinate"][1] = 0;
	newpoint["geometry"]["paths"]["back"][0]["coordinate"][2] = lon;
	newpoint["geometry"]["paths"]["back"][0]["pointcloud1"] = mapdata["features"][line_id-1]["geometry"]["paths"]["back"][point_id_back]["pointcloud1"].asString();
	newpoint["geometry"]["paths"]["back"][0]["pointcloud2"] = mapdata["features"][line_id-1]["geometry"]["paths"]["back"][point_id_back]["pointcloud2"].asString();
	newpoint["geometry"]["paths"]["back"][0]["heading"] = mapdata["features"][line_id-1]["geometry"]["paths"]["back"][0]["heading"].asDouble();
	mapdata["features"][line_size-1]["geometry"]["paths"]["back"].append(newpoint);

	///////////////////////////////////////////////////////////


	bool front = frontorback(front_heading,back_heading,heading);
	cout<<"front_heading: "<<front_heading<<" "<<"back_heading:"<<back_heading<<" "<<" heading_now:"<<heading<<endl;
	readAlldata();
	vector<PointS> task_input;
	task_input.push_back(task_node);
	vector<int > task_tmp = rebuildTopo(task_input);
	
	////////////////////////////////////////////10-24
	vector<int> task;
	if(front)
	{
		task.push_back(point_num);
		cout<<"front"<<endl;
	}
	else
	{
		task.push_back(point_num+1);
		cout<<"back"<<endl;
	}
	
	for(int i=0;i<task_tmp.size();i++)
	{
		if(task_tmp[i] == task[task.size()-1])
		{
			continue;
		}
		else
		{
			task.push_back(task_tmp[i]);
		}
	}
	/////////////////////////////////////////////
	vector<PointS> output;
	output.clear();
	output = plan(task);
	return output;

}

vector<PointS> pathPlan::plan(vector<int> task){
	cout<<"tasksize: "<<task.size()<<endl;
	readAlldata();
	cout<<"readok"<<endl;

	for(int i=0;i<task.size();i++){
		task[i]--;
	}	
	int start = task[0];
	int end =0;
	int task_size = task.size();
	vector<int> mark;
	vector<int> way;
	vector<int> subway;
	vector<PointS> output;
	output.clear();

	if(task_size<2){
		int point_index = task[0]++;
		for(int i=0;i<all_points.size();i++){
			if(all_points[i].id == point_index){
				output.push_back(all_points[i]);
			}
		} 
		return output;
	}
	else{
		end = task[1];
	}

	for(int i=0;i<task_size;i++){
		mark.push_back(task[i]);
	}

	way.push_back(start);
	mark[0] = -1;

	for(int i=1;i<task_size;i++){
		double min = max;
		int pointindex = 1;
		for(int j=0;j<task_size;j++){
			if(mark[j] == -1) continue;

			if(graph[start][mark[j]] < min){
				min = graph[start][mark[j]];
				pointindex = j;
			}
		}

		if(start == mark[pointindex])
		{
			start = mark[pointindex];
       		mark[pointindex] = -1;
       		continue;
		}

		subway = paths(start,mark[pointindex]);
		for (vector<int>::iterator iter = subway.begin(); iter != subway.end(); iter++)
		{
			way.push_back(*iter);
		}
		subway.clear();
        start = mark[pointindex];
        mark[pointindex] = -1;
	}

	for(int i=0;i<way.size();i++){

		for(int j=0;j<all_points.size();j++){
			if(way[i]+1 == all_points[j].id){
				output.push_back(all_points[j]);
			}
		}
	}

	outRoad(way);
	return output;
}

vector<int> pathPlan::rebuildTopo(vector<PointS> node_in){
	int node_size = node_in.size();
	Json::Value newpoint;
	Json::Value deleted;
	vector<int> out;

	/////////////////////
	Json::StyledWriter jwriter;
	ofstream testjson("/home/chen/Project/catkin_sysu/src/loam_velodyne/map_test.json");

	/////////////////////

	int line_id = 0;
	int point_id = 0;
	int point_id_back = 0;

	for(int i=0;i<node_size;i++)
	{
	
		int line_point1 = 0;
		int line_point2 = 0;
		int path_size = 0 ;
		int path_back_size = 0;

		int line_size = 0;

		readAlldata();
		
		double lat = node_in[i].lat;
		double lon = node_in[i].lon;
		double lat_back = 0;
		double lon_back = 0;
		bool isGpoint = false;
		//cout<<all_points.size()<<endl;
		for(int j=0;j<all_points.size();j++)
		{
			// if((fabs(lat - all_points[j].lat) < 0.0000000001) && (fabs(lon - all_points[j].lon) < 0.0000000001))
			// {
			// 	out.push_back(all_points[j].id);

			// 	isGpoint = true;
			// 	break;
			// }
			if(xy_distance(lat,lon,all_points[j].lat,all_points[j].lon) <0.1)
			{
				out.push_back(all_points[j].id);

				isGpoint = true;
				break;
			}
		}

		if(isGpoint) continue;
/*
		line_size =mapdata["features"].size();
		double p2ldistance = max;
		for(int j=0;j<line_size;j++)
		{
			path_size = mapdata["features"][j]["geometry"]["paths"]["front"].size();
			double line_lat1 = mapdata["features"][j]["geometry"]["paths"]["front"][0]["coordinate"][0].asDouble();
			double line_lon1 = mapdata["features"][j]["geometry"]["paths"]["front"][0]["coordinate"][2].asDouble();
			double line_lat2 = mapdata["features"][j]["geometry"]["paths"]["front"][path_size-1]["coordinate"][0].asDouble();
			double line_lon2 = mapdata["features"][j]["geometry"]["paths"]["front"][path_size-1]["coordinate"][2].asDouble();

			double cross = (line_lat2 - line_lat1) * (lat - line_lat1) + (line_lon2 - line_lon1) * (lon - line_lon1);
			if(cross <= 0 ) continue;

			double dis2 = (line_lat2 - line_lat1) * (line_lat2 - line_lat1) + (line_lon2 - line_lon1) * (line_lon2 - line_lon1);
			if(cross >= dis2) continue;


			double r = cross/dis2;
			double px = line_lat1 + (line_lat2 - line_lat1) * r;
			double py = line_lon1 + (line_lon2 - line_lon1) * r;
			double line_distance = sqrt((lat - px)*(lat - px) + (lon - py)*(lon - py));

			if(line_distance <p2ldistance)
			{
				p2ldistance = line_distance;
				line_id = mapdata["features"][j]["attributes"]["CONVERAGE_"].asInt();
				line_point1 = mapdata["features"][j]["attributes"]["FNODE_"].asInt();
				line_point2 = mapdata["features"][j]["attributes"]["TNODE_"].asInt();
			}
		}

		if(p2ldistance <= 0.5)
		{
			path_size = mapdata["features"][line_id-1]["geometry"]["paths"]["front"].size();
			double point_distance = max;
			for(int j=0;j<path_size;j++)//front
			{
				double pp[2] = {mapdata["features"][line_id-1]["geometry"]["paths"]["front"][j]["coordinate"][0].asDouble(),
								mapdata["features"][line_id-1]["geometry"]["paths"]["front"][j]["coordinate"][2].asDouble()};

				double point_dis = sqrt((lat-pp[0])*(lat-pp[0])+(lon-pp[1])*(lon-pp[1]));
				if(point_dis<point_distance)
				{
					point_distance = point_dis;
					point_id = j;
				}
			}

			path_back_size = mapdata["features"][line_id-1]["geometry"]["paths"]["back"].size();
			double point_back_distance = max;
			for(int j=0;j<path_back_size;j++)//back
			{
				double pp_back[2] = {mapdata["features"][line_id-1]["geometry"]["paths"]["back"][j]["coordinate"][0].asDouble(),
									 mapdata["features"][line_id-1]["geometry"]["paths"]["back"][j]["coordinate"][2].asDouble()};

				double point_back_dis = sqrt((lat-pp_back[0])*(lat-pp_back[0])+(lon-pp_back[1])*(lon-pp_back[1]));
				if(point_back_dis<point_back_distance)
				{
					point_back_distance = point_back_dis;
					point_id_back = j;
				}
			}
			
		}
		else//error
		{
			//out.push_back(-1);
			//cout<<"cannot plan the road!!!!! "<<endl;
			//return out;
			///////////////////////////////////////

			////////////////10_23//////////////////
			int points_size = mapdata["points"]["number"].asInt();
			double near_point = max;
			int point_id2;
			for(int count=0;count<points_size;count++)
			{
				double x1 = mapdata["points"]["point"][count]["coordinate"][0].asDouble();
				double y1 = mapdata["points"]["point"][count]["coordinate"][2].asDouble();
				double dis_tmp = xy_distance(lat,lon,x1,y1);
				if(dis_tmp < near_point)
				{
					point_id2 = mapdata["points"]["point"][count]["id"].asInt();
					near_point = dis_tmp;
				}

			}

			out.push_back(point_id2);
			continue;
			///////////////////////////////////////
		}
*/
		

		///////////////////////////////////////////////////
		find_id(lat,lon,line_id,point_id,point_id_back);
		//cout<<"line_id: "<<line_id<<"  point_id: "<<point_id<<"  point_id_back: "<<point_id_back<<endl;
		line_point1 = mapdata["features"][line_id-1]["attributes"]["FNODE_"].asInt();
		line_point2 = mapdata["features"][line_id-1]["attributes"]["TNODE_"].asInt();
		line_size =mapdata["features"].size();
		path_size = mapdata["features"][line_id-1]["geometry"]["paths"]["front"].size();
		path_back_size = mapdata["features"][line_id-1]["geometry"]["paths"]["back"].size();
		///////////////////////////////////////////////////


		/*Add new point into point data*/
		int point_num = mapdata["points"]["number"].asInt();
		point_num++;
		newpoint.clear();
		// lat = mapdata["features"][line_id-1]["geometry"]["paths"]["front"][point_id]["coordinate"][0].asDouble();
		// lon = mapdata["features"][line_id-1]["geometry"]["paths"]["front"][point_id]["coordinate"][2].asDouble();
		newpoint["id"] = point_num;
		newpoint["coordinate"][0] = lat;
		newpoint["coordinate"][1] = mapdata["features"][line_id-1]["geometry"]["paths"]["front"][point_id]["coordinate"][1].asDouble();
		newpoint["coordinate"][2] = lon;
		newpoint["pointcloud1"] = mapdata["features"][line_id-1]["geometry"]["paths"]["front"][point_id]["pointcloud1"].asString();
		newpoint["pointcloud2"] = mapdata["features"][line_id-1]["geometry"]["paths"]["front"][point_id]["pointcloud2"].asString();
		newpoint["heading"] = mapdata["features"][line_id-1]["geometry"]["paths"]["front"][point_id]["heading"].asDouble();
		mapdata["points"]["point"].append(newpoint);
		mapdata["points"]["number"] = point_num;
		out.push_back(point_num);

		double line_point1_lat = mapdata["features"][line_id-1]["geometry"]["paths"]["front"][0]["coordinate"][0].asDouble();
		double line_point1_lon = mapdata["features"][line_id-1]["geometry"]["paths"]["front"][0]["coordinate"][2].asDouble();
		double distance = sqrt((lat-line_point1_lat)*(lat-line_point1_lat)+(lon-line_point1_lon)*(lon-line_point1_lon));
		double Length = mapdata["features"][line_id-1]["attributes"]["LENGTH"].asDouble();
		mapdata["features"][line_id-1]["attributes"]["TNODE_"] = point_num;
		mapdata["features"][line_id-1]["attributes"]["LENGTH"] = distance;

		
		/*Add new line into mapdata*/
		/////////test-1210//////////////////////////////////////////////////////////////////////////////////////
		lat = mapdata["features"][line_id-1]["geometry"]["paths"]["front"][point_id]["coordinate"][0].asDouble();
		lon = mapdata["features"][line_id-1]["geometry"]["paths"]["front"][point_id]["coordinate"][2].asDouble();
		lat_back = mapdata["features"][line_id-1]["geometry"]["paths"]["back"][point_id_back]["coordinate"][0].asDouble();
		lon_back = mapdata["features"][line_id-1]["geometry"]["paths"]["back"][point_id_back]["coordinate"][2].asDouble();
		/////////////////////////////////////////////////////////////////////////////////////////////////////////
		newpoint.clear();
		line_size++;
		newpoint["attributes"]["FNODE_"] = point_num;
		newpoint["attributes"]["TNODE_"] = line_point2;
		newpoint["attributes"]["CONVERAGE_"] = line_size;
		newpoint["attributes"]["LENGTH"] = Length - distance;
		newpoint["geometry"]["paths"]["front"][0]["coordinate"][0] = lat;
		newpoint["geometry"]["paths"]["front"][0]["coordinate"][1] = 0;
		newpoint["geometry"]["paths"]["front"][0]["coordinate"][2] = lon;
		newpoint["geometry"]["paths"]["front"][0]["pointcloud1"] = mapdata["features"][line_id-1]["geometry"]["paths"]["front"][point_id]["pointcloud1"].asString();
		newpoint["geometry"]["paths"]["front"][0]["pointcloud2"] = mapdata["features"][line_id-1]["geometry"]["paths"]["front"][point_id]["pointcloud2"].asString();
		newpoint["geometry"]["paths"]["front"][0]["heading"] = mapdata["features"][line_id-1]["geometry"]["paths"]["front"][point_id+1]["heading"].asDouble();

		mapdata["features"].append(newpoint);

		int point_count = path_size -point_id -1;
		for(int j=0;j<point_count;j++)
		{
			deleted.clear();
			mapdata["features"][line_id-1]["geometry"]["paths"]["front"].removeIndex(point_id+1 , &deleted);
			mapdata["features"][line_size-1]["geometry"]["paths"]["front"].append(deleted);

		}

		//int point_back_count = path_back_size -point_id_back -1;
		for(int j=0;j<point_id_back;j++)
		{
			deleted.clear();
			mapdata["features"][line_id-1]["geometry"]["paths"]["back"].removeIndex(0, &deleted);
			mapdata["features"][line_size-1]["geometry"]["paths"]["back"].append(deleted);

		}


		newpoint.clear();
		newpoint["geometry"]["paths"]["back"][0]["coordinate"][0] = lat_back;
		newpoint["geometry"]["paths"]["back"][0]["coordinate"][1] = 0;
		newpoint["geometry"]["paths"]["back"][0]["coordinate"][2] = lon_back;
		newpoint["geometry"]["paths"]["back"][0]["pointcloud1"] = mapdata["features"][line_id-1]["geometry"]["paths"]["back"][point_id_back]["pointcloud1"].asString();
		newpoint["geometry"]["paths"]["back"][0]["pointcloud2"] = mapdata["features"][line_id-1]["geometry"]["paths"]["back"][point_id_back]["pointcloud2"].asString();
		newpoint["geometry"]["paths"]["back"][0]["heading"] = mapdata["features"][line_id-1]["geometry"]["paths"]["back"][0]["heading"].asDouble();
		mapdata["features"][line_size-1]["geometry"]["paths"]["back"].append(deleted);


	}



	testjson << jwriter.write(mapdata);
	testjson.close();
	cout << "mapjson" << endl;

	return out;
}

vector<int> pathPlan::paths(int start, int end){
	vector<int> way;
	vector<int> subway;
	//cout<<start<<" "<<end<<endl;
	if (nextnode[start][end] != -1)
	{
		if (nextnode[start][end] == end)
		{
			way.push_back(end);
		}
		else
		{
			way.push_back(nextnode[start][end]);
			subway = paths(nextnode[start][end],end);
			for (vector<int>::iterator iter = subway.begin(); iter != subway.end(); iter++)
			{
				way.push_back(*iter);
			}
			subway.clear();
		}
	}
	else
	{
		std::cout << "无法到达点：" << endl;
		exit(-1);
	}
	return way;
}

void pathPlan::outRoad(vector<int> way){
 	for(int i=0;i<way.size();i++){
 		way[i]++;
 		cout<<way[i]<<" ";
 	}
 	cout<<endl;

 	string navi_path;
 	vector<GPSPoints> road;
 	road.clear();
	
	int path_size = way.size();
	int stpoint = way[0];
	int enpoint = way[0];
	double lat,lon,x,z,y,heading;
	string pointcloud1,pointcloud2;

	double lat_last,lon_last,x_last,z_last,y_last,heading_last;
	string pointcloud1_last,pointcloud2_last;

	int keyframe = 0;
	int turnpoint = 0;

	double x_ori,y_ori,heading_ori,x_new,y_new,heading_new;

	double distance = 0.0;

	///////////////////////////
    ofstream outfile;
    string outpathtxt = getTime();
    outfile.open((pathtxt%outpathtxt).str().c_str());
	///////////////////////////
    outfile<<"lat_now: "<< Tasknode[0].lat<<" "<<"lon_now: "<<Tasknode[0].lon<<" "<<" task_x: "<<Tasknode[1].lat<<" "<<"task_y: "<<Tasknode[1].lon<<endl;

	//////////////////////////

	for(int i=1;i<path_size;i++)
	{
		enpoint = way[i];
		int mapsize = mapdata["features"].size();
		for(int j=0;j<mapsize;j++)
		{
            int start = mapdata["features"][j]["attributes"]["FNODE_"].asInt();
			int end = mapdata["features"][j]["attributes"]["TNODE_"].asInt();
			if(start == stpoint && end == enpoint)
			{
				cout<<mapdata["features"][j]["attributes"]["CONVERAGE_"].asString()<<endl;
				int point_size = mapdata["features"][j]["geometry"]["paths"]["front"].size();
				for(int k=0;k<point_size;k++)
				{
					keyframe = 0;
					turnpoint = 0;
					x = mapdata["features"][j]["geometry"]["paths"]["front"][k]["coordinate"][0].asDouble();
					z = mapdata["features"][j]["geometry"]["paths"]["front"][k]["coordinate"][1].asDouble();
					y = mapdata["features"][j]["geometry"]["paths"]["front"][k]["coordinate"][2].asDouble();
					pointcloud1 = mapdata["features"][j]["geometry"]["paths"]["front"][k]["pointcloud1"].asString();
					pointcloud2 = mapdata["features"][j]["geometry"]["paths"]["front"][k]["pointcloud2"].asString();
					heading = mapdata["features"][j]["geometry"]["paths"]["front"][k]["heading"].asDouble();

					if(pointcloud1.compare("") == 0 || pointcloud2.compare("") == 0) continue;

                    GPSPoints Newpoint;

					if(k == 0 && i == 1)
					{
						x_ori = x;
						y_ori = y;
						heading_ori = heading;
						keyframe = 0;
						turnpoint = 1;
						
						Newpoint.x = x;
						Newpoint.height = z;
						Newpoint.y = y;
						Newpoint.cname = pointcloud1;
						Newpoint.sname = pointcloud2;
						Newpoint.heading = heading;
						Newpoint.key = keyframe;
						Newpoint.is_turn = turnpoint;
						road.push_back(Newpoint);

                                                 outfile << setprecision(12) << x << " " << z << " "<< y << " "
                                                                                                        << pointcloud1 << " " << pointcloud2 << " "
                                                                                                        << heading << " " << keyframe << " " << turnpoint << endl;

					}


					else if(k == point_size-1 && i == path_size-1)
					{
						turnpoint = 1;

						Newpoint.x = x;
						Newpoint.height = z;
						Newpoint.y = y;
						Newpoint.cname = pointcloud1;
						Newpoint.sname = pointcloud2;
						Newpoint.heading = heading;
						Newpoint.key = keyframe;
						Newpoint.is_turn = turnpoint;
						road.push_back(Newpoint);

                                                 outfile << setprecision(12) << x << " " << z << " "<< y << " "
                                                                                                        << pointcloud1 << " " << pointcloud2 << " "
                                                                                                        << heading << " " << keyframe << " " << turnpoint << endl;
					}

					else 
					{
						x_new = x;
						y_new = y;
						heading_new = heading;
						distance += xy_distance(x_ori,y_ori,x_new,y_new);
						if(distance >= 0.3)
						{
							keyframe = 1;
							distance = 0.0;
						}
						
						if(fabs(heading_new - heading_ori) > 1.3)//turn point heading larger than 70 degree
						{
							turnpoint = 1;
							
						}

						Newpoint.x = x;
						Newpoint.height = z;
						Newpoint.y = y;
						Newpoint.cname = pointcloud1;
						Newpoint.sname = pointcloud2;
						Newpoint.heading = heading;
						Newpoint.key = keyframe;
						Newpoint.is_turn = turnpoint;
						road.push_back(Newpoint);

                                                 outfile << setprecision(12) << x << " " << z << " "<< y << " "
                                                                                                        << pointcloud1 << " " << pointcloud2 << " "
                                                                                                        << heading << " " << keyframe << " " << turnpoint << endl;

						x_ori =x;
						y_ori = y;
						heading_ori = heading;
						keyframe = 0;
						turnpoint = 0;
					}

				}
			}
			


			if(end == stpoint && start == enpoint)
			{
				int point_back_size = mapdata["features"][j]["geometry"]["paths"]["back"].size();
				cout<<mapdata["features"][j]["attributes"]["CONVERAGE_"].asString()<<endl;
				for(int k=0;k<point_back_size;k++)
				{
					keyframe = 0;
					turnpoint = 0;
					x = mapdata["features"][j]["geometry"]["paths"]["back"][k]["coordinate"][0].asDouble();
					z = mapdata["features"][j]["geometry"]["paths"]["back"][k]["coordinate"][1].asDouble();
					y = mapdata["features"][j]["geometry"]["paths"]["back"][k]["coordinate"][2].asDouble();
					pointcloud1 = mapdata["features"][j]["geometry"]["paths"]["back"][k]["pointcloud1"].asString();
					pointcloud2 = mapdata["features"][j]["geometry"]["paths"]["back"][k]["pointcloud2"].asString();
					heading = mapdata["features"][j]["geometry"]["paths"]["back"][k]["heading"].asDouble();

					if(pointcloud1.compare("") == 0 || pointcloud2.compare("") == 0) continue;
					
					GPSPoints Newpoint;

					if(k == 0 && i == 1)
					{
						x_ori = x;
						y_ori = y;
						heading_ori = heading;
						keyframe = 0;
						turnpoint = 0;
						
						Newpoint.x = x;
						Newpoint.height = z;
						Newpoint.y = y;
						Newpoint.cname = pointcloud1;
						Newpoint.sname = pointcloud2;
						Newpoint.heading = heading;
						Newpoint.key = keyframe;
						Newpoint.is_turn = turnpoint;
						road.push_back(Newpoint);

                                                outfile << setprecision(12) << x << " " << z << " "<< y << " "
                                                                                                        << pointcloud1 << " " << pointcloud2 << " "
                                                                                                        << heading << " " << keyframe << " " << turnpoint << endl;

					}


                                        else if(k == point_back_size-1 && i == path_size-1)
					{
						turnpoint = 1;

						Newpoint.x = x;
						Newpoint.height = z;
						Newpoint.y = y;
						Newpoint.cname = pointcloud1;
						Newpoint.sname = pointcloud2;
						Newpoint.heading = heading;
						Newpoint.key = keyframe;
						Newpoint.is_turn = turnpoint;
						road.push_back(Newpoint);

                                                 outfile << setprecision(12) << x << " " << z << " "<< y << " "
                                                                                                        << pointcloud1 << " " << pointcloud2 << " "
                                                                                                        << heading << " " << keyframe << " " << turnpoint << endl;
					}

					else 
					{
						x_new = x;
						y_new = y;
						heading_new = heading;
						distance += xy_distance(x_ori,y_ori,x_new,y_new);
						if(distance >= 0.3)
						{
							keyframe = 1;
							distance = 0.0;
						}
						
						if(fabs(heading_new - heading_ori) > 1.3)//turn point heading larger than 70 degree
						{
							turnpoint = 1;
							
						}

						Newpoint.x = x;
						Newpoint.height = z;
						Newpoint.y = y;
						Newpoint.cname = pointcloud1;
						Newpoint.sname = pointcloud2;
						Newpoint.heading = heading;
						Newpoint.key = keyframe;
						Newpoint.is_turn = turnpoint;
						road.push_back(Newpoint);

                                                 outfile << setprecision(12) << x << " " << z << " "<< y << " "
                                                                                                        << pointcloud1 << " " << pointcloud2 << " "
                                                                                                        << heading << " " << keyframe << " " << turnpoint << endl;

						x_ori =x;
						y_ori = y;
						heading_ori = heading;
						keyframe = 0;
						turnpoint = 0;
					}

				}

			}




		}


		stpoint = way[i];
	}

        outfile.close();
	encodePath(navi_path,road);
	pathplan = navi_path;

}

void pathPlan::encodePath(string& paths,vector<GPSPoints> map){
  string final_s("");
  string tmp_s("");
  string r("");
  //stringstream ss;
  for(int i = 0; i < map.size(); i++){

    tmp_s.clear();
    tmp_s = boost::lexical_cast<string>(map[i].x);
    r = tmp_s;

    tmp_s.clear();
    tmp_s = boost::lexical_cast<string>(map[i].height);
    r.append(" ").append(tmp_s);

    tmp_s.clear();
    tmp_s = boost::lexical_cast<string>(map[i].y);
    r.append(" ").append(tmp_s);

    tmp_s.clear();
    tmp_s = boost::lexical_cast<string>(map[i].cname);
    r.append(" ").append(tmp_s);

    tmp_s.clear();
    tmp_s = boost::lexical_cast<string>(map[i].sname);
    r.append(" ").append(tmp_s);

    tmp_s.clear();
    tmp_s = boost::lexical_cast<string>(map[i].heading);
    r.append(" ").append(tmp_s);

    tmp_s.clear();
    tmp_s = boost::lexical_cast<string>(map[i].key);
    r.append(" ").append(tmp_s);

    tmp_s.clear();
    tmp_s = boost::lexical_cast<string>(map[i].is_turn);
    r.append(" ").append(tmp_s);

    //cout<<i<<endl;

    if(i == map.size()-1)
    {
      final_s.append(r);
    }else{
      final_s.append(r).append(";");
    }
  }
  paths = final_s;
  cout<<"encode path end and map size is "<<map.size()<<endl;
}

bool pathPlan::frontorback(double front_heading,double back_heading,double heading){
	
	double left_heading_f = front_heading - 70;
	double right_heading_f = front_heading +70;
	double left_heading_b = back_heading - 70;
	double right_heading_b = back_heading +70;
	///////front//////////////////////////
	if(left_heading_f < -180)
	{
		left_heading_f +=360;
		if( (heading < right_heading_f && heading >= -180) || (heading >=left_heading_f && heading <=180))
		{
			return true;
		}
	}
	else if(right_heading_f > 180)
	{
		right_heading_f -=360;
		if( (heading > left_heading_f && heading <=180) || (heading < right_heading_f && heading >= -180) )
		{
			return true;
		}
	}
	else
	{
		if( heading > left_heading_f && heading < right_heading_f)
		{
			return true;
		}
	}
	////////////////////////////////////////////////////////////////
	if(left_heading_b < -180)
	{
		left_heading_b +=360;
		if( (heading < right_heading_b && heading >= -180) || (heading >=left_heading_b && heading <=180))
		{
			return false;
		}
	}
	else if(right_heading_b > 180)
	{
		right_heading_b -=360;
		if( (heading > left_heading_b && heading <=180) || (heading < right_heading_b && heading >= -180) )
		{
			return false;
		}
	}
	else
	{
		if( heading > left_heading_b && heading < right_heading_b)
		{
			return false;
		}
	}

	return true;

}
void pathPlan::find_id(double lat,double lon,int &line_id, int &point_id,int &point_id_back){
	double distance = 9999999999;
	double distance_back = 99999999;
	int line_size = mapdata["features"].size();
	for(int i=0;i<line_size;i++)
	{
		int path_size = mapdata["features"][i]["geometry"]["paths"]["front"].size();
		for(int j=0;j<path_size;j++)
		{
			double line_lat1 = mapdata["features"][i]["geometry"]["paths"]["front"][j]["coordinate"][0].asDouble();
			double line_lon1 = mapdata["features"][i]["geometry"]["paths"]["front"][j]["coordinate"][2].asDouble();

			double line_distance = sqrt((lat - line_lat1)*(lat - line_lat1) + (lon - line_lon1)*(lon - line_lon1));
			if(line_distance < distance)
			{
				line_id = mapdata["features"][i]["attributes"]["CONVERAGE_"].asInt();
				point_id = j;
				distance = line_distance;
			}
		}

		path_size = mapdata["features"][i]["geometry"]["paths"]["back"].size();
		for(int j=0;j<path_size;j++)
		{
			double line_lat1 = mapdata["features"][i]["geometry"]["paths"]["back"][j]["coordinate"][0].asDouble();
			double line_lon1 = mapdata["features"][i]["geometry"]["paths"]["back"][j]["coordinate"][2].asDouble();

			double line_distance = sqrt((lat - line_lat1)*(lat - line_lat1) + (lon - line_lon1)*(lon - line_lon1));
			if(line_distance < distance_back)
			{
				point_id_back = j;
				distance_back = line_distance;
			}
		}
	}

}
#endif
