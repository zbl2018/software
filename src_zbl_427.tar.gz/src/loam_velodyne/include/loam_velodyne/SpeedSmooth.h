#ifndef _SPEEDSMOOTH_H
#define _SPEEDSMOOTH_H

#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;

ofstream op("/home/chen/Project/catkin_sysu/src/loam_velodyne/output/ssdata.txt");
const float SmallestSpeed = 0.3;
const float Stop = 0.0;
const float Kp = 0.15;
const float MAX_DELT_v = 0.08;
const float MIN_v = 0.005;
const float TheLengthOfATire = 80.110613;
const float DISTANCE = 1.5;

struct InfoToSS
{
    float SendSpeed; // the speed would be sent to the car
    float TargetSpeed; //target speed
    int LeftBackTire;
    int RightBackTire;
    float Distance2Stop;
};

inline float CaculateFeedBackSpeed(int cs1, int cs2)
{
    float cs = cs1 + cs2;
    float result = cs * 0.5 / 60.0 * TheLengthOfATire * 0.01;
    op << result << " ";
    return result;
}

float FilterFeedBackSpeed(int cs1, int cs2)
{
    static float last_cs1;
    static float last_cs2;
    static int last_cnt = 0;
    
    if(!last_cnt)
    {
        last_cs1 = cs1;
        last_cs2 = cs2;
        last_cnt++;
        return CaculateFeedBackSpeed(cs1,cs2);
    }
    else
    {
        if(fabs(cs1 - last_cs1) > 12 && fabs(cs2 - last_cs2) > 12)
        {
            cs1 = last_cs1;
            cs2 = last_cs2; 
        }
        else if(fabs(cs1 - last_cs1) > 12)
        {
            cs1 = cs2;
        }
        else if(fabs(cs2 - last_cs2) > 12)
        {
            cs2 = cs1;
        }
        last_cs1 = cs1;
        last_cs2 = cs2;
        return CaculateFeedBackSpeed(cs1,cs2);
    }

}

float SpeedUp(float vi, float vt)
{   
    if(vi <= vt)
    {
        if(vi < 1e-5)
        {
            return SmallestSpeed;
        }
        if((vi + MIN_v) < vt)
        {
            return vi + MIN_v;
        }
        else
        {
            return vt;
        }
    }
    else
    {
        if(vi <= 0.20)
            return SmallestSpeed;
        return vi;
    }
}

float SpeedDown(float vi, float vt, float dis2stop, float upspeed)
{
    float deltV;
    if(vi >= vt)
    {
        if(vi < 0.2)
        {
            return SmallestSpeed;
        }
        // double spe = atan(fabs(dis2stop)) / atan(M_PI / 2) * upspeed;
        // if(spe > vi)
        // {
        //    return vi;
        // }
        // else
        // {
        //    return spe;
        // }
        deltV = Kp * dis2stop;
        if(deltV>MAX_DELT_v)
  		{
  		  deltV=MAX_DELT_v;
  		}
        if(vi - deltV < SmallestSpeed)
        {
            return SmallestSpeed;
        }
        return vi - deltV;
    }
    else
    {
        return Stop;
    }
}

float SendInfoAndMakeSpeedSmooth(const InfoToSS & itss)
{
    op << itss.LeftBackTire << " " << itss.RightBackTire << " " << itss.SendSpeed << " " << itss.TargetSpeed << " " << itss.Distance2Stop << " ";
    float FeedbackSpeed = FilterFeedBackSpeed(itss.LeftBackTire,itss.RightBackTire);
    float sent_speed = 0;
    if(itss.Distance2Stop > DISTANCE && FeedbackSpeed > 0.02)
    {
        sent_speed = SpeedUp(itss.SendSpeed, itss.TargetSpeed);
        op << 1 << " ";
    }
    else if(itss.Distance2Stop > DISTANCE)
    {
        op << 2 << " ";
        sent_speed = SmallestSpeed;
    }
    else
    {
        op << 3 << " ";
        sent_speed = SpeedDown(FeedbackSpeed, Stop, itss.Distance2Stop, itss.TargetSpeed);
    }
    op << sent_speed << " " << FeedbackSpeed << endl;
    return sent_speed;
}

#endif
