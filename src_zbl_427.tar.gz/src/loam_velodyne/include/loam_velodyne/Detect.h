#ifndef DETECT_H_
#define DETECT_H_

#include <iostream>
#include "ObstacleDetect.h"

using namespace std;

class Detect
{
private:

	

public:
	ObstacleDetect OD;
	int mode = 0;

public:
	
	void GetData(const Point & t, const vector<Point> & obstacles);
	int IsThisTimeCrashed(const vector<Point> & obstacles);

};

#endif
