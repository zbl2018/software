/*
    School: Sun Yat-sen University
    Author: Louis Chen
      Date: 2018.01.11
*/

#ifndef _REVERSECONTROLLER_H
#define _REVERSECONTROLLER_H

#include <iostream>
#include <fstream>
#include <cmath>
#include "ReverseController.h"

using namespace std;
ofstream data_for_analysis("/home/chen/Project/catkin_sysu/src/loam_velodyne/output/rc_data.csv");


class ReverseController
{

public:
    ReverseController();

    template<typename T> ReverseController(const T & location, const T & target);
    template<typename T> double GiveInfoAndReturnSteer(const T & location, const T & target);
    template<typename T> T WorldToMap(const T & location, const T & target);
    template<typename T> double ComputeSteeringAngle(const T & RelativeCoord);

public:
    
    double SteerAngle = 0.0;

private:
    
    const double L = 0.5;
    const double lrv = 0.15;

};

const double ToRad = 57.29577951308232;

ReverseController::ReverseController()
{

}

template<typename T>
ReverseController::ReverseController(const T & location, const T & target)
{
    SteerAngle = ComputeSteeringAngle(WorldToMap(location, target));
}

template<typename T>
double ReverseController::GiveInfoAndReturnSteer(const T & location, const T & target)
{
    
    data_for_analysis << location.x << " " << location.y << " " << location.heading << " " << target.x << " " << target.y << " ";
    SteerAngle = ComputeSteeringAngle(WorldToMap(location, target));
    data_for_analysis << SteerAngle << endl;
    return SteerAngle;
}

template<typename T>
T ReverseController::WorldToMap(const T & location, const T & target)
{
    T delta_p;
    double delta_x = 0.0;
    double delta_y = 0.0;
    double yaw = location.heading / ToRad;
    
    delta_x = target.x - location.x;
    delta_y = target.y - location.y;

    delta_p.x = delta_x * cos(yaw) - delta_y * sin(yaw);
    delta_p.y = delta_x * sin(yaw) + delta_y * cos(yaw) + lrv;

	data_for_analysis << delta_p.x << " " << delta_p.y << " ";	

    return delta_p;

}

template<typename T>
double ReverseController::ComputeSteeringAngle(const T & RelativeCoord)
{
    double a;					//a:车辆前轮转角
	double delt_b;				//delt_b:车辆当前方向和预瞄方向的夹角  预瞄方向：车两后轮中心和预瞄点的连线
    double Lf;					//Lforward，后轮中心与预瞄点的距离
    
    delt_b = atan(RelativeCoord.x / RelativeCoord.y);
    Lf = sqrt(RelativeCoord.x * RelativeCoord.x + RelativeCoord.y * RelativeCoord.y);
    if(Lf < 0.01)
    {
        return 0;
    }
    a = ToRad * -atan(L * sin(delt_b) / (Lf / 2.0 + lrv * cos(delt_b)));
    data_for_analysis << RelativeCoord.x << " " << RelativeCoord.y << " " << delt_b << " " << Lf << " " << 2.0 * sin(delt_b) / Lf << " ";
    return -a;
}


#endif
