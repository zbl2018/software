#include "getAngle.h"
#include <vector>
#include <iostream>
#include <cmath>
using namespace std;

class Simulation
{

private:

	vector<Point> MicObstacle;
	vector<Point> TrueObstacle;
	GPSPoint NowLoc;
	GPSPoint MicLoc;

	
	double MicLx;
	double MicLy;
	double MaxObjectHeading = 0;
	double MinObjectHeading = 0;

public:

	int IsCrashed=0;
	int LeftOrRightSimulate = 1;
	ObstacleDetect OD;
	GPSPoint target;
	double ObjectHeading = 0;
	

public:

	void GetRoadHeading(const double & RoadHeading);
	void GetData(const GPSPoint & t, const GPSPoint & NowLocataion, const vector<Point> & obstacles);
	int SimulationTimes();
	int SimulateStart();
	int LeftSimulate();
	int RightSimulate();

};

void Simulation::GetData(const GPSPoint & t, const GPSPoint & NowLocataion, const vector<Point> & obstacles)
{
	target = t;
	NowLoc = NowLocataion;
	TrueObstacle.clear();
	TrueObstacle = obstacles;
	
}

void Simulation::GetRoadHeading(const double & RoadHeading)
{
	MaxObjectHeading = RoadHeading + 80;
	MinObjectHeading = RoadHeading - 80;
}

int Simulation::SimulationTimes()
{
	for(int i=0; i < 2; i++)
	{
		MicLoc = NowLoc;
		if(!SimulateStart())
		{
			return 0;
		}
	}
	return 1;
}

int Simulation::SimulateStart()
{
	if(LeftOrRightSimulate)
	{
		IsCrashed = LeftSimulate();
		LeftOrRightSimulate = 0;
		return IsCrashed;
	}
	else
	{
		IsCrashed = RightSimulate();
		LeftOrRightSimulate = 1;
		return IsCrashed;
	}
}

int Simulation::LeftSimulate()
{
	Point PointOfTarget;
	
	while(MicLoc.heading < MaxObjectHeading)
	{
		double mode = 0;
		MicLoc.heading += 3;
		WorldtoMap(MicLoc,target.x,target.y,MicLx,MicLy);
		PointOfTarget.x = MicLx;
		PointOfTarget.y = MicLy;
		OD.GetTargetPoint(PointOfTarget);
		Point temptArc={0,0};
		for(vector<Point>::iterator it=OD.a.TheSetOfPointsOnTheArc.begin(); it != OD.a.TheSetOfPointsOnTheArc.end(); it++)
		{
			double h = (NowLoc.heading - MicLoc.heading) / 57.3;
			temptArc.x = cos(h) * it->x - sin(h) * it->y;
        	temptArc.y = sin(h) * it->x + cos(h) * it->y;
			it->x = temptArc.x;
			it->y = temptArc.y;
		}
		for(vector<Point>::iterator it=TrueObstacle.begin(); it != TrueObstacle.end(); it++)
		{
			if(OD.GetCrashPoint(*it))
			{
				mode = 1;
				break;
			}
		}
		if(!mode)
		{
			ObjectHeading = MicLoc.heading;
			return 0;
		}
	}
	return 1;
}

int Simulation::RightSimulate()
{
	Point PointOfTarget;
	
	while(MicLoc.heading > MinObjectHeading)
	{
		double mode = 0;
		MicLoc.heading -= 3;
		WorldtoMap(MicLoc,target.x,target.y,MicLx,MicLy);
		PointOfTarget.x = MicLx;
		PointOfTarget.y = MicLy;
		OD.GetTargetPoint(PointOfTarget);
		Point temptArc={0,0};
		for(vector<Point>::iterator it=OD.a.TheSetOfPointsOnTheArc.begin(); it != OD.a.TheSetOfPointsOnTheArc.end(); it++)
		{
			double h = (NowLoc.heading - MicLoc.heading) / 57.3;
			temptArc.x = cos(h) * it->x - sin(h) * it->y;
        	temptArc.y = sin(h) * it->x + cos(h) * it->y;
			it->x = temptArc.x;
			it->y = temptArc.y;
		}
		for(vector<Point>::iterator it=TrueObstacle.begin(); it != TrueObstacle.end(); it++)
		{
			if(OD.GetCrashPoint(*it))
			{
				mode = 1;
				break;
			}
		}
		if(!mode)
		{
			ObjectHeading = MicLoc.heading;
			cout << MicLx << " " << MicLy << " " << ObjectHeading << endl;
			return 0;
		}
	}
	return 1;
}
