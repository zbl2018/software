/*
 *  Copyright (c) 2017, Tanzby 
 *  All rights reserved.
*/
#include <pcl/recognition/ransac_based/trimmed_icp.h>
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <boost/format.hpp>
#include <pcl/registration/icp.h>
#include <pcl/visualization/pcl_plotter.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <boost/thread/thread.hpp>
#include <iostream>
#define PI 3.14159265
#define timeCount(t2,t1) std::chrono::duration_cast<std::chrono::duration<double>>(t2-t1).count()
//typedef std::chrono::steady_clock::time_point tp;
const float ACCURACY =  1e-9;
const float defaultParamForICP[]    = {0,0,0,0,0,0,25,1.5,3.2,2,-0.36};
const float defaultParamForTRIICP[] = {0,0,0,0,0,0,0.98,0.9999,3.2,2,-0.36};
std::ofstream print_record( "Record.txt",ios::out );
float calculateRTBuf[6];
bool ShowErr = true;
/**
 * @param[in] filePath The path of pcd file
 * @return read pcd data
 */
inline pcl::PointCloud<pcl::PointXYZ>::Ptr readPCDFile(const char * filePath)
{
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud (new pcl::PointCloud<pcl::PointXYZ>);
    if (pcl::io::loadPCDFile<pcl::PointXYZ> (filePath, *cloud) == -1)
    {
        if(ShowErr) PCL_ERROR ("Couldn't read file %s\n",filePath);
        throw -1;
    }
#ifdef PCLTOOLPRINTF
    std::cout << "Loaded " << cloud->size () << " data points from "<< filePath << std::endl;
#endif
    return cloud;
}


/**
 * @brief     show cloud image before and after register]
 * @param[in] target_cloud Cloud which is the target object
 * @param[in] input_cloud  Cloud which is needed to be transformed
 * @param[in] output_cloud Cloud which has registered
 * @param[in] savePcdName  The name of pcd file which combines target cloud and registered cloud
 */
void showPCDInfo(pcl::PointCloud<pcl::PointXYZ>::Ptr target_cloud,
                 pcl::PointCloud<pcl::PointXYZ>::Ptr input_cloud,
                 pcl::PointCloud<pcl::PointXYZ>::Ptr output_cloud,
                 const char* savePcdName = "register.pcd"
)
{
    // Saving transformed input cloud.
    pcl::io::savePCDFileASCII (savePcdName, *output_cloud);

    // Initializing point cloud visualizer
    boost::shared_ptr<pcl::visualization::PCLVisualizer>
            viewer_before(new pcl::visualization::PCLVisualizer ("before")),
            viewer_final (new pcl::visualization::PCLVisualizer ("Final"));

    viewer_final->setBackgroundColor (0, 0, 0);
    viewer_before->setBackgroundColor (0, 0, 0);

    // Coloring and visualizing target cloud (red).
    pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> target_color (target_cloud, 255, 0, 0);
    // Coloring and visualizing transformed input cloud (green).
    pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ>  output_color (output_cloud, 0, 255, 0);

    // viewer_before setting
    viewer_before->addPointCloud<pcl::PointXYZ> (target_cloud, target_color, "target cloud");
    viewer_before->addPointCloud<pcl::PointXYZ> (input_cloud, output_color, "input cloud");
    viewer_before->setPointCloudRenderingProperties (pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 1, "target cloud");
    viewer_before->setPointCloudRenderingProperties (pcl::visualization::PCL_VISUALIZER_POINT_SIZE,  1, "input cloud");
    viewer_before->addCoordinateSystem (1.0, "global");
    viewer_before->initCameraParameters ();
    // viewer_final setting
    viewer_final->addPointCloud<pcl::PointXYZ> (target_cloud, target_color, "target cloud");
    viewer_final->addPointCloud<pcl::PointXYZ> (output_cloud, output_color, "output cloud");
    viewer_final->setPointCloudRenderingProperties (pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 1, "target cloud");
    viewer_final->setPointCloudRenderingProperties (pcl::visualization::PCL_VISUALIZER_POINT_SIZE,  1, "output cloud");
    viewer_final->addCoordinateSystem (1.0, "global");
    viewer_final->initCameraParameters ();

    // Wait until visualizer window is closed.
    while (!viewer_final->wasStopped ())
    {
        viewer_final->spinOnce (100);
        viewer_before->spinOnce (100);
        boost::this_thread::sleep (boost::posix_time::microseconds (50));
    }
}

/**
 * @param[in] RTMatrix RT RTMatrix,which included 3*3 Rotation Matrix and 3*1 translation Matrix
 */
inline void print4x4Matrix (const Eigen::Matrix4d & RTMatrix)
{
    double phi = 0,theta,psi;
    if(fabs(RTMatrix(2,0)-1.0)>1E-9)
    {
        double theta1 = -asin(RTMatrix(2,0));
        double theta2 = PI - theta1;
        double psi1 = atan2(RTMatrix(2,1)/cos(theta1),RTMatrix(2,2)/cos(theta1));
        double psi2 = atan2(RTMatrix(2,1)/cos(theta2),RTMatrix(2,2)/cos(theta2));
        double phi1 = atan2(RTMatrix(1,0)/cos(theta1),RTMatrix(0,0)/cos(theta1));
        double phi2 = atan2(RTMatrix(1,0)/cos(theta2),RTMatrix(0,0)/cos(theta2));
        if(fabs(psi1)<1.74 && fabs(psi1)<1.74 && fabs(psi1)<1.74)
        {
            phi = phi1*180/PI;
            theta = theta1*180/PI;
            psi= psi1*180/PI;
        }
        else
        {
            phi = phi2*180/PI;
            theta = theta2*180/PI;
            psi= psi2*180/PI;
        }
    }
    else
    {
        if (fabs(RTMatrix(2,0)+1.0)<1E-9)
        {
            theta = 90;
            psi = (phi + atan2(RTMatrix(0,1),RTMatrix(0,2)))*180/PI;
        }
        else
        {
            theta = -90;
            psi = (-phi + atan2(-RTMatrix(0,1),-RTMatrix(0,2)))*180/PI;
        }
    }
    calculateRTBuf[0]=psi;
    calculateRTBuf[1]=theta;
    calculateRTBuf[2]=phi;
    calculateRTBuf[3]=RTMatrix (0, 3);
    calculateRTBuf[4]=RTMatrix (1, 3);
    calculateRTBuf[5]=RTMatrix (2, 3); // rx  ry  rz  tx  ty  tz

#ifdef PCLTOOLPRINTF
    printf ("RT Matrix :\n");
        printf (" | %6.3f %6.3f %6.3f %6.3f| \n", RTMatrix (0, 0), RTMatrix (0, 1), RTMatrix (0, 2),RTMatrix (0, 3));
        printf (" | %6.3f %6.3f %6.3f %6.3f| \n", RTMatrix (1, 0), RTMatrix (1, 1), RTMatrix (1, 2),RTMatrix (1, 3));
        printf (" | %6.3f %6.3f %6.3f %6.3f| \n", RTMatrix (2, 0), RTMatrix (2, 1), RTMatrix (2, 2),RTMatrix (2, 3));
        printf (" | %6.3f %6.3f %6.3f %6.3f| \n", RTMatrix (3, 0), RTMatrix (3, 1), RTMatrix (3, 2),RTMatrix (3, 3));
        printf ("RT of Eular:\n");
        printf("%6.4f %6.4f %6.4f %6.4f %6.4f %6.4f\n", psi, theta,phi,RTMatrix (0, 3),RTMatrix (1, 3),RTMatrix (2, 3)); // rx  ry  rz  tx  ty  tz

        printf ("Rotation    : %6.4f d\n",sqrt( psi*psi + theta*theta + phi*phi ));
        printf ("Displacement: %6.4f m\n",sqrt( RTMatrix (0, 3)*RTMatrix (0, 3)+ RTMatrix (1, 3)*RTMatrix (1, 3) + RTMatrix (2, 3)*RTMatrix (2, 3)));
#endif

#ifdef PCLTOOLRECORD

    char buf[64];
        sprintf(buf,"%6.4f %6.4f %6.4f %6.4f %6.4f %6.4f",psi,theta,phi,RTMatrix (0, 3), RTMatrix (1, 3), RTMatrix (2, 3));
        print_record << buf<<endl;
#endif
}

/**
 * For an input cloud data, points which is in the range of distance will be erased
 * @param input_cloud The cloud to be cooped
 * @param distance    the length of erace radius
 * @param eraseGround if ground points will be erased
 *        eraseGround = 1, x will be the condition
 *        eraseGround = 2, y
 *        eraseGround = 3, z
 * @param groundDeep the deep of laser to the ground
 */
inline void eraseNearPoint(pcl::PointCloud<pcl::PointXYZ>::Ptr input_cloud, const float & distance,int eraseGround = 3,float groundDeep = -0.6)
{
    size_t j = 0;
    for ( size_t i = 0; i < input_cloud->points.size(); ++i )
    {
        float dis2 = input_cloud->points[i].x * input_cloud->points[i].x +
                     input_cloud->points[i].y * input_cloud->points[i].y +
                     input_cloud->points[i].z * input_cloud->points[i].z;
        if ( dis2 < distance*distance + 1e-16
             || (eraseGround == 1 && input_cloud->points[i].x < groundDeep)
             || (eraseGround == 2 && input_cloud->points[i].y < groundDeep)
             || (eraseGround == 3 && input_cloud->points[i].z < groundDeep)
                )
        {
            continue;
        }
        input_cloud->points[j++] = input_cloud->points[i];
    }
    input_cloud->resize(j);
}
/**
 * For an input cloud data, points which is in the range of distance will be erased
 * @param pcdFilePath The path of cloud to be cooped
 * @param distance    the length of erace radius
 * @param eraseGround if ground points will be erased
 *        eraseGround = 1, x will be the condition
 *        eraseGround = 2, y
 *        eraseGround = 3, z
 * @param groundDeep the deep of laser to the ground
 */
inline void eraseNearPoint(const char *pcdFilePath, const float & distance, int eraseGround = 3,float groundDeep = -0.6)
{
    pcl::PointCloud<pcl::PointXYZ>::Ptr input_cloud(readPCDFile(pcdFilePath));
    eraseNearPoint(input_cloud,distance,eraseGround,groundDeep);
    std::cout << input_cloud->points.size()<<std::endl;
    pcl::io::savePCDFileASCII ("erased.pcd", *input_cloud);
}

/**
 * @brief put corner point cloud and surfur cloud into a cloud
 *        example:
 *                conbineCorSuf("/media/dky/hdd/Data/0.5-1.5/0.5/cor/%d.pcd",
 *                              "/media/dky/hdd/Data/0.5-1.5/0.5/suf/%d.pcd",
 *                              "/media/dky/hdd/Data/0.5-1.5/0.5/cmb/%d.pcd");
 * @param[in] filePathCor the read path of corner cloud
 * @param[in] filePathSur the read path of surfur cloud
 * @param[in] filePathCmb the save path of cloud which is combined
 */
void conbineCorSuf(const char* filePathCor,const char* filePathSur,const char* filePathCmb )
{
    ShowErr = false;
    boost::format	fmt  ( filePathCor );
    boost::format	fmt_ ( filePathSur );
    boost::format	fmt__( filePathCmb );

    for(int j = 0; j < 500; j++)
    {
        try
        {
            pcl::io::savePCDFileASCII( (fmt__%j).str(),
                                       ( *(readPCDFile( (fmt_%j).str().c_str()))+*(readPCDFile((fmt%j).str().c_str())))
            );
        }
        catch(...)
        {
            std::cout<<"end !\n";
            break;
        }
    }
}
/**
 * @brief convert [rx,ry,rz,tx,ty,tz] to RT Matrix
 */
Eigen::Matrix4f conver6param2RT(const float& rx,const float& ry,const float& rz,
                                const float& tx,const float& ty,const float& tz)
{
    float transform_pair[] = {rx,ry,rz,tx,ty,tz};
    Eigen::AngleAxisf rollAngle(transform_pair[2], Eigen::Vector3f::UnitZ());
    Eigen::AngleAxisf yawAngle(transform_pair[1], Eigen::Vector3f::UnitY());
    Eigen::AngleAxisf pitchAngle(transform_pair[0], Eigen::Vector3f::UnitX());
    Eigen::Quaternion<float> q = rollAngle * yawAngle * pitchAngle;
    Eigen::Matrix3f rotationMatrix = q.matrix();//rotation of point_cloud
    Eigen::Vector3f T(transform_pair[3],transform_pair[4],transform_pair[5]);
    Eigen::Vector3f x_now(0.5,0,0.5);
    Eigen::Vector3f x_next;
    x_next = rotationMatrix*x_now + T;
    //cout<<"next:"<<x_next[0]<<" "<<x_next[1]<<" "<<x_next[2]<<endl<<endl;
    Eigen::Matrix4f final_RT;
    for(int i=0;i<3;i++)
    {
        for(int j=0;j<3;j++)
        {
            final_RT(i,j) = rotationMatrix(i,j);
            final_RT(i,3) = transform_pair[i+3];
        }
    }
    final_RT(3,0) = 0;
    final_RT(3,1) = 0;
    final_RT(3,2) = 0;
    final_RT(3,3) = 1;
    return final_RT;
}

/**
 *@brief read target Cloud and input cloud,then ICP will be used to register input cloud to target cloud
 *@param[in] targetCloud  the point data which is the registering target
 *@param[in] inputCloud   the point data which is needed to transform and regeiter to targin cloud
 *@param[in] param        some setting od ICP algorithm and PointCloud coops.
 *                        param[0] to param[5] will be the values used for RT estimation
 *                        param[6] will be the number of maximum number of iterations
 *                        param[7] will be the maximum distance between a point and its correspondence
 *                        param[8] is the erasing range around the laser
 *                        param[9] represents the coordinates of the vertical direction, 1 for x, 2 for y, 3 for z
 *                        param[10] represents the length from laser machine to ground, which can erase the points in the ground
 *@param[out] RT          estimate RT result
 *@param[in]  showPcdGraph decide whether to show two images which are the of two point Cloud before and after
 *                        registering.
*/
double ICP(pcl::PointCloud<pcl::PointXYZ>::Ptr targetCloud,
         pcl::PointCloud<pcl::PointXYZ>::Ptr inputCloud,
         float param[],float RT[],bool showPcdGraph = false)
{
    for (int i = 0; i < 11; ++i)
        if (abs(param[i]-0)<1E-10)
            param[i] = defaultParamForICP[i];

    eraseNearPoint(targetCloud,param[8],int(param[9]),param[10]);
    eraseNearPoint(inputCloud,param[8],int(param[9]),param[10]);

    pcl::IterativeClosestPoint<pcl::PointXYZ, pcl::PointXYZ> icp;
    icp.setInputSource(inputCloud);
    icp.setInputTarget(targetCloud);
    icp.setMaximumIterations(int(param[6]));
    icp.setMaxCorrespondenceDistance(param[7]);
    icp.setTransformationEpsilon(ACCURACY);
    icp.setEuclideanFitnessEpsilon(ACCURACY);

    pcl::PointCloud<pcl::PointXYZ>::Ptr Final(new pcl::PointCloud<pcl::PointXYZ>);
#ifdef PCLTOOLPRINTF
    //tp t1 = std::chrono::steady_clock::now();
#endif

    Eigen::Matrix4f g = conver6param2RT (param[0],param[1],param[2],param[3],param[4],param[5]);// rx,ry,rz,tx,ty,tz
    icp.align(*Final,g);
#ifdef PCLTOOLPRINTF
    //tp t2 = std::chrono::steady_clock::now();
    //std::cout <<"align Time :"<<timeCount(t2,t1)<<"s\n";
#endif

    print4x4Matrix(icp.getFinalTransformation ().cast<double>());
    RT[0]=calculateRTBuf[0];
    RT[1]=calculateRTBuf[1];
    RT[2]=calculateRTBuf[2];
    RT[3]=calculateRTBuf[3];
    RT[4]=calculateRTBuf[4];
    RT[5]=calculateRTBuf[5];
    if(false)
    {
        showPCDInfo(targetCloud,inputCloud,Final);
    }
    return icp.getFitnessScore();
   
 
}
/**
 *@brief read target Cloud and input cloud,then
 *       ICP will be used to register input cloud to target cloud
 *@param[in] targetCloudfilePath the path of point file which is the registering target
 *@param[in] inputCloudfilePath  the path of point file which is needed to transform and regeiter to targin cloud
 *@param[in] param               some setting od ICP algorithm and PointCloud coops.
 *                               param[0] to param[5] will be the values used for RT estimation
 *                               param[6] will be the number of maximum number of iterations
 *                               param[7] will be the maximum distance between a point and its correspondence
 *                               param[8] is the erasing range around the laser
 *                               param[9] represents the coordinates of the vertical direction, 1 for x, 2 for y, 3 for z
 *                               param[10] represents the length from laser machine to ground, which can erase the points in the ground
 *@param[out] RT                 estimate RT result
 *@param[in]  showPcdGraph       decide whether to show two images which are the of two point Cloud before and after
 *                               registering.
*/
double ICP(const char* targetCloudfilePath, const char* inputCloudfilePath,
         float param[],float RT[], bool showPcdGraph = true )
{
    // Loading first scan of room.
    pcl::PointCloud<pcl::PointXYZ>::Ptr target_cloud = readPCDFile(targetCloudfilePath),input_cloud = readPCDFile(inputCloudfilePath);
    return ICP(target_cloud,input_cloud,param,RT,showPcdGraph);
}
/**
 *\brief  read target PointCloud and input PointCloudcloud data, then TrimmedICP will be used to register input PointCloud to target cloud
 *@param[in] targetCloud     the path of point file which is the registering target
 *@param[in] inputCloud      the path of point file which is needed to transform and regeiter to targin cloud
 *@param[in] param           some setting od ICP algorithm and PointCloud coops.
 *                           param[0] to param[5] will be the values used for RT estimation
 *                           param[6] will be the ratio of number of points which used in calculate RT
 *                           param[7] will be the value for iteration ending condition, the larger param[2]
 *                                        themore accurate
 *                           param[8] is the erasing range around the laser
 *                           param[9] represents the coordinates of the vertical direction, 1 for x, 2 for y, 3 for z
 *                           param[10] represents the length from laser machine to ground, which can erase the points in the ground
 *@param[out] RT             estimate RT result
 *@param[in]  showPcdGraph   decide whether to show two images which are the of two point Cloud before and after
 *                               registering.
*/
void TRIICP(pcl::PointCloud<pcl::PointXYZ>::Ptr targetCloud,
            pcl::PointCloud<pcl::PointXYZ>::Ptr inputCloud,
            float param[],float RT[],bool showPcdGraph = true)
{
    for (int i = 0; i < 11; ++i)
        if (abs(param[i]-0)<1E-10)
            param[i] = defaultParamForTRIICP[i];

    eraseNearPoint(targetCloud,param[8],int(param[9]),param[10]);
    eraseNearPoint(inputCloud,param[8],int(param[9]),param[10]);
#ifdef PCLTOOLPRINTF
    //tp t1 = std::chrono::steady_clock::now();
#endif

    pcl::recognition::TrimmedICP<pcl::PointXYZ,float>  triICP;
    triICP.init(targetCloud);
    triICP.setNewToOldEnergyRatio(param[6]);
    Eigen::Matrix4f RTMatrix= conver6param2RT (param[0],param[1],param[2],param[3],param[4],param[5]);// rx,ry,rz,tx,ty,tz
    triICP.align(*inputCloud,inputCloud->points.size()*param[7],RTMatrix);


#ifdef PCLTOOLPRINTF
    //tp t2 = std::chrono::steady_clock::now();
    //td::cout <<"align Time :"<<timeCount(t2,t1)<<"s\n";
#endif

    print4x4Matrix(RTMatrix.cast<double>());
    RT[0]=calculateRTBuf[0];
    RT[1]=calculateRTBuf[1];
    RT[2]=calculateRTBuf[2];
    RT[3]=calculateRTBuf[3];
    RT[4]=calculateRTBuf[4];
    RT[5]=calculateRTBuf[5];
    if(showPcdGraph)
    {
        pcl::PointCloud<pcl::PointXYZ>::Ptr Final(new pcl::PointCloud<pcl::PointXYZ>);
        pcl::transformPointCloud (*inputCloud, *Final, RTMatrix);
        showPCDInfo(targetCloud,inputCloud,Final);
    }
}

/**
 *\brief read target PointCloud and input PointCloudcloud data from files, then TrimmedICP will be used to register input PointCloud to target cloud
 *@param[in] targetCloudfilePath the path of point file which is the registering target
 *@param[in] inputCloudfilePath  the path of point file which is needed to transform and regeiter to targin cloud
 *@param[in] param               some setting od ICP algorithm and PointCloud coops.
 *                               param[0] to param[5] will be the values used for RT estimation
 *                               param[6] will be the ratio of number of points which used in calculate RT
 *                               param[7] will be the value for iteration ending condition, the larger param[2]
 *                                        themore accurate
 *                               param[8] is the erasing range around the laser
 *                               param[9] represents the coordinates of the vertical direction, 1 for x, 2 for y, 3 for z
 *                               param[10] represents the length from laser machine to ground, which can erase the points in the ground
 *@param[out] RT                 estimate RT result
 *@param[in]  showPcdGraph       decide whether to show two images which are the of two point Cloud before and after
 *                               registering.
*/
void TRIICP(const char* targetCloudfilePath,
            const char* inputCloudfilePath,
            float param[],float RT[], bool showPcdGraph = true )
{
    // Loading first scan of room.
    pcl::PointCloud<pcl::PointXYZ>::Ptr target_cloud = readPCDFile(targetCloudfilePath),input_cloud = readPCDFile(inputCloudfilePath);
    TRIICP(target_cloud,input_cloud,param,RT,showPcdGraph);
}


/**
 * @brief accept a RT transform vector and a staring point coor, transform coor to a new coor' by RT
 * @param[in] TL        transform vector
 * @param[in] oriPoint  start point coor, also a output of a new point coor
 */
inline void transform(float TL[],float oriPoint[])
{
    TL[0] = TL[0]*PI/180+oriPoint[0];
    TL[1] = TL[1]*PI/180+oriPoint[1];
    TL[2] = TL[2]*PI/180+oriPoint[2];


    float x1 = cos(TL[2]) * TL[3] - sin(TL[2]) * TL[4];
    float y1 = sin(TL[2]) * TL[3] + cos(TL[2]) * TL[4];
    float z1 = TL[5];

    float x2 = x1;
    float y2 = cos(TL[0]) * y1 - sin(TL[0]) * z1;
    float z2 = sin(TL[0]) * y1 + cos(TL[0]) * z1;

    oriPoint[0] = TL[0];
    oriPoint[1] = TL[1];
    oriPoint[2] = TL[2];


    oriPoint[3] = cos(TL[1]) * x2 + sin(TL[1]) * z2 + oriPoint[3];
    oriPoint[4] = y2+oriPoint[4];
    oriPoint[5] = -sin(TL[1]) * x2 + cos(TL[1]) * z2 + oriPoint[5];
}

/**
 * @brief input a path of RT record txt file, and generate a path according to it
 * @param[in] pointCloudSetPath the input RT file path
 */
void drawPath(const char*pointCloudSetPath,
              bool isTriICP = true)
{
    boost:pcl::visualization::PCLPlotter* plt = new pcl::visualization::PCLPlotter("Path");
    plt->setYRange (0, 80);
    plt->setXRange (-30,10 );
    plt->setShowLegend(1);

    std::ifstream f(pointCloudSetPath);
    std::vector<double> posX,posZ;
    std::string s;
    float A[6] = {0,0,0,0,0,0},TL[6];
    while(!plt->wasStopped())
    {
        if(getline(f,s))
        {
            std::stringstream ss;
            ss << s;
            for(int i = 0;i < 6; i++)
            {
                ss >> TL[i];
            }

            transform(TL,A);

            posX.push_back(A[3]); // save X values
            posZ.push_back(A[5]); // save Z values
            plt->clearPlots ();
            plt->addPlotData(posX,posZ,"keyPoint",vtkChart::POINTS);
            plt->addPlotData(posX,posZ,"keyPoint Line",vtkChart::LINE);
        }
        boost::this_thread::sleep (boost::posix_time::microseconds (50));
        plt->spinOnce (50);
    }
}


/**
 * @brief use TriICP of ICP to coop a series of .pcd and generate a path of motion
 * @param pointCloudSetPath[in] the file path of input .pcd file set
 * @param numOfPCDfile[in] the size of input .pcd file set
 * @param isTriICP[in]     whether to ues TriICP for registering key-Frames to key-Frames
 */
void drawPathDynamic(const char*pointCloudSetPath,
                     int numOfPCDfile = 150,
                     bool isTriICP = true)
{

    boost:pcl::visualization::PCLPlotter* plt = new pcl::visualization::PCLPlotter("Path");
    plt->setYRange (0, 80);
    plt->setXRange (-30,10 );
    plt->setShowLegend(1);
    boost::format fmtKey( pointCloudSetPath );
    std::vector<double> posX,posZ;
    float A[6] = {0,0,0,0,0,0};
    float TL[6];
    float param1[11] = {0,0,0,0,0,0.1,0.98,0.999999};
    float param2[11] = {0,0,0,0,0,0.1,100,1.0};
    int i = 0;
    bool noentry = false;
    while(!plt->wasStopped ())
    {
        if(!noentry && i < 194)
        {
            try
            {
                if(isTriICP)
                {
                    TRIICP(  (fmtKey%i).str().c_str(),(fmtKey%(i+1)).str().c_str(),param1,TL,0 );
                }
                else
                {
                    ICP( (fmtKey%i).str().c_str(),(fmtKey%(i+1)).str().c_str(),param2,TL,0);
                }

                transform(TL,A);

                posX.push_back(A[3]); // save X values
                posZ.push_back(A[5]); // save Z values
                plt->clearPlots ();
                plt->addPlotData(posX,posZ,"keyPoint",vtkChart::POINTS);
                plt->addPlotData(posX,posZ,"keyPoint Line",vtkChart::LINE);
                plt->spinOnce (50);
                i++;
            }
            catch(...)
            {
                noentry = true;
            }
        }
        else
        {
            plt->spinOnce (50);
            boost::this_thread::sleep (boost::posix_time::microseconds (50));

        }
    }
}
/**
 * @brief accept paths of key-Frames set path and input-Frames set path and read them, then first use key-to-key to
 * form a path of key frame, then register input pcd to key-Frames which is near that frame, also form a path of input-Frame
 * @param[i] keyframeCloudfilePath   path of key-Frame pcds
 * @param[i] inputframeCloudfilePath path of input-Frame pcds
 * @param[i] numOfkeyFrame           number of input pcd frames file
 * @param[i] numOfinputFrame         number of input pcd frames file
 * @param[i] isTriICPforKeytoInput   whether to ues TriICP for registering input-Frames to key-Frames
 * @param[i] isTriICPforKeytoKey     whether to ues TriICP for registering key-Frames to key-Frames
 */
void followDraw(const char *keyframeCloudfilePath,
                const char *inputframeCloudfilePath,
                int numOfkeyFrame = 190,
                int numOfinputFrame = 150,
                bool isTriICPforKeytoInput = true,
                bool isTriICPforKeytoKey = true)
{

    boost:pcl::visualization::PCLPlotter* plt = new pcl::visualization::PCLPlotter("Path");
    plt->setYRange (0, 80);
    plt->setXRange (-30,10 );
    plt->setShowLegend(1);
    boost::format fmtKey( keyframeCloudfilePath );
    boost::format fmtInp( inputframeCloudfilePath );
    std::vector<double> KposX,KposZ,IposX,IposZ;
    float A[6] = {0,0,0,0,0,0};
    float B[6] = {0,0,0,0,0,0};
    float TL_A[6],TL_B[6],HP_Last[6];
    float param_for_key[11] = {0,0,0,0,0,0.1,0.99,0.999999};
    float param_for_key2input[11] = {0,0,0,0,0,0.0,0.99,0.999999};
    float param_for_key_ICP[11] = {0,0,0,0,0,0.1,30,1.0};
    float param_for_key2input_ICP[11] = {0,0,0,0,0,0.0,50,2.0};
    float param2[11] = {0,0,0,0,0,0.1,100,1.0};
    int i = 0,j=0;
    bool noentry = false;
    std::vector<char> color_1(4);
    std::vector<char> color_2(4);
    color_1[0]=(char(255));
    color_1[1]=(char(0));
    color_1[2]=(char(0));
    color_1[3]=(char(255));
    color_2[0]=(char(0));
    color_2[1]=(char(0));
    color_2[2]=(char(255));
    color_2[3]=(char(255));
    const int numOfkeyFrame = 190;
    const int numOfinputFrame = 150;
    while(!plt->wasStopped ())
    {
        if(!noentry && i<170)
        {
            try
            {
                if(i<numOfkeyFrame)
                {
                    if(isTriICPforKeytoKey)
                    {
                        TRIICP(  (fmtKey%i).str().c_str(),(fmtKey%(i+1)).str().c_str(),param_for_key,TL_A,0 );
                    }
                    else
                    {
                        ICP( (fmtKey%i).str().c_str(),(fmtKey%(i+1)).str().c_str(),param_for_key_ICP,TL_A,0);
                    }

                    // backUp heading of postion for keyFrame in last time
                    HP_Last[0] =  A[0];
                    HP_Last[1] =  A[1];
                    HP_Last[2] =  A[2];
                    HP_Last[3] =  A[3];
                    HP_Last[4] =  A[4];
                    HP_Last[5] =  A[5];

                    // upDate heading and pos for keyFrame of now
                    transform(TL_A,A);

                    if(j<numOfinputFrame)
                    {
                        // calculate input ->keyframe
                        int index = i/numOfkeyFrame*numOfinputFrame;
                        if(isTriICPforKeytoInput)
                        {
                            TRIICP( (fmtKey%i).str().c_str(),(fmtInp%(index)).str().c_str(),param_for_key2input,TL_B,0 );
                        }
                        else
                        {
                            ICP( (fmtKey%i).str().c_str(),(fmtInp%(index)).str().c_str(),param_for_key2input_ICP,TL_B,0 );

                        }

                        transform(TL_B,HP_Last);
                        IposX.push_back(B[3]); // save X values of input frame
                        IposZ.push_back(B[5]); // save Z values of input frame
                        plt->addPlotData(IposX,IposZ,"keyPoint B",vtkChart::POINTS,color_2);
                    }

                    KposX.push_back(A[3]); // save X values of keyframe
                    KposZ.push_back(A[5]); // save Z values of keyframe
                    plt->addPlotData(KposX,KposZ,"keyPoint A",vtkChart::POINTS,color_1);
                    j++;

                }
                plt->spinOnce (50);
                plt->clearPlots ();
                i++;
            }
            catch(...)
            {
                noentry = true;
            }

        }
        else
        {
            plt->spinOnce (50);
            boost::this_thread::sleep (boost::posix_time::microseconds (50));
        }
    }
}


/**
 * @brief use TriICP of ICP to coop two series of .pcd and generate twno path of motion
 * @param Cloud1Path  pointCloudSetPath the input RT file path
 * @param Cloud2Path  pointCloudSetPath the input RT file path
 * @param numOfFrame1 the size of input .pcd file set 1
 * @param numOfFrame2 the size of input .pcd file set 2
 */
void drawTwoPath(const char *Cloud1Path,
                 const char *Cloud2Path,
                 const int numOfFrame1 = 150,
                 const int numOfFrame2 = 150,
                 bool isTriICP_1 = true,
                 bool isTriICP_2 = true )
{
    boost:pcl::visualization::PCLPlotter* plt = new pcl::visualization::PCLPlotter("Path");
    plt->setYRange (0, 80);
    plt->setXRange (-30,10 );
    plt->setShowLegend(1);
    boost::format fmt1( Cloud1Path );
    boost::format fmt2( Cloud2Path );
    std::vector<double> posX_A,posZ_A,posX_B,posZ_B;
    float A[6] = {0,0,0,0,0,0}, B[6] = {0,0,0,0,0,0};
    float TL_A[6],TL_B[6];
    float param_icp[11] = {0,0,0,0,0,0.1,50,1.0};
    float param_triicp[11] = {0,0,0,0,0,0.1,0.98,0.999999};
    int i = 0,j = 0;
    bool noentry = false;
    
    std::vector<char> color_1(4);
    std::vector<char> color_2(4);
    color_1[0]=(char(255));
    color_1[1]=(char(0));
    color_1[2]=(char(0));
    color_1[3]=(char(255));
    color_2[0]=(char(0));
    color_2[1]=(char(0));
    color_2[2]=(char(255));
    color_2[3]=(char(255));

    while(!plt->wasStopped ())
    {
        if(!noentry && i < 194)
        {
            try
            {
                if(i < numOfFrame1)
                {
                    if(isTriICP_1)
                    {
                        TRIICP( (fmt1%i).str().c_str(),(fmt1%(i+1)).str().c_str(),param_triicp,TL_A,0 );
                    }
                    else
                    {
                        ICP( (fmt1%i).str().c_str(),(fmt1%(i+1)).str().c_str(),param_icp,TL_A,0 );

                    }
                    // upDate heading and pos for keyFrame of now
                    transform(TL_A,A);
                    posX_A.push_back(A[3]); // save X values
                    posX_A.push_back(A[5]); // save Z values
                    plt->addPlotData(posX_A,posZ_A,"Cloud1 Points",vtkChart::POINTS,color_1);
                }

                if(j<numOfFrame2)
                {
                    // upDate heading and pos for keyFrame of now
                    if(isTriICP_2)
                    {
                        TRIICP( (fmt2%j).str().c_str(),(fmt2%(j+1)).str().c_str(),param_triicp,TL_B,0 );
                    }
                    else
                    {
                        ICP( (fmt2%j).str().c_str(),(fmt2%(j+1)).str().c_str(),param_icp,TL_B,0 );

                    }
                    transform(TL_B,B);
                    posX_B.push_back(B[3]); // save X values
                    posZ_B.push_back(B[5]); // save Z values
                    plt->addPlotData(posX_B,posZ_B,"Cloud2 Points",vtkChart::POINTS,color_2);

                }


                plt->spinOnce (50);
                if(i<numOfFrame1 && j < numOfFrame2)
                {
                    j++;
                    i++;
                    plt->clearPlots ();
                }
            }
            catch(...)
            {
                noentry = true;
            }
        }
        else
        {
            plt->spinOnce (50);
            boost::this_thread::sleep (boost::posix_time::microseconds (50));
        }
    }

}
